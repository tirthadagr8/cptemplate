#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <setjmp.h>
#include <alloca.h>
#include <sys/systeminfo.h>
#include "avl.h"
#include "se.h"

/*
 * Notes on bizarre issues with parsing:
 *
 * When structs are declared, the members of the struct are parsed and the
 * struct definition is complete before any code can be parsed.  Then,
 * variables of this struct type are parsed and new instances of the struct
 * are created.  Then when the code is parsed and references to the struct
 * members are made, the links to the variables referenced point to the
 * instances of the struct variable, not the "variables" in the struct
 * declaration itself.
 * 
 * However, in the case of classes, the class definition has not been
 * completely parsed before the class code is encountered.  As the parser
 * builds the parse tree for the class code, references made to members
 * of the class itself are referenced back to the actual *declaration* of the
 * class member instead of an instance.  This is why there was a limitation
 * on the class type that only one active user defined class variable could
 * be allowed per program.  Because the parse tree for the class code pointed
 * at the "variables" inside of the declaration of the class instead of an
 * instance of the class.
 */

typedef struct _name T_NAME;

struct _name {
  char   *n_name;
  T_NAME *n_next;
};

extern int yylex(void);

/* for se_put_* */
#define NO_DUPS     0
#define ALLOW_DUPS  1

#define MAX_CHAR  ((unsigned char)  -1)
#define MAX_SHORT ((unsigned short) -1)

#define GET_BLOCK(n)    ((T_BLOCK *)  get_symbol(SYM_BLOCK, (n)))
#define GET_VARIABLE(n) ((T_STRUCT *) get_symbol(SYM_VARIABLE, (n)))
#define GET_STRUCT(n)   ((T_STRUCT *) get_symbol(SYM_STRUCT, (n)))

#define PUT_BLOCK(n, b, a)    put_symbol(SYM_BLOCK,    n, b, a)
#define PUT_VARIABLE(n, v, a) put_symbol(SYM_VARIABLE, n, v, a)
#define PUT_STRUCT(n, s, a)   put_symbol(SYM_STRUCT,   n, s, a)

/* for integral_constant_expression second parameter */
#define INT_TYPES    VAR_INTEGRAL
#define AGG_TYPES   (VAR_NUMERIC|VAR_STRING)

typedef struct _bmap T_BMAP;

struct _bmap {
  char      *bm_name;
  T_STYPE    bm_stype;
  int        bm_param_count;
  T_VARTYPE  bm_return_type;
  char      *bm_user_type;
  void     (*bm_check)(char *, T_EXPR *);
};

/*
 * local function forward declarations
 */


static T_STATEMENT *reverse_statement_list(T_STATEMENT *);
static T_EXPR      *reverse_arg_list      (T_EXPR *);
static T_VARIABLE  *reverse_member_list   (T_VARIABLE *);
static T_CASE      *reverse_case_list     (T_CASE *);

static void        *get_symbol      (T_SYMTYPE, char *);
static void         put_symbol      (T_SYMTYPE, char *, void *, int);
static void         add_special_name(char *);
static void         free_user_type  (T_STRUCT *);
static T_NAME      *get_special_name(char *);
static T_BMAP      *get_builtin     (char *);
static T_VARIABLE  *get_variable    (char *);

static int          check_symbol      (anode *);
static void         symbol_check      (void);
static T_VARTYPE    type_value        (T_EXPR *);
static int          integral_constant_expression(T_EXPR *, int);
static void         expr_clash_check  (T_EXPR *, T_EXPR *, char *);
static void         l_expr_clash_check(T_EXPR *, T_EXPR *, char *);
static T_VARIABLE  *do_dot_check      (char *, char *m, T_VARIABLE *, int *);
static T_VARIABLE  *do_array_check    (char *, T_EXPR *, T_VARIABLE *);
static void         do_digit_checks   (T_VARIABLE *, T_EXPR *);
static void         do_assign_check   (T_VARIABLE *, T_EXPR *, char *, int);
static void         do_switch_check   (T_SWITCH *);
static void         do_for_check      (T_FOR *);
static void         do_while_check    (T_WHILE *);
static void         do_special_check  (char *, T_VARIABLE *);
static void         do_structure_check(T_STRUCT *);
static void         do_param_check    (T_FCALL *);
static void         do_main_check     (T_BLOCK *);
static void         do_return_check   (T_VARIABLE *, T_RETURN *);
static void         do_builtin_check  (T_BMAP *, T_VARIABLE *,
                                       T_FCALL *, T_EXPR *, int);
static void         do_compound_check (T_VARIABLE *, T_EXPR *, char *);
static void         do_lazy_value     (T_EXPR *, T_VARIABLE *);
static T_STATEMENT *do_lazy_lvalue    (T_STATEMENT *);
static void         do_attach_check   (char *, T_BLOCK *);
static void         do_aggregate_check(T_VARIABLE *, T_VARIABLE *);
static void         do_member_check   (T_VARIABLE *, T_VARIABLE *);
static void         do_do_check       (T_DO *);

/* builtins */
static void         do_string_check  (char *, T_EXPR *);
static void         do_long_check    (char *, T_EXPR *);
static void         do_dbl_check     (char *, T_EXPR *);
static void         do_2dbl_check    (char *, T_EXPR *);
static void         do_dbl_long_check(char *, T_EXPR *);
static void         do_long_dbl_check(char *, T_EXPR *);
static void         do_refresh_check (char *, T_EXPR *);
static void         do_printf_check  (char *, T_EXPR *);
static void         do_qsort_check   (char *, T_EXPR *);
static void         do_bsearch_check (char *, T_EXPR *);
static void         do_signal_check  (char *, T_EXPR *);
static void         do_spawn_check   (char *, T_EXPR *);
static void         do_fprintf_check (char *, T_EXPR *);
static void         do_syslog_check  (char *, T_EXPR *);
static void         do_sizeof_check  (char *, T_EXPR *);
static void         do_kvm_cvt_check (char *, T_EXPR *);
static void         do_kvm_addr_check(char *, T_EXPR *);
static void         do_str_fill_check(char *, T_EXPR *);

/* news */
static T_VARIABLE  *new_variable    (T_VARIABLE *);
static T_STRUCT    *new_user_type   (T_VARIABLE *);
static void        *new_array_type  (T_VARIABLE *);

/* misc. */
static void         member_inherit  (T_VARIABLE *, T_VFTYPE);
static void         case_error      (T_CASE *, char *);
static void         push            (void *, T_STACK *);
static void        *pop             (T_STACK *);
static int          is_lazy         (T_VARIABLE *);
static void         fix_offsets     (T_STRUCT *, int, int);
static void         free_aggregate  (T_VARIABLE *);


/*
 * local variable declarations
 */

static char        error_buf[BUFSIZ];
static char        type_name[128];
static char        block_type[128];
static char       *current_scope_name;
static char       *current_class_name;
static char        in_local_scope;
static char        in_class_scope;
static char        block_already_called;
static T_VARIABLE *current_scope;
static T_VARIABLE *class_scope;
static T_VARIABLE *last_variable;
static T_VARIABLE *last_parameter;
static T_VARIABLE *last_dot_component;
static T_STACK     component_stack;
static T_FCALL     *call_list;
static T_RETURN   *return_list;
static T_BREAK    *break_list;
static T_STACK     break_stack;
static T_NAME     *name_list;
static T_CONTINUE *continue_list;
static T_STACK     continue_stack;
static T_VARIABLE  zero_variable;
static T_EXPR      zero_expr;

static T_BMAP builtins[] = {
 { "acos",        S_ACOS,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "acosh",       S_ACOSH,       1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "asin",        S_ASIN,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "asinh",       S_ASINH,       1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "atan",        S_ATAN,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "atan2",       S_ATAN2,       2, VAR_DOUBLE,  0,        do_2dbl_check     },
 { "atanh",       S_ATANH,       1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "atexit",      S_ATEXIT,      1, VAR_LONG,    0,        do_string_check   },
 { "bsearch",     S_BSEARCH,     5, VAR_REGISTER,0,        do_bsearch_check  },
 { "cbrt",        S_CBRT,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "ceil",        S_CEIL,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "copysign",    S_COPYSIGN,    2, VAR_DOUBLE,  0,        do_2dbl_check     },
 { "cos",         S_COS,         1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "cosh",        S_COSH,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "debug_off",   S_DEBUG_OFF,   0, 0,           0,        0                 },
 { "debug_on",    S_DEBUG_ON,    0, 0,           0,        0                 },
 { "erf",         S_ERF,         1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "erfc",        S_ERFC,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "exp",         S_EXP,         1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "expm1",       S_EXPM1,       1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "fabs",        S_FABS,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "fileno",      S_FILENO,      1, VAR_LONG,    0,        do_long_check     },
 { "first_proc",  S_FIRST_PROC,  0, VAR_USER,   "psinfo_t",0                 },
 { "floor",       S_FLOOR,       1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "fmod",        S_FMOD,        2, VAR_DOUBLE,  0,        do_2dbl_check     },
 { "fprintf",     S_FPRINTF,    -1, VAR_LONG,    0,        do_fprintf_check  },
 { "frexp",       S_FREXP,       2, VAR_DOUBLE,  0,        do_dbl_long_check },
 { "gamma",       S_GAMMA,       1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "gamma_r",     S_GAMMA_R,     2, VAR_DOUBLE,  0,        do_dbl_long_check },
 { "get_proc",    S_GET_PROC,    1, VAR_USER,   "psinfo_t",do_long_check     },
 { "hypot",       S_HYPOT,       2, VAR_DOUBLE,  0,        do_2dbl_check     },
 { "ilogb",       S_ILOGB,       1, VAR_LONG,    0,        do_dbl_check      },
 { "isnan",       S_ISNAN,       1, VAR_LONG,    0,        do_dbl_check      },
 { "itoa",        S_ITOA,        1, VAR_STRING,  0,        do_long_check     },
 { "j0",          S_J0,          1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "j1",          S_J1,          1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "jn",          S_JN,          2, VAR_DOUBLE,  0,        do_long_dbl_check },
 { "kvm_address", S_KVM_ADDR,    1, VAR_REGISTER,0,        do_kvm_addr_check },
 { "kvm_cvt",     S_KVM_CVT,     2, 0,           0,        do_kvm_cvt_check  },
 { "kvm_declare", S_KVM_DECLARE, 1, VAR_REGISTER,0,        do_string_check   },
 { "ldexp",       S_LDEXP,       2, VAR_DOUBLE,  0,        do_dbl_long_check },
 { "lgamma",      S_LGAMMA,      1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "lgamma_r",    S_LGAMMA_R,    2, VAR_DOUBLE,  0,        do_dbl_long_check },
 { "log",         S_LOG,         1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "log10",       S_LOG10,       1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "log1p",       S_LOG1P,       1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "logb",        S_LOGB,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "matherr",     S_MATHERR,     1, VAR_LONG,    0,        do_long_check     },
 { "modf",        S_MODF,        2, VAR_DOUBLE,  0,        do_dbl_long_check },
 { "next_proc",   S_NEXT_PROC,   0, VAR_USER,   "psinfo_t",0                 },
 { "nextafter",   S_NEXTAFTER,   2, VAR_DOUBLE,  0,        do_2dbl_check     },
 { "pow",         S_POW,         2, VAR_DOUBLE,  0,        do_2dbl_check     },
 { "printf",      S_PRINTF,     -1, VAR_LONG,    0,        do_printf_check   },
 { "qsort",       S_QSORT,       4, 0,           0,        do_qsort_check    },
 { "readdir",     S_READDIR,     1, VAR_REGISTER,0,        do_long_check     },
 { "refresh$",    S_REFRESH,     1, 0,           0,        do_refresh_check  },
 { "remainder",   S_REMAINDER,   2, VAR_DOUBLE,  0,        do_2dbl_check     },
 { "rint",        S_RINT,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "scalb",       S_SCALB,       2, VAR_DOUBLE,  0,        do_2dbl_check     },
 { "scalbn",      S_SCALBN,      2, VAR_DOUBLE,  0,        do_dbl_long_check },
 { "signal",      S_SIGFUNC,     2, VAR_STRING,  0,        do_signal_check   },
 { "significand", S_SIGNIFICAND, 1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "sin",         S_SIN,         1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "sinh",        S_SINH,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "sizeof",      S_SIZEOF,      1, VAR_LONG,    0,        do_sizeof_check   },
 { "sprintf",     S_SPRINTF,    -1, VAR_STRING,  0,        do_printf_check   },
 { "sqrt",        S_SQRT,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "struct_empty",S_STRUCT_EMPTY,2, 0,           0,        do_str_fill_check },
 { "struct_fill", S_STRUCT_FILL, 2, 0,           0,        do_str_fill_check },
 { "syslog",      S_SYSLOG,     -1, 0,           0,        do_syslog_check   },
 { "tan",         S_TAN,         1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "tanh",        S_TANH,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "y0",          S_Y0,          1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "y1",          S_Y1,          1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "yn",          S_YN,          2, VAR_DOUBLE,  0,        do_long_dbl_check },
};
typedef union
#ifdef __cplusplus
	YYSTYPE
#endif
 {
  int          integer;
  double       real;
  char        *string;
  T_BLOCK     *block;
  T_STATEMENT *statement;
  T_IF        *if_statement;
  T_FCALL     *call_statement;
  T_WHILE     *while_statement;
  T_ASSIGN    *assign_statement;
  T_EXPR      *expression;
  T_LEXPR     *l_expression;
  T_VARIABLE  *variable;
  T_STRUCT    *structure;
  T_VARTYPE    var_type;
  T_FOR       *for_statement;
  T_DO        *do_statement;
  T_SWITCH    *switch_statement;
  T_CASE      *case_statement;
  T_RETURN    *return_statement;
  T_BREAK     *break_statement;
  T_CONTINUE  *continue_statement;
  T_SFTYPE     struct_flags;
} YYSTYPE;
# define AMPERSAND 257
# define AND 258
# define AND_EQ 259
# define ASSIGN 260
# define ASTERISK 261
# define ATTACH 262
# define BREAK 263
# define CASE 264
# define CHAR_TYPE 265
# define CLASS 266
# define COLON 267
# define COMMA 268
# define CONTINUE 269
# define DECREMENT 270
# define DEFAULT 271
# define DO 272
# define DOT 273
# define DOUBLE_TYPE 274
# define ELLIPSIS 275
# define ELSE 276
# define EQ 277
# define EXCLAMATION 278
# define EXTERN 279
# define FOR 280
# define GE 281
# define GT 282
# define HAT 283
# define IF 284
# define INCREMENT 285
# define INTEGER 286
# define KSTAT 287
# define KVM 288
# define LE 289
# define LEFT_CURLY 290
# define LEFT_PAREN 291
# define LEFT_SQUARE 292
# define LNEW 293
# define LONGLONG_TYPE 294
# define LONG_TYPE 295
# define LRENEW 296
# define LT 297
# define MIB 298
# define MINUS 299
# define MINUS_EQ 300
# define MOD_EQ 301
# define NDD 302
# define NE 303
# define NIL 304
# define OR 305
# define OR_EQ 306
# define PERCENT 307
# define PIPE 308
# define PLUS 309
# define PLUS_EQ 310
# define PRAGMA 311
# define QSTRING 312
# define RE_EQ 313
# define RE_NEQ 314
# define REAL 315
# define LRETURN 316
# define QUESTION 317
# define RIGHT_CURLY 318
# define RIGHT_PAREN 319
# define RIGHT_SQUARE 320
# define SEMICOLON 321
# define SHIFT_LEFT 322
# define SHIFT_RIGHT 323
# define SHIFT_LEFT_EQ 324
# define SHIFT_RIGHT_EQ 325
# define SHORT_TYPE 326
# define SLASH 327
# define SLASH_EQ 328
# define STRING 329
# define STRING_TYPE 330
# define STRUCT 331
# define SWITCH 332
# define TILDE 333
# define TIMES_EQ 334
# define UCHAR_TYPE 335
# define ULONGLONG_TYPE 336
# define ULONG_TYPE 337
# define USER_TYPE 338
# define USHORT_TYPE 339
# define WHILE 340
# define XOR_EQ 341
# define AT_SIGN 342
# define BACKSLASH 343
# define DOT_DOT 344
# define EOLN 345
# define BI_MAX_CPU 346
# define BI_MAX_DISK 347
# define BI_MAX_IF 348
# define BI_MAX_INTS 349

#include <inttypes.h>

#ifdef __STDC__
#include <stdlib.h>
#include <string.h>
#define	YYCONST	const
#else
#include <malloc.h>
#include <memory.h>
#define	YYCONST
#endif

#include <values.h>

#if defined(__cplusplus) || defined(__STDC__)

#if defined(__cplusplus) && defined(__EXTERN_C__)
extern "C" {
#endif
#ifndef yyerror
#if defined(__cplusplus)
	void yyerror(YYCONST char *);
#endif
#endif
#ifndef yylex
	int yylex(void);
#endif
	int yyparse(void);
#if defined(__cplusplus) && defined(__EXTERN_C__)
}
#endif

#endif

#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
extern int yyerrflag;
YYSTYPE yylval;
YYSTYPE yyval;
typedef int yytabelem;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif
#if YYMAXDEPTH > 0
int yy_yys[YYMAXDEPTH], *yys = yy_yys;
YYSTYPE yy_yyv[YYMAXDEPTH], *yyv = yy_yyv;
#else	/* user does initial allocation */
int *yys;
YYSTYPE *yyv;
#endif
static int yymaxdepth = YYMAXDEPTH;
# define YYERRCODE 256


/*
 * exported functions
 */

void
se_parse_init(void)
{
  T_VARIABLE *vp;

  Se_symbol_table = avlinit();
  if (Se_symbol_table == 0)
    yyerror("cannot initialize parser", ERR_LATER);

  Se_type_sizes[VAR_STRING]    =  sizeof(char *);
  Se_type_sizes[VAR_CHAR]      =  sizeof(char);
  Se_type_sizes[VAR_UCHAR]     =  sizeof(unsigned char);
  Se_type_sizes[VAR_SHORT]     =  sizeof(short);
  Se_type_sizes[VAR_USHORT]    =  sizeof(unsigned short);
  Se_type_sizes[VAR_LONG]      =  sizeof(int);
  Se_type_sizes[VAR_ULONG]     =  sizeof(unsigned int);
  Se_type_sizes[VAR_LONGLONG]  =  sizeof(T_LLONG);
  Se_type_sizes[VAR_ULONGLONG] =  sizeof(T_ULLONG);
  Se_type_sizes[VAR_DOUBLE]    =  sizeof(double);
  Se_type_sizes[VAR_USER]      = -1;
  Se_type_sizes[VAR_ELLIPSIS]  =  sizeof(void *);
  Se_type_sizes[VAR_BOGUS]     = -2;

  vp = NEW(T_VARIABLE);
  vp->var_name = "stdin";
  vp->var_un.var_register = (T_REGISTER) stdin;
  vp->var_flags = VF_REFERENCED | VF_GENERATED;
  vp->var_type = VAR_REGISTER;
  put_symbol(SYM_VARIABLE, vp->var_name, vp, 0);

  vp = NEW(T_VARIABLE);
  vp->var_name = "stdout";
  vp->var_un.var_register = (T_REGISTER) stdout;
  vp->var_flags = VF_REFERENCED | VF_GENERATED;
  vp->var_type = VAR_REGISTER;
  put_symbol(SYM_VARIABLE, vp->var_name, vp, 0);

  vp = NEW(T_VARIABLE);
  vp->var_name = "stderr";
  vp->var_un.var_register = (T_REGISTER) stderr;
  vp->var_flags = VF_REFERENCED | VF_GENERATED;
  vp->var_type = VAR_REGISTER;
  put_symbol(SYM_VARIABLE, vp->var_name, vp, 0);
}

T_BLOCK *
se_get_block(char *name)
{
  return (T_BLOCK *) get_symbol(SYM_BLOCK, name);
}

static T_VARIABLE *
get_variable(char *name)
{
  T_VARIABLE *vp;

  if (in_local_scope) {
    for(vp=current_scope; vp; vp=vp->var_next)
      if (strcmp(vp->var_name, name) == 0)
        return vp;
    if (in_class_scope) {
      for(vp=class_scope; vp; vp=vp->var_next)
        if (strcmp(vp->var_name, name) == 0)
          return vp;
    }
  }
  return (T_VARIABLE *) GET_VARIABLE(name);
}

T_VARIABLE *
se_get_variable(char *name)
{
  return get_variable(name);
}

T_STRUCT *
se_get_struct(char *name)
{
  return (T_STRUCT *) get_symbol(SYM_STRUCT, name);
}


/*
 * list reversal functions
 */


static T_STATEMENT *
reverse_statement_list(T_STATEMENT *sp)
{
  T_STATEMENT *head = 0;
  T_STATEMENT *ssp;

  for(; sp; sp=ssp) {
    ssp = sp->s_next;
    sp->s_next = head;
    head = sp;
  }
  return head;
}

static T_EXPR *
reverse_arg_list(T_EXPR *ep)
{
  T_EXPR *head = 0;
  T_EXPR *eep;

  for(; ep; ep=eep) {
    eep = ep->e_next;
    ep->e_next = head;
    head = ep;
  }
  return head;
}

static T_VARIABLE *
reverse_member_list(T_VARIABLE *vp)
{
  T_VARIABLE *head = 0;
  T_VARIABLE *vvp;

  for(; vp; vp=vvp) {
    vvp = vp->var_next;
    vp->var_next = head;
    head = vp;
  }
  return head;
}

static T_CASE *
reverse_case_list(T_CASE *cp)
{
  T_CASE *head = 0;
  T_CASE *ccp;

  for(; cp; cp=ccp) {
    ccp = cp->ca_next;
    cp->ca_next = head;
    head = cp;
  }
  return head;
}


/*
 * symbol getting and putting
 */


static void *
get_symbol(T_SYMTYPE type, char *name)
{
  anode *anp = avlget(Se_symbol_table, name);
  T_SYMBOL *sp;

  if ((anp == 0) || (anp->an_data == 0))
    return 0;
  sp = (T_SYMBOL *) anp->an_data;
  if (sp->sym_type != type)
    return 0;
  return (void *) sp->sym_un.sym_block;
}

static void
put_symbol(T_SYMTYPE type, char *name, void *p, int allow_dups)
{
  int redeclared = 0;
  anode *anp;
  T_SYMBOL *sp;

  switch(avlinsert(Se_symbol_table, name, 0, &anp)) {
  case AVL_THERE:
    sp = (T_SYMBOL *) anp->an_data;
    if ((allow_dups == 0) && sp->sym_un.sym_block) {
      snprintf(error_buf, sizeof error_buf, "redeclaration of %s", name);
      yyerror(error_buf, ERR_NONFATAL);
      redeclared = 1;
      break;
    } /* else fall through */
  case AVL_INSERT:
    if (anp->an_data == 0) {
      sp = NEW(T_SYMBOL);
      sp->sym_type = type;
      anp->an_data = sp;
    }
    if ((redeclared == 0) && p)
      sp->sym_un.sym_block = (T_BLOCK *) p;
    break;
  case AVL_NOMEM:
    yyerror("out of memory", ERR_LATER);
    break;
  }
}

static void
add_special_name(char *name)
{
  T_NAME *tp;
  T_NAME *np = NEW(T_NAME);

  for(tp=name_list; tp; tp=tp->n_next)
    if (strcmp(tp->n_name, name) == 0) {
      snprintf(error_buf, sizeof error_buf,
        "redeclaration of special prefix: %s", name);
      yyerror(error_buf, ERR_NONFATAL);
    }
  np->n_name = name;
  np->n_next = name_list;
  name_list = np;
}

static T_NAME *
get_special_name(char *name)
{
  T_NAME *np;

  if (name == 0)
    return 0;
  for(np=name_list; np; np=np->n_next)
    if (strncmp(np->n_name, name, strlen(np->n_name)) == 0)
      return np;
  return 0;
}

static T_BMAP *
get_builtin(char *name)
{
  static avlhdr *builtin_tree;
  int i;
  int n;
  anode *anp;

  if (builtin_tree == 0) {
    builtin_tree = avlinit();
    if (builtin_tree == 0)
      yyerror("out of builtin_tree memory", ERR_FATAL);
    builtin_tree->ah_cmp = AVC_NONE;
    n = sizeof(builtins) / sizeof(T_BMAP);
    for(i=0; i<n; i++)
      if (avlinsert(builtin_tree, builtins[i].bm_name,
                   &builtins[i], &anp) == AVL_NOMEM)
        yyerror("out of builtin_tree node memory", ERR_FATAL);
  }
  anp = avlget(builtin_tree, name);
  if (anp == 0)
    return 0;
  return (T_BMAP *) anp->an_data;
}

/*
 * checking functions
 */


static int
check_symbol(anode *anp)
{
  T_SYMBOL *sp = (T_SYMBOL *) anp->an_data;
  T_BLOCK *bp;
  T_VARIABLE *vp;

  if (sp == 0)
    return 0;
  switch(sp->sym_type) {
  case SYM_BLOCK:
    bp = sp->sym_un.sym_block;
    if (bp == 0) {
      snprintf(error_buf, sizeof error_buf,
        "undeclared block: %s", anp->an_tag);
      yyerror(error_buf, ERR_NONFATAL);
    } else {
      for(vp=bp->b_variables; vp; vp=vp->var_next)
        if ((vp->var_flags & VF_REFERENCED) == 0) {
          snprintf(error_buf, sizeof error_buf,
            "variable: %s unused in block: %s", vp->var_name, bp->b_name);
          yyerror(error_buf, ERR_WARNING);
        }
    }
    break;
  case SYM_VARIABLE:
    vp = sp->sym_un.sym_variable;
    if (vp && ((vp->var_flags & (VF_REFERENCED|VF_EXTERN)) == 0)) {
      snprintf(error_buf, sizeof error_buf,
        "unused global variable: %s", vp->var_name);
      yyerror(error_buf, ERR_WARNING);
    }
    vp->var_flags |= VF_GLOBAL;
    for(vp=vp->var_instances; vp; vp=vp->var_next)
      vp->var_flags |= VF_GLOBAL;
    break;
  case SYM_STRUCT:
    break;
  }
  return 0;
}

/* hunt for blocks called but not declared */
static void
symbol_check(void)
{
  anode *anp;

  for(anp=avlfirst(Se_symbol_table); anp; anp=avlnext(Se_symbol_table, anp, 0))
    check_symbol(anp);
}

static T_VARTYPE
type_value(T_EXPR *ep)
{
  T_VARIABLE *vp;

  if (ep == 0)
    return VAR_BOGUS;

  switch(ep->e_type) {
  case E_VALUE:
  case E_INCRA:
  case E_INCRB:
  case E_DECRA:
  case E_DECRB:
  case E_LAZY_INCRA:
  case E_LAZY_INCRB:
  case E_LAZY_DECRA:
  case E_LAZY_DECRB:
    vp = ep->e_variable;
    break;
  case E_CALL:
    if (ep->e_call->c_block)
      vp = ep->e_call->c_block->b_return;
    else
      return VAR_BOGUS;
    break;
  case E_ASSIGN:
    vp = ep->e_assign->a_variable;
    break;
  default:
    if (ep->e_right == 0)
      return type_value(ep->e_left);
    else
      return type_value(ep->e_left) | type_value(ep->e_right);
  }

  if (vp) {
    if (vp->var_dimension && (vp->var_subscript == 0))
      if (vp->var_type == VAR_CHAR)
        return VAR_STRING;
      else
        return VAR_BOGUS;
    else
      return vp->var_type;
  } else
    return VAR_BOGUS;
}

static int
integral_constant_expression(T_EXPR *ep, int allowed_types)
{
  T_VARIABLE *vp = 0;

  if (ep == 0)
    return 0;

  switch(ep->e_type) {
  case E_VALUE:
    vp = ep->e_variable;
    break;
  case E_CALL:
  case E_QCOP:
  case E_INCRA:
  case E_INCRB:
  case E_DECRA:
  case E_DECRB:
  case E_LAZY_INCRA:
  case E_LAZY_INCRB:
  case E_LAZY_DECRA:
  case E_LAZY_DECRB:
  case E_ASSIGN:
    return 0;
  default:
    if (ep->e_right == 0)
      return integral_constant_expression(ep->e_left, allowed_types);
    else
      return integral_constant_expression(ep->e_left, allowed_types) &&
             integral_constant_expression(ep->e_right, allowed_types);
  }

  /* only E_VALUE here */
  if (vp == 0)
    return 0;

  return ((vp->var_name == 0) && (vp->var_type & allowed_types));
}

static void
expr_clash_check(T_EXPR *left, T_EXPR *right, char *op)
{
  T_VARTYPE left_value = type_value(left);
  T_VARTYPE right_value = (right ? type_value(right) : VAR_NUMERIC);

  switch(*op) {
  case '+':
  case '-':
  case '*':
  case '/':
    if (((left_value  & VAR_NUMERIC) == 0) ||
        ((right_value & VAR_NUMERIC) == 0)) {
      snprintf(error_buf, sizeof error_buf,
        "operands have incompatible types: op \"%s\"", op);
      yyerror(error_buf, ERR_NONFATAL);
    }
    break;
  case '%':
  case '&':
  case '|':
  case '^':
  case '<':
  case '>':
  case '~':
    if (((left_value  & VAR_NUMERIC) == 0) ||
        ((right_value & VAR_NUMERIC) == 0)) {
      snprintf(error_buf, sizeof error_buf,
        "operands have incompatible types: op \"%s\"", op);
      yyerror(error_buf, ERR_NONFATAL);
    }
    if ((left_value == VAR_DOUBLE) || (right_value == VAR_DOUBLE)) {
      snprintf(error_buf, sizeof error_buf,
        "operands must have integral type: op \"%s\"", op);
      yyerror(error_buf, ERR_NONFATAL);
    }
    break;
  default:
    /* ?: */
    break;
  }
}

static void
l_expr_clash_check(T_EXPR *left, T_EXPR *right, char *op)
{
  T_VARTYPE left_value = type_value(left);
  T_VARTYPE right_value = type_value(right);
  T_VARTYPE result_value = left_value | right_value;

  switch(result_value) {
  case VAR_USER:
    yyerror("structure comparisons not supported", ERR_NONFATAL);
    return;
  case VAR_STRING:
    return;
  default:
    if ((op[0] == '=') && (op[1] == '~'))
      yyerror("operands must be type string: op \"=~\"", ERR_NONFATAL);
    else
      /* if they're not both numeric then it's wrong */
      if (result_value & ~VAR_NUMERIC) {
        snprintf(error_buf, sizeof error_buf,
          "operands have incompatible types: op \"%s\"", op);
        yyerror(error_buf, ERR_NONFATAL);
      }
  }
}

static int
theres_an_array_in_the_family(T_VARIABLE *vp)
{
  T_VARIABLE *vvp;

  for(vvp=vp->var_parent; vvp; vvp=vvp->var_parent)
    if (vvp->var_dimension)
      return 1;
  return 0;
}

static T_VARIABLE *
do_dot_check(char *var_name, char *member_name, T_VARIABLE *vp, int *newed)
{
  T_VARIABLE *vvp;
  T_VARIABLE *xvp;

  if (vp->var_type != VAR_USER) {
    snprintf(error_buf, sizeof error_buf,
      "variable: %s is not a structure", var_name);
    yyerror(error_buf, ERR_NONFATAL);
    return 0;
  }
  if (vp->var_dimension) {
    if (vp->var_subscript == 0)
      yyerror("left operand of \".\" must be struct object", ERR_NONFATAL);

    /* even dynamic arrays will have at least one (see new_array()) */
    vvp = ((T_STRUCT **) vp->var_un.var_array)[0]->st_members;
  } else
    vvp = vp->var_un.var_user->st_members;
  for(; vvp; vvp=vvp->var_next) {
    if (strcmp(vvp->var_name, member_name) == 0) {
      vvp->var_parent = vp;
      if (theres_an_array_in_the_family(vvp)) {
        xvp = NEW(T_VARIABLE);
        *xvp = *vvp;
        xvp->var_next = vvp->var_instances;
        vvp->var_instances = xvp;
        if (newed)
          *newed = 1;
        return xvp;
      } else
        return vvp;
    }
  }
  snprintf(error_buf, sizeof error_buf, "invalid member name: %s", member_name);
  yyerror(error_buf, ERR_NONFATAL);
  return 0;
}

static T_VARIABLE *
do_array_check(char *var_name, T_EXPR *sub, T_VARIABLE *vp)
{
  int n;
  T_VARIABLE *vvp;

  /* is this an array? */
  if (vp->var_dimension == 0) {
    snprintf(error_buf, sizeof error_buf, "%s: %s is not an array",
      (vp->var_flags & VF_MEMBER) ? "member" : "variable", var_name);
    yyerror(error_buf, ERR_NONFATAL);
    return 0;
  }
  if ((type_value(sub) & VAR_INTEGRAL) == 0) {
    yyerror("invalid subscript type", ERR_NONFATAL);
    return 0;
  }
  /* see if it's subscripted with a constant and do a bounds check */
  if ((sub->e_type == E_VALUE) && (vp->var_dimension != -1)) {
    vvp = sub->e_variable;
    if (vvp->var_name == 0) {
      n = vvp->var_un.var_digit;
      if ((n < 0) || (n >= vp->var_dimension)) {
        snprintf(error_buf, sizeof error_buf,
          "subscript: %d out of range for: %s", n, vp->var_name);
        yyerror(error_buf, ERR_NONFATAL);
      }
    }
  }
  vp->var_subscript = sub;
  return vp;
}

static void
do_digit_checks(T_VARIABLE *vp, T_EXPR *ep)
{
  char c;
  short s;
  double d;
  int i;
  T_LLONG li;
  unsigned char uc;
  unsigned short us;
  unsigned int ui;
  T_ULLONG uli;
  T_VARIABLE *vvp = 0;

  /* make sure all constant values in the expression are the same type *
   * as the variable that the expression is being assigned to.         */

  switch(ep->e_type) {
  case E_EXPRESSION:
  case E_QCOP:
    do_digit_checks(vp, ep->e_left);
    if (ep->e_right)
      do_digit_checks(vp, ep->e_right);
    return;
  case E_VALUE:
  case E_INCRA:
  case E_INCRB:
  case E_DECRA:
  case E_DECRB:
  case E_LAZY_INCRA:
  case E_LAZY_INCRB:
  case E_LAZY_DECRA:
  case E_LAZY_DECRB:
    /* variable/constant in question */
    vvp = ep->e_variable;
    break;
  case E_CALL:
  case E_ASSIGN:
    return;
  }

  /* not a constant or not a digit, return */
  if ((vvp == 0) || vvp->var_name || ((vvp->var_type & VAR_NUMERIC) == 0))
    return;

  /* the constant is stored as a VAR_CONSTANT or a VAR_DOUBLE. *
   * Grab it and make it what the variable is.                 */

  switch(vp->var_type) {
  case VAR_CHAR:
    c = vvp->var_un.var_register;
    vvp->var_un.var_digit = (int) c;
    vvp->var_type = vp->var_type;
    break;
  case VAR_UCHAR:
    uc = vvp->var_un.var_register;
    vvp->var_un.var_udigit = (unsigned int) uc;
    vvp->var_type = vp->var_type;
    break;
  case VAR_SHORT:
    s = vvp->var_un.var_register;
    vvp->var_un.var_digit = (int) s;
    vvp->var_type = vp->var_type;
    break;
  case VAR_USHORT:
    us = vvp->var_un.var_register;
    vvp->var_un.var_udigit = (unsigned int) us;
    vvp->var_type = vp->var_type;
    break;
  case VAR_LONG:
#ifdef _LP64
    li = vvp->var_un.var_register;
    vvp->var_un.var_digit = (int) li;
    vvp->var_type = vp->var_type;
#endif
    break;
  case VAR_ULONG:
#ifdef _LP64
    uli = vvp->var_un.var_register;
    vvp->var_un.var_udigit = (int) uli;
    vvp->var_type = vp->var_type;
#endif
    break;
  case VAR_LONGLONG:
#ifndef _LP64
    i = vvp->var_un.var_register;
    vvp->var_un.var_ldigit = (T_LLONG) i;
    vvp->var_type = vp->var_type;
#endif
    break;
  case VAR_ULONGLONG:
#ifndef _LP64
    ui = vvp->var_un.var_register;
    vvp->var_un.var_ldigit = (T_ULLONG) ui;
    vvp->var_type = vp->var_type;
#endif
    break;
  case VAR_DOUBLE:
    if (vvp->var_type != VAR_DOUBLE) {
      d = (double) vvp->var_un.var_register;
      vvp->var_un.var_rdigit = d;
      vvp->var_type = vp->var_type;
    }
    break;
  }
}

static int
r_integrals(T_VARIABLE *left, T_VARIABLE *right, char *fn, int arg)
{
  /* if neither is a digit, then this check doesn't care */
  if (((left->var_type & VAR_NUMERIC) == 0) &&
      ((right->var_type & VAR_NUMERIC) == 0))
    return 0;

  /* if either is an array then the array checker will check */
  if ((left->var_dimension && (left->var_subscript == 0)) ||
      (right->var_dimension && (right->var_subscript == 0)))
    return 0;

  /* if both are numeric then it's ok */
  if ((left->var_type & VAR_NUMERIC) && (right->var_type & VAR_NUMERIC)) {

#if ANYONE_REALLY_CARED

    /* if right is bigger (and isn't a constant, since constants are LONGLONG)
       than left then there's precision loss */
    if (right->var_name && right->var_type > left->var_type) {
      if (arg)
        snprintf(error_buf, sizeof error_buf,
          "possible loss of precision in call: arg #%d: %s", arg, fn);
      else
        snprintf(error_buf, sizeof error_buf,
          "possible loss of precision in %s", fn);
      yyerror(error_buf, ERR_WARNING);
    }

#endif

    return 0;
  }

  /* one is, the other isn't. wrong. */
  return 1;
}

static int
r_arrays(T_VARIABLE *left, T_VARIABLE *right, char *fn, int arg)
{
  int left_is_array = (left->var_dimension != 0) && (left->var_subscript == 0);
  int left_is_dynamic = left->var_dimension == -1;
  int right_is_array =
    (right->var_dimension != 0) && (right->var_subscript == 0);
  int right_is_dynamic = right->var_dimension == -1;

  /* neither is an array, this check doesn't care */
  if (!left_is_array && !right_is_array)
    return 0;

  /* if left is array and right is not, then it must be strings */
  if (left_is_array && !right_is_array)
    if ((left->var_type == VAR_CHAR) && (right->var_type == VAR_STRING))
      return 0;
    else
      return 1;

  /* if right is array and left is not, then it must be strings */
  if (!left_is_array && right_is_array)
    if ((left->var_type == VAR_STRING) && (right->var_type == VAR_CHAR))
      return 0;
    else
      return 1;

  /* ok, they're both arrays */

  /* they must be the same type */
  if (left->var_type != right->var_type)
    return 1;

  /* both are not dynamic and the right is bigger than the left */
  if (!left_is_dynamic && !right_is_dynamic)
    if (right->var_dimension > left->var_dimension)
      return 1;

  return 0;
}

static int
r_users(T_VARIABLE *left, T_VARIABLE *right, char *fn, int arg)
{
  /* only checking user types here */
  if ((left->var_type != VAR_USER) && (right->var_type != VAR_USER))
    return 0;

  if ((left->var_type | right->var_type) != VAR_USER)
    return 1;

  return strcmp(left->var_struct->st_name, right->var_struct->st_name);
}

static void 
do_assign_check(T_VARIABLE *left, T_EXPR *ep, char *fn, int arg)
{
  T_VARIABLE *right = 0;
  T_VARIABLE var;
  static int (*rule_list[])(T_VARIABLE *, T_VARIABLE *, char *, int) = {
    r_integrals,  /* can't assign integral to non-integral, and vice-versa */
    r_arrays,     /* can't assign array to non-array, and vice-versa       */
    r_users,      /* can't assign user defined types of different types    */
    0
  };
  int (**rule)(T_VARIABLE *, T_VARIABLE *, char *, int);

  if (left == 0)
    goto clash;

  if (left->var_type == VAR_ELLIPSIS)
    return;

  switch(ep->e_type) {
  case E_VALUE:
  case E_INCRA:
  case E_INCRB:
  case E_DECRA:
  case E_DECRB:
  case E_LAZY_INCRA:
  case E_LAZY_INCRB:
  case E_LAZY_DECRA:
  case E_LAZY_DECRB:
    right = ep->e_variable;
    break;
  case E_CALL:
    if (ep->e_call->c_block)
      right = ep->e_call->c_block->b_return;
    break;
  case E_EXPRESSION:
  case E_QCOP:
    var = zero_variable;
    var.var_type = type_value(ep);
    if ((var.var_type & (VAR_USER | VAR_BOGUS)) == 0)
      right = &var;
    break;
  case E_ASSIGN:
    right = ep->e_assign->a_variable;
    break;
  }
  if (right == 0)
    goto clash;

  /* if a kvm var is assigned to, then we need write access to kvm */
  if ((left->var_flags & VF_SPECIAL) == VF_KVM)
    Se_kvm_open_flags = O_RDWR;

  /* for each rule */
  for(rule=rule_list; *rule; rule++)
    if ((*(*rule))(left, right, fn, arg))
      goto clash;

  /* make numeric constants in the expression be of the same type */
  if ((left->var_type & VAR_NUMERIC) && ep)
    do_digit_checks(left, ep);

  return;

clash:
  if (arg)
    snprintf(error_buf, sizeof error_buf,
      "argument type mismatch: arg #%d: %s", arg, fn);
  else
    snprintf(error_buf, sizeof error_buf, "%s type mismatch", fn);
  yyerror(error_buf, ERR_NONFATAL);
}

#if it_wasnt_fucking_broken

/* for notification of errors */
#define KVM_TOLDEM       1
#define KSTAT_TOLDEM     2
#define MIB_TOLDEM       4

static void 
do_assign_check(T_VARIABLE *left, T_EXPR *ep, char *fn, int arg)
{
  int done = 0;
  int clash = 0;
  static int told_em = 0;
  T_VARIABLE *right = 0;
  T_VARIABLE var;

  if (left == 0)
    clash = 1;
  else if (left->var_type == VAR_ELLIPSIS)
    return;
  switch(ep->e_type) {
  case E_VALUE:
  case E_INCRA:
  case E_INCRB:
  case E_DECRA:
  case E_DECRB:
  case E_LAZY_INCRA:
  case E_LAZY_INCRB:
  case E_LAZY_DECRA:
  case E_LAZY_DECRB:
    right = ep->e_variable;
    break;
  case E_CALL:
    if (ep->e_call->c_block)
      right = ep->e_call->c_block->b_return;
    break;
  case E_EXPRESSION:
  case E_QCOP:
    var = zero_variable;
    var.var_type = type_value(ep);
    if ((var.var_type & (VAR_USER | VAR_BOGUS)) == 0)
      right = &var;
    break;
  case E_ASSIGN:
    right = ep->e_assign->a_variable;
    break;
  }
  if (right == 0)
    clash = 1;

  /* do special variable checking */
  if (clash == 0) {
    switch(left->var_flags & VF_SPECIAL) {
    case VF_KVM:
#if CHECK_ACCESS_DURING_PARSE
      if (((told_em & KVM_TOLDEM) == 0) &&
          ((Se_flags & SE_SYNTAX) == 0) &&
          ((getegid() != 3) && (geteuid() != 0))) {
        yyerror("insufficient privilege to modify kvm variables", ERR_NONFATAL);
        told_em |= KVM_TOLDEM;
      }
#endif
      Se_kvm_open_flags = O_RDWR;
      break;
    case VF_KSTAT:
#if CHECK_ACCESS_DURING_PARSE
      if (strcmp(left->var_name, NAME_NAME) &&
          strcmp(left->var_name, NUMBER_NAME) &&
         ((told_em & KSTAT_TOLDEM) == 0) &&
         ((Se_flags & SE_SYNTAX) == 0) &&
         (geteuid() != 0)) {
        yyerror("must be super-user to modify kstat variables", ERR_NONFATAL);
        told_em |= KSTAT_TOLDEM;
      }
#endif
      break;
    case VF_MIB:
#if CHECK_ACCESS_DURING_PARSE
      if (((told_em & MIB_TOLDEM) == 0) && ((Se_flags & SE_SYNTAX) == 0)) {
        yyerror("mib variables are read-only", ERR_WARNING);
        told_em |= MIB_TOLDEM;
      }
#endif
      break;
    default:
      break;
    }
  }

  if (clash == 0) {
    /* if left is an array then */
    if (left->var_dimension && (left->var_subscript == 0)) {
      switch(left->var_type) {
      case VAR_CHAR:
        /* left side is a character array */
        switch(right->var_type) {
        case VAR_STRING:
          /* if right is a constant then */
          if (right->var_name == 0)
            /* but right is not a function call or the value "nil" */
            if ((ep->e_type != E_CALL) && right->var_un.var_string)
              /* if the length of the constant is > the size of left then */
              if (strlen(right->var_un.var_string) >
                  (size_t) left->var_dimension)
                clash = 1;
          done = 1;
          break;
        default:
          /* if left size is not equal to right size then */
          if (((left->var_dimension != right->var_dimension) &&
               (left->var_dimension != -1) && (right->var_dimension != -1)) ||
              (left->var_subscript && (right->var_subscript == 0)) ||
             ((left->var_subscript == 0) && right->var_subscript))
            clash = 1;
          break;
        }
        break;
      default:
        /* if left size is not equal to right size then */
        if (((left->var_dimension != right->var_dimension) &&
             (left->var_dimension != -1) && (right->var_dimension != -1)) ||
            (left->var_subscript && (right->var_subscript == 0)) ||
           ((left->var_subscript == 0) && right->var_subscript))
          clash = 1;
        break;
      }
    /* if the left is a string */
    } else if (left->var_type == VAR_STRING) {
      switch(right->var_type) {
      case VAR_CHAR:
        /* if the right is not an array then */
        if ((right->var_dimension == 0) || right->var_subscript)
          clash = 1;
        done = 1;
        break;
      case VAR_STRING:
        /* if the right is an array then */
        if (right->var_dimension && (right->var_subscript == 0))
          clash = 1;
        done = 1;
        break;
      default:
        clash = 1;
        break;
      }
    /* if the right is an array then */
    } else if (right->var_dimension && (right->var_subscript == 0)) {
      switch(right->var_type) {
      case VAR_CHAR:
        switch(left->var_type) {
        case VAR_STRING:
          done = 1;
          break;
        default:
          clash = 1;
          break;
        }
        break;
      default:
        /* if left is array and right is not or left is not and right is... */
        if ((left->var_dimension && (right->var_dimension == 0)) ||
           ((left->var_dimension == 0) && right->var_dimension))
          clash = 1;

        if (((left->var_dimension != right->var_dimension) &&
             (left->var_dimension != -1) && (right->var_dimension != -1)) ||
            (left->var_subscript && (right->var_subscript == 0)) ||
           ((left->var_subscript == 0) && right->var_subscript))
          clash = 1;
        break;
      }
    }
  }

  if ((clash == 0) && (done == 0)) {
    if (left->var_type & VAR_NUMERIC) {
      if (ep) {
        do_digit_checks(left, ep);
        if ((right->var_type & VAR_NUMERIC) == 0)
          clash = 1;
      }
    } else if (left->var_type == VAR_USER) {
      if (right->var_type != VAR_USER)
        clash = 1;
      else if (strcmp(left->var_struct->st_name, right->var_struct->st_name))
        clash = 1;
    }
  }

  if (clash) {
    if (arg)
      snprintf(error_buf, sizeof error_buf,
        "argument type mismatch: arg #%d: %s", arg, fn);
    else
      snprintf(error_buf, sizeof error_buf, "%s type mismatch", fn);
    yyerror(error_buf, ERR_NONFATAL);
  }
}

#endif

static void
do_switch_check(T_SWITCH *sp)
{
  char *p;
  T_VARTYPE switch_type;
  T_VARTYPE case_type;
  T_CASE *cp;
  T_CASE *ccp;
  T_CASE *default_case = 0;
  T_STATEMENT *stp;
  T_BREAK *bp;
  avlhdr *cases;
  anode *anp;

  switch_type = type_value(sp->sw_expr);
  if (switch_type & (VAR_DOUBLE|VAR_USER)) {
    yyerror("non-integral switch expression", ERR_NONFATAL);
    return;
  }
#ifndef _LP64
  if (switch_type & (VAR_LONGLONG|VAR_ULONGLONG)) {
    yyerror("switching on longlong or ulonglong not supported", ERR_NONFATAL);
    return;
  }
#endif

  /* link breaks back to the switch statement */
  for(bp=break_list; bp; bp=bp->brk_next) {
    bp->brk_type = BRK_SWITCH;
    bp->brk_un.brk_switch = sp;
  }

  cases = avlinit();
  if (cases == 0)
    yyerror("out of memory", ERR_FATAL);

  /* either string or int */
  if (switch_type != VAR_STRING)
    cases->ah_cmp = AVC_INT;

  for(cp=sp->sw_case_list; cp; cp=cp->ca_next) {
    /* not the default case */
    if (cp->ca_value) {
      /* the case type can only be VAR_STRING, VAR_CONSTANT, or VAR_DOUBLE */
      case_type = cp->ca_value->var_type;
      if (case_type == VAR_DOUBLE) {
        case_error(cp, "non-integral case expression");
        continue;
      }
      /* we're down to VAR_STRING and VAR_CONSTANT */
      if (case_type == VAR_CONSTANT) {
        if ((switch_type & VAR_INTEGRAL) == 0) {
          case_error(cp, "switch/case type mismatch");
          continue;
        }
      } else {
        if (switch_type != VAR_STRING) {
          case_error(cp, "switch/case type mismatch");
          continue;
        }
      }
    } else {
      if (default_case == 0)
        default_case = cp;
      else
        case_error(cp, "duplicate default in switch");
    }
  }

  /* for each case statement */
  for(cp=sp->sw_case_list; cp; cp=cp->ca_next) {

    if (cp->ca_statements)
      /* mark it as having statements */
      cp->ca_flags |= CA_STATEMENTS;

    /* find the first case that has statements */
    for(ccp=cp->ca_next; ccp; ccp=ccp->ca_next) {
      if (ccp->ca_statements) {

        /* if the source case has statements */
        if (cp->ca_statements) {


          /* find the last statement */
          for(stp=cp->ca_statements; stp->s_next; stp=stp->s_next)
            ;

          /* and link it to the target case's statements */
          stp->s_next = ccp->ca_statements;

        } else {  /* otherwise, make the target's statements the sources's */
          cp->ca_statements = ccp->ca_statements;
        }
        break;   /* found the case with statements, stop searching */
      }
    }

    /* put statement lists into case tree for non-default cases */
    if (cp->ca_value) {
      p = cp->ca_value->var_un.var_string;
      if ((switch_type == VAR_STRING) && (p == 0))
        p = NIL_VALUE;
      switch(avlinsert(cases, p, cp->ca_statements, &anp)) {
      case AVL_INSERT:
        break;
      case AVL_THERE:
        case_error(cp, "duplicate case in switch");
        continue;
      case AVL_NOMEM:
        yyerror("out of memory", ERR_FATAL);
        break;
      }
    }
  }

  sp->sw_cases = cases;
  sp->sw_default = default_case;
}

static void
do_for_check(T_FOR *fp)
{
  T_BREAK *bp;
  T_CONTINUE *cp;

  /* link breaks back to the for statement */
  for(bp=break_list; bp; bp=bp->brk_next) {
    bp->brk_type = BRK_FOR;
    bp->brk_un.brk_for = fp;
  }
  for(cp=continue_list; cp; cp=cp->con_next) {
    cp->con_type = CON_FOR;
    cp->con_un.con_for = fp;
  }
}

static void
do_do_check(T_DO *dp)
{
  T_BREAK *bp;
  T_CONTINUE *cp;

  /* link breaks back to the while statement */
  for(bp=break_list; bp; bp=bp->brk_next) {
    bp->brk_type = BRK_DO;
    bp->brk_un.brk_do = dp;
  }
  for(cp=continue_list; cp; cp=cp->con_next) {
    cp->con_type = CON_DO;
    cp->con_un.con_do = dp;
  }
}

static void
do_while_check(T_WHILE *wp)
{
  T_BREAK *bp;
  T_CONTINUE *cp;

  /* link breaks back to the while statement */
  for(bp=break_list; bp; bp=bp->brk_next) {
    bp->brk_type = BRK_WHILE;
    bp->brk_un.brk_while = wp;
  }
  for(cp=continue_list; cp; cp=cp->con_next) {
    cp->con_type = CON_WHILE;
    cp->con_un.con_while = wp;
  }
}

static void 
do_special_check(char *name, T_VARIABLE *vp)
{
  static int told_em = 0;
  char *p;

  if (strncmp(name, KVM_PREFIX, KVM_PREFIX_LEN) == 0) {
    vp->var_flags |= VF_KVM;
    Se_kvm_var_count++;
    member_inherit(vp, VF_KVM);
#if CHECK_ACCESS_DURING_PARSE
    if ((told_em == 0) && ((Se_flags & SE_SYNTAX) == 0) &&
        (getegid() != 3) && (geteuid() != 0)) {
      yyerror("insufficient privilege to access kvm variables", ERR_NONFATAL);
      told_em = 1;
    }
#endif
    Se_kvm_open_flags = O_RDONLY;
  } else if (strncmp(name, KSTAT_PREFIX, KSTAT_PREFIX_LEN) == 0) {
    vp->var_flags |= VF_KSTAT;
    Se_kstat_var_count++;
    member_inherit(vp, VF_KSTAT);
  } else if (strncmp(name, MIB_PREFIX, MIB_PREFIX_LEN) == 0) {
    vp->var_flags |= VF_MIB;
    Se_mib_var_count++;
    member_inherit(vp, VF_MIB);
  } else if (strncmp(name, NDD_PREFIX, NDD_PREFIX_LEN) == 0) {
    vp->var_flags |= VF_NDD;
    member_inherit(vp, VF_NDD);
  } else if (get_special_name(name)) {
    if (vp->var_struct && vp->var_struct->st_class) {
      p = vp->var_struct->st_class->b_name;
      if (strncmp(name, p, strlen(p))) {
        snprintf(error_buf, sizeof error_buf,
          "incorrect special class prefix for class %s, use %s",
                vp->var_struct->st_name, p);
        yyerror(error_buf, ERR_NONFATAL);
      }
    }
    vp->var_flags |= VF_CLASS;
    member_inherit(vp, VF_CLASS);
  } else
    member_inherit(vp, (T_VFTYPE) 0);
}

/* We compute the offsets for this structure only here.  The offsets for  *
 * members inside of structures that may be the members of this structure *
 * are computed elsewhere.                                                */

static void 
do_structure_check(T_STRUCT *sp)
{
  T_VARIABLE *vp;
  T_VARIABLE *vvp;
  int size = 0;
  int m;
  int n;
  int do_pad = 0;

  /* assign offsets and compute structure size */
  for (vp = sp->st_members; vp; vp = vp->var_next) {
    n = Se_type_sizes[vp->var_type];
    if (n == -1) {
      /* this member is a structure, pad offset to register size */
      if (size % sizeof(T_REGISTER))
        size += (sizeof(T_REGISTER) - (size % sizeof(T_REGISTER)));
      n = vp->var_struct->st_size;
      for(vvp=vp->var_struct->st_members; vvp; vvp=vvp->var_next) {
        /* hunt through the structure and see if it has anything in it other *
         * than a char type.  If it does, it gets padded.                    */
        if (vvp->var_type != VAR_USER) {
          if ((m = Se_type_sizes[vvp->var_type]) > 1) {
            if (size % m)
              size += (m - (size % m));
            do_pad = 1;
          }
          break;
        }
      }
    } else {
      if (n > 1) {
        if (size % n)
          size += (n - (size % n));
        do_pad = 1;
      }
    }
    if (vp->var_dimension)
      n *= vp->var_dimension;
    vp->var_offset = size;
    vp->var_flags |= VF_MEMBER;
    size += n;
  }
  if ((do_pad) && (size % sizeof(T_REGISTER)))
    size += (sizeof(T_REGISTER) - (size % sizeof(T_REGISTER)));
  sp->st_size = size;
}

static void
do_member_check(T_VARIABLE *left, T_VARIABLE *right)
{
  void *array;
  int i;
  int n;
  T_VARIABLE *rp;
  T_VARIABLE subv;
  T_EXPR sub;
  T_EXPR e;

  if (left->var_type == VAR_USER) {
    do_aggregate_check(left, right);
    return;
  }
  /* array of simple types */
  if (left->var_dimension) {
    switch(right->var_type) {
    case VAR_USER:
      break;
    case VAR_STRING:
      /* char hello[6] = "hello"; */
      if (left->var_type == VAR_CHAR) {
        if (right->var_un.var_string == 0) {
          yyerror("illegal initializer", ERR_NONFATAL);
          return;
        }
        if (strlen(right->var_un.var_string) > (size_t) left->var_dimension) {
          yyerror("initializer does not fit", ERR_NONFATAL);
          return;
        }
        goto exceptional_case;
      }
      /* else fall through */
    default:
      yyerror("initialization type mismatch", ERR_NONFATAL);
      return;
    }
    /* dummy subscript constant */
    subv = zero_variable;
    subv.var_type = VAR_LONG;

    /* dummy subscript expression */
    sub = zero_expr;
    sub.e_type = E_VALUE;
    sub.e_variable = &subv;

    /* set it up */
    left->var_subscript = &sub;

    /* dummy expression */
    e = zero_expr;
    e.e_type = E_VALUE;

    /* members of aggregate */
    rp = right->var_struct->st_members;

    /* aggregate assignment to not-yet-new'ed var */
    if (left->var_dimension == -1) {
      T_VARIABLE *xp;

      for(n=0, xp=rp; xp; xp=xp->var_next, n++)
        ;
    } else
      n = left->var_dimension;
    for(i=0; (i<n) && rp; rp=rp->var_next, i++) {
      subv.var_un.var_digit = i;
      e.e_variable = rp;
      do_assign_check(left, &e, "initialization", 0);
      if (Se_errors == 0)
        se_run_assign(left, &e);
    }
    /* return to normal */
    left->var_subscript = 0;

    if (rp)
      yyerror("too many array initializers", ERR_NONFATAL);

    return;
  }

exceptional_case:

  /* dummy expression */
  e = zero_expr;
  e.e_type = E_VALUE;
  e.e_variable = right;
  do_assign_check(left, &e, "initialization", 0);
  if (Se_errors == 0)
    se_run_assign(left, &e);
}

static void
do_aggregate_check(T_VARIABLE *left, T_VARIABLE *right)
{
  int i;
  T_STRUCT **lpp;
  T_VARIABLE *rpp;
  T_VARIABLE *lp;
  T_VARIABLE *rp;

  /* an array of simple types */
  if (left->var_type != VAR_USER) {
    do_member_check(left, right);
    return;
  }
  /* an array of structures */
  if (left->var_dimension) {
    lpp = (T_STRUCT **) left->var_un.var_array;
    rpp = right->var_struct->st_members;
    if (rpp->var_type != VAR_USER) {
      yyerror("initialization type mismatch", ERR_NONFATAL);
      return;
    }
    for(i=0; (i<left->var_dimension) && rpp; i++, rpp=rpp->var_next) {
      lp = lpp[i]->st_members;
      rp = rpp->var_struct->st_members;
      for(; lp && rp; lp=lp->var_next, rp=rp->var_next)
        do_member_check(lp, rp);
    }
    if (rpp)
      yyerror("too many struct initializers", ERR_NONFATAL);
    return;
  }
  lp = left->var_un.var_user->st_members;
  rp = right->var_struct->st_members;
  for(; lp && rp; lp=lp->var_next, rp=rp->var_next)
    do_member_check(lp, rp);
}

static void
free_aggregate(T_VARIABLE *vp)
{
  T_VARIABLE *xp;
  T_VARIABLE *next;

  if (vp->var_type != VAR_USER)
    return;
  se_free(vp->var_name);
  for(xp=vp->var_struct->st_members; xp; xp=next) {
    next = xp->var_next;
    switch(xp->var_type) {
    case VAR_STRING:
      se_free(xp->var_un.var_string);
      break;
    case VAR_USER:
      free_aggregate(xp);
      continue; /* xp already free from recursive call */
    default:
      break;
    }
    se_free(xp);
  }
  se_free(vp);
}

static void
do_param_check(T_FCALL *cp)
{
  int i;
  int n;
  int ellipsis = 0;
  T_VARIABLE *vp;
  T_EXPR *ep;

  n = Lex_line_no;
  for(vp=cp->c_block->b_parameters; vp && vp->var_next; vp=vp->var_next)
    ;
  if (vp && (vp->var_type == VAR_ELLIPSIS))
    ellipsis = 1;
  Lex_line_no = cp->c_line_no;
  if ((ellipsis == 0) && (cp->c_arg_count != cp->c_block->b_param_count)) {
    snprintf(error_buf, sizeof error_buf,
      "function: %s expects %d parameter%s, %d sent",
      cp->c_name, cp->c_block->b_param_count,
      (cp->c_block->b_param_count != 1) ? "s" : "", cp->c_arg_count);
    yyerror(error_buf, ERR_NONFATAL);
    Lex_line_no = n;
    return;
  }
  vp = cp->c_block->b_parameters;
  ep = cp->c_args;
  for(i=1; ep && vp; vp=vp->var_next, ep=ep->e_next, i++)
    do_assign_check(vp, ep, cp->c_name, i);
  Lex_line_no = n;
}

static void
do_main_check(T_BLOCK *bp)
{
  T_VARIABLE *vp = bp->b_parameters;
  int error = 0;

  if (vp) {
    if ((vp->var_type != VAR_LONG) || vp->var_dimension)
      error = 1;
    else {
      vp = vp->var_next;
      if (vp && ((vp->var_type != VAR_STRING) || (vp->var_dimension == 0)))
        error = 2;
      if (vp->var_next)
        yyerror("function: main accepts only 2 parameters\n", ERR_WARNING);
    }
    if (error) {
      snprintf(error_buf, sizeof error_buf,
        "argument type mismatch: arg #%d: main", error);
      yyerror(error_buf, ERR_NONFATAL);
    }
  }
  if (bp->b_return && bp->b_return->var_type != VAR_LONG)
    yyerror("main must have a return type of int", ERR_NONFATAL);
}

static void
do_return_check(T_VARIABLE *vp, T_RETURN *rp)
{
  int n;

  n = Lex_line_no;
  Lex_line_no = rp->ret_line_no;
  if (rp->ret_expr == 0) {
    snprintf(error_buf, sizeof error_buf,
      "function expects to return value: %s",
            rp->ret_block->b_name);
    yyerror(error_buf, ERR_NONFATAL);
  } else
    do_assign_check(vp, rp->ret_expr, "return value", 0);
  Lex_line_no = n;
}

static void
do_long_arg_check(char *fn, T_EXPR *args, int arg)
{
  T_VARIABLE var;

  if (args == 0)
    return;
  var = zero_variable;
  var.var_type = VAR_REGISTER;
  do_assign_check(&var, args, fn, arg);
}

static void
do_int_arg_check(char *fn, T_EXPR *args, int arg)
{
  T_VARIABLE var;

  if (args == 0)
    return;
  var = zero_variable;
  var.var_type = VAR_LONG;
  do_assign_check(&var, args, fn, arg);
}

static void
do_dbl_arg_check(char *fn, T_EXPR *args, int arg)
{
  T_VARIABLE var;

  if (args == 0)
    return;
  var = zero_variable;
  var.var_type = VAR_DOUBLE;
  do_assign_check(&var, args, fn, arg);
}

static void
do_long_check(char *fn, T_EXPR *args)
{
  do_long_arg_check(fn, args, 1);
}

static void
do_dbl_check(char *fn, T_EXPR *args)
{
  do_dbl_arg_check(fn, args, 1);
}

static void
do_2dbl_check(char *fn, T_EXPR *args)
{
  do_dbl_arg_check(fn, args, 1);
  if (args->e_next)
    do_dbl_arg_check(fn, args->e_next, 2);
}

static void
do_dbl_long_check(char *fn, T_EXPR *args)
{
  do_dbl_arg_check(fn, args, 1);
  if (args->e_next)
    do_long_arg_check(fn, args->e_next, 2);
}

static void
do_long_dbl_check(char *fn, T_EXPR *args)
{
  do_long_arg_check(fn, args, 1);
  if (args->e_next)
    do_dbl_arg_check(fn, args->e_next, 2);
}

static void
do_string_arg_check(char *fn, T_EXPR *args, int arg)
{
  T_VARIABLE var;

  if (args == 0)
    return;
  var = zero_variable;
  var.var_type = VAR_STRING;
  do_assign_check(&var, args, fn, arg);
}

static void
do_string_check(char *fn, T_EXPR *args)
{
  do_string_arg_check(fn, args, 1);
}

static void
do_refresh_check(char *fn, T_EXPR *args)
{
  int flags;
  T_VARIABLE *vp;

  /* must be a variable and not a constant */
  if ((args->e_type != E_VALUE) || (args->e_variable == 0)) {
    yyerror("argument type mismatch: arg #1: refresh$", ERR_NONFATAL);
    return;
  }
  vp = args->e_variable;
  if ((vp->var_type == VAR_USER) &&
      (vp->var_un.var_user->st_class != 0) &&
      (vp->var_dimension != 0)) {
    yyerror("arrays of active class variables not allowed", ERR_NONFATAL);
    return;
  }
  if (vp->var_special == SS_KVM) {
    Se_kvm_var_count++;
    return;
  }

  /* if it's not kvm, then it's a structure. */
  flags = (int) (vp->var_struct->st_flags & (SF_KSTAT|SF_MIB|SF_NDD));
  switch(flags) {
  case SF_KSTAT:
    Se_kstat_var_count++;
    vp->var_special = SS_KSTAT;
    break;
  case SF_NDD:
    vp->var_special = SS_NDD;
    break;
  case SF_MIB:
    vp->var_special = SS_MIB;
    Se_mib_var_count++;
    break;
  default:
    break;
  }
}

static void
do_printf_check(char *fn, T_EXPR *args)
{
  int i;
  T_VARIABLE *vp;
  T_VARIABLE var;
  T_EXPR *ep;

  if (args == 0)
    return;

  var = zero_variable;
  var.var_type = VAR_STRING;
  do_assign_check(&var, args, fn, 1);

  /* check the other args for nonsense */
  for(i=1, ep=args->e_next; ep; ep=ep->e_next, i++) {
    switch(ep->e_type) {
    case E_VALUE:
    case E_INCRA:
    case E_INCRB:
    case E_DECRA:
    case E_DECRB:
    case E_LAZY_INCRA:
    case E_LAZY_INCRB:
    case E_LAZY_DECRA:
    case E_LAZY_DECRB:
      vp = ep->e_variable;
      break;
    case E_QCOP:
      var.var_type = type_value(ep->e_left);
      vp = &var;
      break;
    case E_CALL:
      if (ep->e_call->c_block)
        vp = ep->e_call->c_block->b_return;
      else
        vp = 0;
      break;
    case E_ASSIGN:
      vp = ep->e_assign->a_variable;
      break;
    default:
      continue;
    }
    if ((vp == 0) || ((vp->var_type == VAR_USER) ||
                      (vp->var_dimension &&
                      (vp->var_subscript == 0) && vp->var_type != VAR_CHAR))) {
      snprintf(error_buf, sizeof error_buf,
        "argument type mismatch: arg #%d: %s", i+1, fn);
      yyerror(error_buf, ERR_NONFATAL);
    }
  }
}

static void
do_qsort_check(char *fn, T_EXPR *args)
{
  if (args == 0)
    return;
  do_long_arg_check(fn, args, 1);
  args = args->e_next;
  if (args) {
    do_long_arg_check(fn, args, 2);
    args = args->e_next;
    if (args) {
      do_long_arg_check(fn, args, 3);
      args = args->e_next;
      if (args)
        do_string_arg_check(fn, args, 4);
    }
  }
}

static void
do_bsearch_check(char *fn, T_EXPR *args)
{
  if (args == 0)
    return;
  do_long_arg_check(fn, args, 1);
  args = args->e_next;
  if (args) {
    do_long_arg_check(fn, args, 2);
    args = args->e_next;
    if (args) {
      do_long_arg_check(fn, args, 3);
      args = args->e_next;
      if (args) {
        do_long_arg_check(fn, args, 4);
        args = args->e_next;
        if (args)
          do_string_arg_check(fn, args, 5);
      }
    }
  }
}

static void
do_fprintf_check(char *fn, T_EXPR *args)
{
  if (args == 0)
    return;
  do_long_arg_check(fn, args, 1);
  if (args->e_next == 0) {
    snprintf(error_buf, sizeof error_buf, "insufficent arguments to %s", fn);
    yyerror(error_buf, ERR_NONFATAL);
    return;
  }
  do_printf_check(fn, args->e_next);
}

static void
do_syslog_check(char *fn, T_EXPR *args)
{
  if (args == 0)
    return;
  do_int_arg_check(fn, args, 1);
  if (args->e_next == 0) {
    snprintf(error_buf, sizeof error_buf, "insufficent arguments to %s", fn);
    yyerror(error_buf, ERR_NONFATAL);
    return;
  }
  do_printf_check(fn, args->e_next);
}

static void
do_signal_check(char *fn, T_EXPR *args)
{
  if (args == 0)
    return;
  do_long_arg_check(fn, args, 1);
  args = args->e_next;
  if (args)
    do_string_arg_check(fn, args, 2);
}

static void
do_sizeof_check (char *fn, T_EXPR *args)
{
  T_VARIABLE var;
  T_BLOCK *bp;

  if (args == 0)
    return;
  switch(args->e_type) {
  case E_CALL:
    bp = args->e_call->c_block;
    if ((bp == 0) || (bp->b_return == 0)) {
      yyerror("cannot take sizeof void", ERR_NONFATAL);
      return;
    }
    break;
  case E_VALUE:
  case E_INCRA:
  case E_INCRB:
  case E_DECRA:
  case E_DECRB:
  case E_LAZY_INCRA:
  case E_LAZY_INCRB:
  case E_LAZY_DECRA:
  case E_LAZY_DECRB:
    if (args->e_variable && (Se_type_sizes[args->e_variable->var_type] == -2))
      yyerror("internal error", ERR_FATAL);
    break;
  case E_EXPRESSION:
  case E_QCOP:
  case E_ASSIGN:
    /* it's silly, but hey */
    break;
  }
}

static void
do_kvm_cvt_check(char *fn, T_EXPR *args)
{
  if (args == 0)
    return;
  if ((args->e_type != E_VALUE) ||
      (args->e_variable == 0) ||
      (args->e_variable->var_name == 0) ||
      (strncmp(args->e_variable->var_name, KVM_PREFIX, KVM_PREFIX_LEN) &&
      (args->e_variable->var_special != SS_KVM))) {
    snprintf(error_buf, sizeof error_buf,
      "%s must take kvm variable as arg #1", fn);
    yyerror(error_buf, ERR_NONFATAL);
  }
  if (args->e_next)
    do_long_arg_check(fn, args->e_next, 2);
}

static void
do_kvm_addr_check(char *fn, T_EXPR *args)
{
  if (args == 0)
    return;
  if ((args->e_type != E_VALUE) ||
      (args->e_variable == 0) ||
      (args->e_variable->var_name == 0) ||
      (strncmp(args->e_variable->var_name, KVM_PREFIX, KVM_PREFIX_LEN) &&
      (args->e_variable->var_special != SS_KVM))) {
    snprintf(error_buf, sizeof error_buf,
      "%s must take kvm variable as arg #1", fn);
    yyerror(error_buf, ERR_NONFATAL);
  }
}

static void
do_str_fill_check(char *fn, T_EXPR *args)
{
  if (args == 0)
    return;
  if ((args->e_type != E_VALUE) ||
      (args->e_variable == 0) ||
      (args->e_variable->var_type != VAR_USER)) {
    snprintf(error_buf, sizeof error_buf,
      "%s requires a struct variable as arg# 1", fn);
    yyerror(error_buf, ERR_NONFATAL);
  }
  if (args->e_next)
    do_long_arg_check(fn, args->e_next, 2);
}

static void
do_builtin_check(T_BMAP *bp, T_VARIABLE *vp, T_FCALL *cp, T_EXPR *ep, int sent)
{
  T_STRUCT *sp;
  T_VARIABLE var;
  int n = bp->bm_param_count;

  if ((n != -1) && (n != sent)) {
    snprintf(error_buf, sizeof error_buf,
      "builtin: %s expects %d parameter%s, %d sent",
      bp->bm_name, bp->bm_param_count, (n != 1) ? "s" : "", sent);
    yyerror(error_buf, ERR_NONFATAL);
  }
  if (bp->bm_return_type) {
    cp->c_block = NEW(T_BLOCK);
    if (bp->bm_return_type == VAR_USER) {
      sp = (T_STRUCT *) get_symbol(SYM_STRUCT, bp->bm_user_type);
      if (sp == 0) {
        snprintf(error_buf, sizeof error_buf,
          "undefined user type: struct %s", bp->bm_user_type);
        yyerror(error_buf, ERR_NONFATAL);
      } else if (vp) {
        /* prototype passed in, possibly lazy value of array of structs */
        cp->c_block->b_return = new_variable(vp);
      } else {
        var = zero_variable;
        var.var_type = VAR_USER;
        var.var_struct = sp;
        cp->c_block->b_return = new_variable(&var);
      }
      fix_offsets(cp->c_block->b_return->var_un.var_user, 0, 0);
    } else {
      if (vp)
        cp->c_block->b_return = new_variable(vp);
      else {
        cp->c_block->b_return = NEW(T_VARIABLE);
        cp->c_block->b_return->var_type = bp->bm_return_type;
      }
    }
  }
  if (bp->bm_check)
    (*bp->bm_check)(bp->bm_name, ep);
}

static void
do_compound_check(T_VARIABLE *vp, T_EXPR *ep, char *op)
{
  T_EXPR expr;

  expr = zero_expr;
  expr.e_type = E_VALUE;
  expr.e_variable = vp;
  expr_clash_check(&expr, ep, op);
  do_assign_check(vp, ep, "assignment", 0);
}

static void
do_lazy_value(T_EXPR *re, T_VARIABLE *vp)
{
  T_FCALL *cp;
  T_EXPR *ep;
  T_BMAP bp;

  /* spoof this to a call */
  re->e_type = E_CALL;

  /* build the arg list with the member in it */
  ep = NEW(T_EXPR);
  ep->e_type = E_VALUE;
  ep->e_variable = vp;

  /* build the call with the arg list */
  cp = NEW(T_FCALL);
  cp->c_name = "se_lazy_value";
  cp->c_line_no = Lex_line_no;
  cp->c_builtin = Se_functions[S_LAZY_VALUE];
  cp->c_args = ep;
  cp->c_arg_count = 1;

  /* put it into the expr */
  re->e_call = cp;

  /* spoof a builtin to build the return value */
  bp.bm_name = cp->c_name;
  bp.bm_stype = 0;
  bp.bm_param_count = 1;
  bp.bm_return_type = vp->var_type;
  if (bp.bm_return_type == VAR_USER)
    bp.bm_user_type = vp->var_struct->st_name;
  bp.bm_check = 0;
  do_builtin_check(&bp, vp, cp, ep, 1);
}

static T_STATEMENT *
do_lazy_lvalue(T_STATEMENT *sp)
{
  T_VARIABLE *vp;
  T_EXPR *ep;
  T_FCALL *cp;
  T_STATEMENT *ssp;

  /* totally fake this */
  vp = NEW(T_VARIABLE);
  vp->var_type = VAR_REGISTER;
  vp->var_un.var_register = (T_REGISTER) sp;

  /* build the arg list with the member in it */
  ep = NEW(T_EXPR);
  ep->e_type = E_VALUE;
  ep->e_variable = vp;

  /* build the call with the arg list */
  cp = NEW(T_FCALL);
  cp->c_name = "se_lazy_lvalue";
  cp->c_line_no = Lex_line_no;
  cp->c_builtin = Se_functions[S_LAZY_LVALUE];
  cp->c_args = ep;
  cp->c_arg_count = 1;

  /* different statement */
  ssp = NEW(T_STATEMENT);
  ssp->s_type = S_CALL;
  ssp->s_un.s_call = cp;
  ssp->s_function = Se_functions[S_CALL];

  return ssp;
}

static int
try_to_attach(void *handle, char *lib, T_BLOCK *attach_list, int last_try)
{
  T_BLOCK *bp;
  int not_found = 0;

  for(bp = attach_list; bp; bp = bp->b_next) {
    bp->b_attachment = (void *(*)(T_REGISTER, ...)) dlsym(handle, bp->b_name);
    if (bp->b_attachment == 0) {
      not_found++;
      if (last_try) {
        snprintf(error_buf, sizeof error_buf,
          "cannot find: %s in library: %s", bp->b_name, lib);
        yyerror(error_buf, ERR_NONFATAL);
      }
    }
  }
  return not_found;
}

char *
se_basedir(char *cmd, int first)
{
  static char path[BUFSIZ];
  static char *tmp;
  static char *p;

  if (first && strchr(cmd, '/')) {
    p = strcpy(path, cmd);
    *strrchr(path, '/') = '\0';
  } else {
    if (first) {
      se_new_string(&tmp, getenv("PATH"));
      p = strtok(tmp, ":");
    } else
      p = strtok(0, ":");
    for(; p; p=strtok(0, ":")) {
      snprintf(path, sizeof path, "%s/%s", p, cmd);
      if (access(path, F_OK) == 0)
        break;
    }
    if (p == 0) {
      if (tmp) {
        se_free(tmp);
        tmp = 0;
      }
    }
  }
  return p;
}

static char *
canonicalize_lib(char *lib)
{
  static char path[BUFSIZ];
  static char processor[32];
  char *p;
  char *tmp;
  int first;

  /* ahh what the hey, let's see if it's actually where I'd like it to be */
  if (processor[0] == '\0')
#ifdef _LP64
# ifdef SI_ARCHITECTURE_64
    sysinfo(SI_ARCHITECTURE_64, processor, sizeof processor);
# else
    strcpy(processor, "sparcv9");
# endif
#else
    sysinfo(SI_ARCHITECTURE, processor, sizeof processor);
#endif
  snprintf(path, sizeof path, DEFAULT_SE_LIB "/%s/%s", processor, lib);
  if (access(path, F_OK) == 0)
    return path;
  snprintf(path, sizeof path, DEFAULT_SE_LIB "/%s", lib);
  if (access(path, F_OK) == 0)
    return path;
  p = getenv("LD_LIBRARY_PATH");
  if (p) {
    tmp = se_string_save(p);
    for(p=strtok(tmp, ":"); p; p=strtok(0, ":")) {
      snprintf(path, sizeof path, "%s/%s", p, lib);
      if (access(path, F_OK) == 0) {
        p = path;
        break;
      }
    }
    free(tmp);
    if (p)
      return p;
  }
  /* not in LD_LIBRARY_PATH, maybe SE isn't installed in /opt/RICHPse */
  for(first = 1;; first = 0) {
    p = se_basedir(Se_programName, first);
    if (p == 0)
      break;
    snprintf(path, sizeof path, "%s/../lib/%s/%s", p, processor, lib);
    if (access(path, F_OK) == 0)
      return path;
  }
  return lib;
}

static void
do_attach_check(char *lib, T_BLOCK *attach_list)
{
  static void *my_handle = 0;
  void *handle = 0;

  if (my_handle == 0) {
    my_handle = dlopen(0, RTLD_LAZY);
    if (my_handle == 0) {
      snprintf(error_buf, sizeof error_buf, "dlopen(0): %s", dlerror());
      yyerror(error_buf, ERR_FATAL);
    }
#ifdef _LP64
    {
      char buf[BUFSIZ];
      char *p;

      p = getenv("LD_LIBRARY_PATH");
      if (p)
        snprintf(buf, sizeof buf, "LD_LIBRARY_PATH=/usr/lib/64:%s", p);
      else
        strcpy(buf, "LD_LIBRARY_PATH=/usr/lib/64");
      putenv(buf);
    }
#endif
  }
  if (attach_list && (try_to_attach(my_handle, lib, attach_list, 0) == 0))
    return;
  lib = canonicalize_lib(lib);
  handle = dlopen(lib, RTLD_LAZY);
  if (handle == 0) {
    snprintf(error_buf, sizeof error_buf, "dlopen(%s): %s", lib, dlerror());
    yyerror(error_buf, ERR_NONFATAL);
    return;
  }
  if (attach_list) 
    try_to_attach(handle, lib, attach_list, 1);
  /* DO NOT dlclose(handle) */
}

/*
 * newing functions
 */


static T_VARIABLE *
new_variable(T_VARIABLE *mp)
{
  T_VARIABLE *new_mp;

  /* common members */
  new_mp = NEW(T_VARIABLE);
  *new_mp = *mp;
  if (new_mp->var_dimension)
    new_mp->var_un.var_array = new_array_type(new_mp);
  else if (mp->var_type == VAR_USER)
    new_mp->var_un.var_user = new_user_type(mp);

  return new_mp;
}

static T_STRUCT *
new_user_type(T_VARIABLE *vp)
{
  register T_VARIABLE *mp;
  T_VARIABLE *head = 0;
  register T_VARIABLE *current;
  T_VARIABLE *new_mp;
  T_VARIABLE *xp;
  T_STRUCT   str;
  T_STRUCT   *sp;

  if (vp->var_struct == 0)
    return 0;

  /* foreach struct member */
  for(mp=vp->var_struct->st_members; mp; mp=mp->var_next) {

    new_mp = new_variable(mp);
    if (head)
      current = current->var_next = new_mp;
    else
      current = head = new_mp;

    new_mp->var_parent = vp;
  }
  sp = NEW(T_STRUCT);
  sp->st_name = vp->var_struct->st_name;
  sp->st_size = vp->var_struct->st_size;
  sp->st_class = vp->var_struct->st_class;
  sp->st_members = head;

  /* if it's a class and has local variables, then create copies of the   *
   * locals and copy the aggregate values over.                           */
  if (vp->var_struct->st_class && vp->var_struct->st_local_vars) {

    /* build the struct. str can be temp since it gets replaced below */
    str.st_name = "class_local_struct";
    str.st_members = vp->var_struct->st_class->b_variables;
    str.st_size = 0;
    str.st_class = 0;
    str.st_local_vars = 0;

    /* build a variable of this struct */
    mp = NEW(T_VARIABLE);
    mp->var_type = VAR_USER;
    mp->var_name = "class_local_variables";
    mp->var_struct = &str;

    /* &str is used up till here.  Now I build a new user type */
    mp->var_un.var_user = new_user_type(mp);

    /* new instances of an active class variable do not have their own   *
     * instances of class_local variables since they cannot access them. */

    for(xp=mp->var_un.var_user->st_members; xp; xp=xp->var_next)
      xp->var_instances = 0;

    /* replace var_struct with the original pointer to the struct */
    mp->var_struct = vp->var_struct;
    sp->st_local_vars = mp;

    /* bring across aggregately initialized class block local variables */
    se_structure_assignment(/* to   = */ mp,
                            /* from = */ vp->var_struct->st_local_vars);
  }

  return sp;
}

static void *
new_array_type(T_VARIABLE *vp)
{
  int i;
  int unit;
  int dimension;
  T_STRUCT **p;

  /* allocate quantity one for dynamic arrays and let run.c deal with it */
  dimension = vp->var_dimension;
  if (dimension == -1)
    dimension = 1;
  unit = Se_type_sizes[vp->var_type];
  if (unit == -1) {
    p = (T_STRUCT **) se_alloc(sizeof(T_STRUCT *) * dimension);
    for(i=0; i<dimension; i++)
      p[i] = new_user_type(vp);
    return p;
  }
  return se_alloc(unit * dimension);
}

void *
se_new_array_type(T_VARIABLE *vp)
{
  return new_array_type(vp);
}


/*
 * misc. utilities
 */


static void
member_inherit(T_VARIABLE *vp, T_VFTYPE type)
{
  int i;
  T_STRUCT **sp;
  T_VARIABLE *vvp;

  if (vp->var_type != VAR_USER) {
    switch(type) {
    case VF_KSTAT:
      yyerror("kstat variables are structures only", ERR_NONFATAL);
      break;
    case VF_CLASS:
      snprintf(error_buf, sizeof error_buf,
        "name: %s designates a class type", vp->var_name);
      yyerror(error_buf, ERR_NONFATAL);
      break;
    case VF_MIB:
      yyerror("mib variables are structures only", ERR_NONFATAL);
      break;
    }
    return;
  }
  if (vp->var_dimension == 0)
    for(vvp=vp->var_un.var_user->st_members; vvp; vvp=vvp->var_next) {
      vvp->var_parent = vp;
      vvp->var_flags |= (vp->var_flags & VF_SPECIAL);
      if (vvp->var_type == VAR_USER)
        member_inherit(vvp, type);
    }
  else {
    sp = (T_STRUCT **) vp->var_un.var_array;
    for(i=0; i<vp->var_dimension; i++)
      for(vvp=sp[i]->st_members; vvp; vvp=vvp->var_next) {
        vvp->var_parent = vp;
        vvp->var_flags |= (vp->var_flags & VF_SPECIAL);
        if (vvp->var_type == VAR_USER)
          member_inherit(vvp, type);
      }
  }
}

static void
case_error(T_CASE *cp, char *msg)
{
  int n = Lex_line_no;

  Lex_line_no = cp->ca_line_no;
  yyerror(msg, ERR_NONFATAL);
  Lex_line_no = n;
}

static void
push(void *item, T_STACK *sp)
{
  if (sp->st_top == MAX_STACK)
    yyerror("statement stack overflow", ERR_FATAL);
  sp->st_array[sp->st_top++] = item;
}

static void *
pop(T_STACK *sp)
{
  if (sp->st_top == 0)
    return 0;
  return sp->st_array[--sp->st_top];
}

static int
is_lazy(T_VARIABLE *vp)
{
  while(vp) {
    if (vp->var_parent && vp->var_parent->var_dimension)
      return 1;
    vp = vp->var_parent;
  }
  return 0;
}

static void
fix_offsets(T_STRUCT *sp, int offset, int fix)
{
  int i;
  int size;
  T_VARIABLE *vvp;

  for(vvp=sp->st_members; vvp; vvp=vvp->var_next) {
    if (fix)
      vvp->var_offset += offset;
    if (vvp->var_type == VAR_USER) {
      if (vvp->var_dimension == 0)
        fix_offsets(vvp->var_un.var_user, vvp->var_offset, 1);
      else {
        size = ((T_STRUCT **) vvp->var_un.var_array)[0]->st_size;
        for(i=0; i<vvp->var_dimension; i++)
          fix_offsets(((T_STRUCT **) vvp->var_un.var_array)[i],
                      vvp->var_offset + (size * i), 1);
      }
    }
  }
}

static void
free_user_type(T_STRUCT *sp)
{
  int i;
  T_VARIABLE *vp;
  T_VARIABLE *xp;

  /* foreach struct member */
  for(vp=sp->st_members; vp; vp=xp) {
    xp = vp->var_next;
    if (vp->var_dimension) {
      switch(vp->var_type) {
      case VAR_USER:
        if (vp->var_un.var_array) {
          for(i=0; i<vp->var_dimension; i++)
            free_user_type(((T_STRUCT **) vp->var_un.var_array)[i]);
          se_free(vp->var_un.var_array);
        }
        break;
      case VAR_STRING:
        if (vp->var_un.var_array) {
          for(i=0; i<vp->var_dimension; i++)
            if (((char **) vp->var_un.var_array)[i])
              se_free (((char **) vp->var_un.var_array)[i]);
          se_free(vp->var_un.var_array);
        }
        break;
      default:
        if (vp->var_un.var_array)
          se_free(vp->var_un.var_array);
        break;
      }
    } else {
      switch(vp->var_type) {
      case VAR_USER:
        free_user_type(vp->var_un.var_user);
        break;
      case VAR_STRING:
        se_free(vp->var_un.var_string);
        break;
      default:
        break;
      }
    }
    se_free(vp);
  }
  se_free(sp);
}

void
se_free_user_type(T_STRUCT *sp)
{
  free_user_type(sp);
}

void
se_clone_array(T_VARIABLE *to, T_VARIABLE *from)
{
  int i;
  int size;
  T_VARIABLE *vp;
  T_VARIABLE *parent;
  T_STRUCT **spp;

  if (to->var_un.var_array) {
    switch(to->var_type) {
    case VAR_STRING:
      for(i=0; i<to->var_dimension; i++)
        if (((char **) to->var_un.var_array)[i])
          se_free (((char **) to->var_un.var_array)[i]);
      break;
    case VAR_USER:
      for(i=0; i<to->var_dimension; i++)
        free_user_type(((T_STRUCT **) to->var_un.var_array)[i]);
      break;
    default:
      break;
    }
    se_free(to->var_un.var_array);
  }
  to->var_un.var_array = new_array_type(from);
  if (to->var_instances)
    parent = to->var_instances->var_parent;
  for(vp=to->var_instances; vp; vp=vp->var_next) {
    /* struct = struct;  implicit instances not caught by lvalue nonterm. */
    if (vp->var_parent != parent)
      break;
    vp->var_un.var_array = to->var_un.var_array;
    vp->var_dimension = from->var_dimension;
  }
  to->var_dimension = from->var_dimension;
  if (to->var_type == VAR_USER) {
    spp = ((T_STRUCT **) to->var_un.var_array);
    size = spp[0]->st_size;
    for(i=0; i<to->var_dimension; i++)
      fix_offsets(spp[i], size * i, 1);
  }
}
static YYCONST yytabelem yyexca[] ={
-1, 1,
	0, -1,
	-2, 0,
-1, 54,
	291, 70,
	-2, 44,
	};
# define YYNPROD 211
# define YYLAST 1262
static YYCONST yytabelem yyact[]={

    84,   391,    83,   134,   373,   392,    92,   365,   281,    14,
   305,    45,   345,    43,    48,    39,   223,   124,   127,   128,
    87,    64,   395,   184,    90,   304,   369,   355,    28,   342,
   184,    39,   341,    86,   333,   332,   324,    36,   320,   319,
   318,   136,   230,   126,   228,   222,   221,   113,    85,    98,
   184,   112,    65,   130,   132,    76,    88,    31,    30,    89,
   184,   170,   101,   388,    77,   340,   321,    97,   125,    39,
   185,   313,   100,   115,   265,    48,   239,   185,    99,    48,
   238,   133,   127,   128,   389,   141,   145,   147,   148,    29,
   124,   354,    39,    27,   121,   152,    91,   185,    32,    35,
    34,    37,    33,   211,   187,   183,   116,   185,   400,   399,
    18,   353,   382,    28,    25,   379,   126,   378,   357,   186,
   159,   322,    36,   173,   174,   175,   176,   177,   178,   179,
   180,   181,   182,   133,    66,    15,    21,   157,   153,   155,
   123,   125,    31,    30,   184,   213,    17,   155,    69,   160,
    16,   370,   329,   210,   327,   127,   128,   218,   219,    22,
   122,   326,   325,   229,   215,   209,   158,   151,    56,   394,
   393,   366,   361,   360,    29,   328,   387,    39,    27,    14,
   171,   165,   164,    32,    35,    34,    37,    33,    75,    61,
   237,   185,   156,   279,   240,   242,   243,   244,   245,   246,
   247,   248,   249,   250,   251,   252,   253,   254,   255,   256,
   257,   258,   259,   144,   356,   141,   376,   263,   196,   190,
   196,   190,   266,   377,   117,   390,   315,   269,   143,   335,
   385,   144,   303,    60,   291,   225,   133,   277,   234,   236,
   135,    10,   140,   312,   334,    94,   143,    70,    28,   142,
   102,    79,   212,    72,   267,   103,    13,    36,    74,   192,
   195,   192,   195,   261,   154,   197,    24,   197,   292,   191,
   316,   191,    20,   296,    41,   299,    50,    31,    30,   303,
    55,   291,    28,   199,   200,   199,   200,   194,   298,   194,
   297,    36,    11,   193,    51,   193,   110,     8,     4,     2,
   198,     1,   198,   108,   331,   336,   337,   290,   289,    29,
    78,    31,    30,    27,    44,   338,    46,   288,    32,    35,
    34,    37,    33,   375,     3,   374,   118,    40,   303,   303,
   291,   291,   129,   349,   348,   166,   347,   105,   106,   371,
   372,   287,   286,    29,   352,   285,   109,    27,    95,   131,
     7,     6,    32,    35,    34,    37,    33,   303,   162,   291,
    28,   303,   303,   291,   291,   364,   367,   368,    96,    36,
   303,   172,   291,   188,   162,     5,   168,   383,   347,   343,
   344,   384,   380,    21,   129,    19,   303,    47,   291,    31,
    30,   303,   396,   291,   303,   303,   291,   291,   301,   397,
   398,   131,   220,   214,   302,   305,    26,   308,    28,   363,
     9,   167,    62,   233,    63,   307,   227,    36,   224,   295,
   304,    29,   139,    71,   381,    27,    98,   294,   293,   231,
    32,    35,    34,    37,    33,    82,    28,    31,    30,   101,
   241,   232,   114,   216,    97,    36,   217,    59,   362,   100,
   260,   300,    48,   138,   262,    99,   282,   137,   284,   283,
   271,   275,    28,    73,    39,    31,    30,   309,   346,    29,
   280,    36,   323,    27,   310,   306,   188,   276,    32,    35,
    34,    37,    33,   162,    28,   386,   278,   129,   107,   270,
    49,    31,    30,    36,    12,    57,   124,    29,   110,   272,
   121,    27,     0,     0,   131,     0,    32,    35,    34,    37,
    33,    28,     0,    31,    30,   161,     0,   169,     0,     0,
    36,     0,   126,    29,    73,     0,     0,    27,     0,     0,
     0,     0,    32,    35,    34,    37,    33,     0,   120,     0,
    31,    30,     0,     0,     0,    29,   123,   125,   119,    27,
     0,     0,     0,     0,    32,    35,    34,    37,    33,     0,
   350,   127,   128,   124,     0,    87,   122,   121,     0,    90,
     0,     0,    29,     0,     0,     0,    27,     0,    86,     0,
     0,    32,    35,    34,    37,    33,   136,     0,     0,   126,
     0,     0,     0,    85,    98,   274,    87,     0,     0,   235,
    90,    88,     0,     0,    89,   120,     0,   101,     0,    86,
     0,     0,    97,   123,   125,   119,     0,   100,     0,     0,
    48,     0,     0,    99,    85,    98,   317,     0,   127,   128,
    80,     0,    88,   122,     0,    89,    73,    39,   101,     0,
     0,    91,    87,    97,     0,     0,    90,     0,   100,     0,
     0,    48,     0,     0,    99,    86,     0,     0,     0,     0,
   330,     0,     0,   136,     0,     0,     0,     0,    39,     0,
    85,    98,    91,    87,     0,     0,   132,    90,    88,     0,
     0,    89,     0,     0,   101,     0,    86,     0,     0,    97,
     0,     0,     0,     0,   100,     0,     0,    48,     0,     0,
    99,    85,    98,     0,    87,     0,    81,    80,    90,    88,
     0,     0,    89,     0,    39,   101,     0,    86,    91,     0,
    97,     0,     0,     0,     0,   100,     0,     0,    48,     0,
     0,    99,    85,    98,     0,     0,     0,     0,    80,     0,
    88,     0,     0,    89,     0,    39,   101,     0,     0,    91,
     0,    97,     0,   124,     0,     0,   100,   121,     0,    48,
     0,     0,    99,     0,   124,     0,     0,     0,   121,     0,
   124,     0,     0,   205,   121,     0,    39,   204,   202,   126,
    91,     0,     0,     0,     0,   203,     0,     0,     0,     0,
   126,     0,     0,   201,     0,   120,   126,     0,     0,   208,
     0,     0,     0,   123,   125,   119,   120,   124,     0,   206,
   207,   121,   120,   124,   123,   125,   119,   121,   127,   128,
   123,   125,   119,   122,     0,     0,   359,     0,     0,   127,
   128,     0,   358,   126,   122,   127,   128,     0,     0,   126,
   122,     0,   124,     0,     0,     0,   121,     0,     0,   120,
     0,     0,     0,     0,     0,   120,     0,   123,   125,   119,
     0,     0,     0,   123,   125,   119,     0,     0,   126,   351,
     0,     0,   127,   128,     0,   339,   124,   122,   127,   128,
   121,     0,     0,   122,   120,     0,   311,   124,     0,     0,
     0,   121,   123,   125,   119,     0,     0,     0,     0,     0,
     0,     0,   126,     0,     0,   314,     0,   127,   128,     0,
     0,     0,   122,   126,     0,     0,     0,   124,   120,     0,
     0,   121,     0,     0,     0,     0,   123,   125,   119,   120,
     0,    52,    23,     0,    23,     0,     0,   123,   125,   119,
     0,   127,   128,   126,     0,     0,   122,     0,     0,     0,
   268,     0,   127,   128,     0,    93,    38,   122,    38,   120,
     0,     0,     0,     0,     0,     0,     0,   123,   125,   119,
    42,     0,     0,     0,     0,    38,     0,     0,    53,    54,
     0,    58,   127,   128,     0,     0,     0,   122,     0,     0,
     0,     0,     0,   104,     0,     0,   111,     0,     0,    42,
     0,     0,     0,     0,     0,     0,     0,   104,    67,    68,
     0,     0,     0,     0,     0,     0,     0,     0,    42,    42,
   149,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   104,     0,     0,     0,     0,   111,
     0,   146,   146,   146,     0,   150,     0,     0,     0,     0,
   104,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   163,     0,     0,     0,   189,    38,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   226,   104,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,   146,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,   264,     0,     0,
     0,     0,     0,     0,     0,     0,   226,     0,     0,   104,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,   273,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   146,   146 };
static YYCONST yytabelem yypact[]={

  -152,-10000000,  -152,-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,
-10000000,-10000000,-10000000,-10000000,  -314,  -318,  -320,  -322,  -233,  -314,
-10000000,   246,  -314,  -314,  -123,  -314,   -27,-10000000,-10000000,-10000000,
-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,
-10000000,  -101,-10000000,  -298,-10000000,  -233,-10000000,  -269,-10000000,-10000000,
  -184,-10000000,  -314,  -314,  -144,-10000000,   -17,  -102,-10000000,  -266,
   416,   246,  -314,  -314,   219,-10000000,  -270,  -144,  -274,   447,
  -213,   -44,-10000000,-10000000,-10000000,   246,-10000000,   660,-10000000,-10000000,
   385,   416,-10000000,-10000000,   -57,  -314,  -314,  -314,   246,  -314,
  -124,   447,-10000000,  -153,   -81,-10000000,-10000000,-10000000,-10000000,-10000000,
  -149,  -166,   197,-10000000,  -314,  -108,  -109,    17,-10000000,  -314,
   246,-10000000,-10000000,-10000000,  -259,   660,  -110,   -17,   246,   447,
   447,   447,   447,   447,   447,   447,   447,   447,   447,  -214,
  -198,  -215,  -237,   -39,   496,-10000000,  -126,-10000000,-10000000,  -165,
-10000000,   660,-10000000,-10000000,-10000000,-10000000,  -145,-10000000,-10000000,  -147,
  -147,  -127,-10000000,   447,   447,-10000000,  -314,-10000000,-10000000,-10000000,
-10000000,  -275,-10000000,  -276,   246,   246,  -277,-10000000,  -128,  -279,
-10000000,    95,-10000000,  -167,  -167,  -240,  -240,  -240,  -304,  -304,
  -304,-10000000,-10000000,-10000000,   308,   308,   447,-10000000,  -239,  -243,
   416,   447,   447,   447,   447,   447,   447,   447,   447,   447,
   447,   447,   447,   447,   447,   447,   447,   447,   447,   308,
-10000000,   416,-10000000,   447,-10000000,   246,  -245,   -46,   660,   630,
-10000000,-10000000,-10000000,   447,   171,-10000000,  -298,   143,-10000000,   -17,
-10000000,   135,    95,-10000000,-10000000,   385,-10000000,   619,-10000000,   447,
   660,-10000000,   660,   660,   660,   660,   660,   660,   660,   660,
   660,   660,   660,   660,   660,   660,   660,   660,   660,   660,
  -248,  -114,-10000000,   585,   -35,-10000000,   447,-10000000,-10000000,   306,
  -281,-10000000,  -282,-10000000,-10000000,  -283,  -253,  -197,   135,-10000000,
-10000000,  -285,-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,
-10000000,-10000000,-10000000,-10000000,-10000000,  -129,  -130,  -137,  -115,  -139,
   339,  -286,  -287,   -41,  -314,  -314,-10000000,-10000000,-10000000,-10000000,
-10000000,   447,   556,-10000000,-10000000,  -254,   660,  -289,-10000000,-10000000,
-10000000,  -292,-10000000,-10000000,-10000000,   308,   308,  -260,   135,   447,
-10000000,   239,-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,   550,-10000000,
   447,-10000000,-10000000,  -208,  -228,  -294,   -54,-10000000,  -200,   513,
-10000000,-10000000,   507,  -117,  -118,   308,  -260,  -333,  -119,-10000000,
   135,   135,  -295,  -114,-10000000,  -140,   -48,  -201,  -203,  -260,
   308,  -206,   -48,-10000000,   140,   -37,-10000000,-10000000,  -100,-10000000,
  -256,  -235,-10000000,-10000000,   -42,   135,-10000000,  -120,  -121,  -299,
   135,-10000000,-10000000,   135,   135,-10000000,-10000000,  -209,  -210,-10000000,
-10000000 };
static YYCONST yytabelem yypgo[]={

     0,   955,   368,   266,   274,   499,   495,   494,   256,   490,
   303,   488,   193,     5,   486,   485,    12,   470,     8,   468,
     1,   459,     2,   458,   268,   457,   453,   240,    53,   448,
   251,     3,   447,   446,   443,   442,   252,   406,   441,   255,
   250,   241,   435,     0,     6,   429,   428,   427,   245,   247,
   423,   249,   422,   242,   253,   235,   418,   272,   298,   410,
   385,   375,   351,   350,   348,   931,   346,   345,   342,   341,
   340,     4,   339,   325,   323,   317,   308,   307,   301,   299,
   324,   297,   292,   290,   288,   275,   273,   264,   254 };
static YYCONST yytabelem yyr1[]={

     0,    78,    79,    79,    80,    80,    80,    80,    80,    80,
    80,    80,    80,    80,    61,    61,    62,    63,    56,    56,
    55,     5,     5,    58,     4,    81,    81,    11,    11,    10,
    10,    66,    66,    59,     6,    60,     9,    40,    40,    39,
    39,    41,    41,    57,    37,    37,    35,    35,    32,    32,
    32,    51,    52,    52,    53,    53,    65,    65,    65,    65,
    65,    65,    65,    65,    65,    65,    65,    82,     7,     8,
     3,    45,    45,    38,    38,    49,    49,    50,    50,    54,
    54,     1,     2,    13,    14,    14,    12,    12,    12,    17,
    17,    17,    17,    17,    17,    17,    17,    18,    18,    18,
    18,    46,    46,    47,    47,    67,    68,    83,    84,    19,
    19,    16,    16,    29,    29,    69,    85,    72,    70,    70,
    71,    71,    20,    20,    73,    74,    76,    77,    75,    75,
    21,    15,    15,    28,    28,    28,    27,    27,    27,    27,
    27,    27,    27,    27,    27,    27,    22,    23,    86,    48,
    48,    48,    87,    88,    43,    24,    24,    25,    25,    26,
    26,    26,    26,    26,    26,    26,    26,    26,    26,    34,
    34,    33,    33,    64,    64,    64,    64,    64,    64,    42,
    42,    44,    44,    44,    31,    31,    31,    31,    36,    30,
    30,    30,    30,    30,    30,    30,    30,    30,    30,    30,
    30,    30,    30,    30,    30,    30,    30,    30,    30,    30,
    30 };
static YYCONST yytabelem yyr2[]={

     0,     3,     4,     2,     3,     3,     3,     3,     3,     3,
     3,     3,     3,     3,    17,     5,    17,     5,     5,     3,
     7,     3,     3,    13,     3,    13,     7,     5,     3,    13,
     7,     3,     1,     5,     3,     9,     7,     5,     3,     7,
    13,     3,     5,     7,     5,    11,     3,     1,     5,     5,
     1,     7,     7,     3,     3,     3,     3,     3,     3,     3,
     3,     3,     3,     3,     3,     3,     3,     9,     5,    17,
     3,     3,     1,     5,     3,     3,     1,     7,     3,     3,
     3,     3,     3,     3,     5,     3,     3,     5,     3,     3,
     3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
     3,     5,     5,     5,     5,    23,    19,     3,     3,     7,
     3,     3,     1,     3,     1,    15,     3,     3,     5,     3,
     9,     7,     3,     1,     3,     3,     5,     5,     5,     7,
    17,     9,     1,     3,     7,     9,     7,     7,     7,     7,
     7,     7,     7,     7,     7,     7,     9,    15,     3,     3,
     7,     9,     3,     3,     3,     3,     3,     7,     7,     7,
     7,     7,     7,     7,     7,     7,     7,     7,     7,     3,
     1,     7,     3,     3,     3,     5,     5,     5,     5,     3,
     3,     3,     3,     3,     3,     7,    15,     7,     7,     3,
     3,     5,     5,     5,     5,     5,     7,     7,     7,     7,
     7,     7,     7,     7,     7,     7,     7,     7,    13,    17,
     5 };
static YYCONST yytabelem yychk[]={

-10000000,   -78,   -79,   -80,   -58,   -61,   -62,   -63,   -81,   -59,
   -41,   -82,    -7,    -8,   331,   287,   302,   298,   262,   -60,
   -57,   288,   311,   -65,    -3,   266,   -37,   330,   265,   326,
   295,   294,   335,   339,   337,   336,   274,   338,    -1,   329,
   -80,    -4,    -1,   331,   -58,   331,   -58,    -2,   312,    -9,
    -8,   -57,   -65,    -1,    -1,    -8,   291,    -6,    -1,   -32,
   260,   290,    -2,    -2,   290,   321,   318,    -1,    -1,   292,
   -49,   -50,   -54,   -37,   275,   290,   321,   -31,   -51,   -30,
   291,   290,   -42,   -22,   -43,   285,   270,   257,   293,   296,
   261,   333,   -44,    -1,   -48,   -64,    -2,   304,   286,   315,
   309,   299,   -40,   -39,   -65,    -4,    -4,   -11,   -10,   -66,
   279,   -65,   321,   321,   -35,   -31,   319,   268,   -40,   309,
   299,   261,   327,   307,   257,   308,   283,   322,   323,   -30,
   -28,   -24,   291,   -43,   -31,   -27,   278,   -25,   -26,   -52,
   -53,   -31,   -51,   285,   270,   -43,    -1,   -43,   -43,   -65,
    -1,   291,   -31,   291,   -87,   292,   273,   286,   315,   286,
   315,   318,   -39,    -1,   290,   290,   318,   -10,    -3,   -37,
   320,   290,   -54,   -31,   -31,   -31,   -31,   -31,   -31,   -31,
   -31,   -31,   -31,   319,   258,   305,   317,   319,   -27,   -65,
   260,   310,   300,   334,   328,   301,   259,   306,   341,   324,
   325,   297,   282,   289,   281,   277,   313,   314,   303,   291,
   318,   268,   -36,   292,   -36,   291,   -34,   -33,   -31,   -31,
   -48,   321,   321,   292,   -56,   -55,   -65,   -40,   321,   291,
   321,   -45,   -38,   -41,   -28,   291,   -28,   -31,   319,   319,
   -31,   -51,   -31,   -31,   -31,   -31,   -31,   -31,   -31,   -31,
   -31,   -31,   -31,   -31,   -31,   -31,   -31,   -31,   -31,   -31,
   -27,   -28,   -53,   -31,   -65,   319,   268,   -88,   320,   -31,
   318,   -55,    -5,    -1,    -2,   318,   -49,   -13,   -14,   -12,
   -17,   -18,   321,   -21,   -23,   -67,   -68,   -69,   -75,   -76,
   -77,   -22,   -24,   -46,   -47,   284,   -86,   -83,   -84,   -85,
   316,   263,   269,   -43,   285,   270,   340,   280,   272,   332,
   -41,   267,   -31,   319,   320,   261,   -31,   320,   321,   321,
   321,   319,   318,   -12,   321,   291,   291,   291,   290,   291,
   321,   -31,   321,   321,   285,   270,   -43,   -43,   -31,   319,
   319,   321,   321,   -28,   -28,   -16,   -19,   -18,   -13,   -31,
   321,   319,   -31,   319,   319,   321,   268,   318,   319,   319,
   290,   290,   -29,   -28,   -18,   340,   290,   -13,   -13,   321,
   291,   -72,   -70,   -71,   -73,   -74,   264,   271,   318,   318,
   -16,   -28,   318,   -71,   -44,   267,   -15,   276,   319,   319,
   267,   -20,   -13,   290,   290,   321,   -20,   -13,   -13,   318,
   318 };
static YYCONST yytabelem yydef[]={

     0,    -2,     1,     3,     4,     5,     6,     7,     8,     9,
    10,    11,    12,    13,     0,     0,     0,     0,     0,     0,
    41,     0,     0,     0,     0,     0,    50,    56,    57,    58,
    59,    60,    61,    62,    63,    64,    65,    66,    70,    81,
     2,     0,    24,     0,    15,     0,    17,     0,    82,    33,
     0,    42,     0,     0,    -2,    68,    76,     0,    34,     0,
     0,     0,     0,     0,    32,    26,     0,    44,     0,    47,
     0,    75,    78,    79,    80,     0,    43,    48,    49,   184,
     0,     0,   189,   190,   180,     0,     0,     0,     0,     0,
     0,     0,   179,   149,   154,   181,   182,   183,   173,   174,
     0,     0,     0,    38,     0,     0,     0,    32,    28,     0,
     0,    31,    36,    67,     0,    46,     0,     0,    35,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   184,
     0,     0,     0,   180,     0,   133,     0,   155,   156,     0,
    53,    54,    55,   191,   193,   192,   149,   194,   195,     0,
     0,     0,   210,   170,     0,   152,     0,   175,   176,   177,
   178,     0,    37,     0,     0,     0,     0,    27,     0,     0,
    45,    72,    77,   198,   199,   200,   201,   202,   203,   204,
   205,   206,   207,   185,     0,     0,     0,   187,   133,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    51,     0,   196,     0,   197,     0,     0,   169,   172,     0,
   150,    23,    39,     0,     0,    19,     0,     0,    25,    76,
    30,     0,    71,    74,   144,     0,   145,     0,   134,     0,
   157,   158,   159,   160,   161,   162,   163,   164,   165,   166,
   167,   168,   136,   137,   138,   139,   140,   141,   142,   143,
   133,     0,    52,     0,     0,   146,     0,   151,   153,     0,
     0,    18,     0,    21,    22,     0,     0,     0,    83,    85,
    86,     0,    88,    89,    90,    91,    92,    93,    94,    95,
    96,    97,    98,    99,   100,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   148,   107,   108,   116,
    73,     0,     0,   135,   188,     0,   171,     0,    14,    20,
    16,     0,    69,    84,    87,     0,     0,   112,     0,     0,
   128,     0,   126,   127,   101,   103,   102,   104,     0,   208,
     0,    40,    29,     0,     0,     0,   111,   110,     0,     0,
   129,   186,     0,     0,     0,   114,     0,     0,     0,   209,
     0,     0,     0,   113,   109,     0,     0,     0,     0,   112,
     0,     0,   117,   119,     0,     0,   124,   125,   132,   147,
     0,     0,   115,   118,     0,   123,   130,     0,     0,     0,
   123,   121,   122,     0,     0,   106,   120,     0,     0,   131,
   105 };
typedef struct
#ifdef __cplusplus
	yytoktype
#endif
{ char *t_name; int t_val; } yytoktype;
#ifndef YYDEBUG
#	define YYDEBUG	0	/* don't allow debugging */
#endif

#if YYDEBUG

yytoktype yytoks[] =
{
	"AMPERSAND",	257,
	"AND",	258,
	"AND_EQ",	259,
	"ASSIGN",	260,
	"ASTERISK",	261,
	"ATTACH",	262,
	"BREAK",	263,
	"CASE",	264,
	"CHAR_TYPE",	265,
	"CLASS",	266,
	"COLON",	267,
	"COMMA",	268,
	"CONTINUE",	269,
	"DECREMENT",	270,
	"DEFAULT",	271,
	"DO",	272,
	"DOT",	273,
	"DOUBLE_TYPE",	274,
	"ELLIPSIS",	275,
	"ELSE",	276,
	"EQ",	277,
	"EXCLAMATION",	278,
	"EXTERN",	279,
	"FOR",	280,
	"GE",	281,
	"GT",	282,
	"HAT",	283,
	"IF",	284,
	"INCREMENT",	285,
	"INTEGER",	286,
	"KSTAT",	287,
	"KVM",	288,
	"LE",	289,
	"LEFT_CURLY",	290,
	"LEFT_PAREN",	291,
	"LEFT_SQUARE",	292,
	"LNEW",	293,
	"LONGLONG_TYPE",	294,
	"LONG_TYPE",	295,
	"LRENEW",	296,
	"LT",	297,
	"MIB",	298,
	"MINUS",	299,
	"MINUS_EQ",	300,
	"MOD_EQ",	301,
	"NDD",	302,
	"NE",	303,
	"NIL",	304,
	"OR",	305,
	"OR_EQ",	306,
	"PERCENT",	307,
	"PIPE",	308,
	"PLUS",	309,
	"PLUS_EQ",	310,
	"PRAGMA",	311,
	"QSTRING",	312,
	"RE_EQ",	313,
	"RE_NEQ",	314,
	"REAL",	315,
	"LRETURN",	316,
	"QUESTION",	317,
	"RIGHT_CURLY",	318,
	"RIGHT_PAREN",	319,
	"RIGHT_SQUARE",	320,
	"SEMICOLON",	321,
	"SHIFT_LEFT",	322,
	"SHIFT_RIGHT",	323,
	"SHIFT_LEFT_EQ",	324,
	"SHIFT_RIGHT_EQ",	325,
	"SHORT_TYPE",	326,
	"SLASH",	327,
	"SLASH_EQ",	328,
	"STRING",	329,
	"STRING_TYPE",	330,
	"STRUCT",	331,
	"SWITCH",	332,
	"TILDE",	333,
	"TIMES_EQ",	334,
	"UCHAR_TYPE",	335,
	"ULONGLONG_TYPE",	336,
	"ULONG_TYPE",	337,
	"USER_TYPE",	338,
	"USHORT_TYPE",	339,
	"WHILE",	340,
	"XOR_EQ",	341,
	"AT_SIGN",	342,
	"BACKSLASH",	343,
	"DOT_DOT",	344,
	"EOLN",	345,
	"BI_MAX_CPU",	346,
	"BI_MAX_DISK",	347,
	"BI_MAX_IF",	348,
	"BI_MAX_INTS",	349,
	"-unknown-",	-1	/* ends search */
};

char * yyreds[] =
{
	"-no such reduction-",
	"program : list_of_decs",
	"list_of_decs : list_of_decs dec",
	"list_of_decs : dec",
	"dec : struct",
	"dec : kstat_struct",
	"dec : ndd_struct",
	"dec : mib_struct",
	"dec : attach",
	"dec : class",
	"dec : declared_variable",
	"dec : pragma",
	"dec : block",
	"dec : typeless_block",
	"kstat_struct : KSTAT STRUCT qstring struct_id LEFT_CURLY list_of_kmembers RIGHT_CURLY SEMICOLON",
	"kstat_struct : KSTAT struct",
	"ndd_struct : NDD STRUCT qstring struct_id LEFT_CURLY list_of_members RIGHT_CURLY SEMICOLON",
	"mib_struct : MIB struct",
	"list_of_kmembers : list_of_kmembers kmember",
	"list_of_kmembers : kmember",
	"kmember : type_name kname SEMICOLON",
	"kname : string",
	"kname : qstring",
	"struct : STRUCT struct_id LEFT_CURLY list_of_members RIGHT_CURLY SEMICOLON",
	"struct_id : string",
	"attach : ATTACH qstring LEFT_CURLY list_of_attachments RIGHT_CURLY SEMICOLON",
	"attach : ATTACH qstring SEMICOLON",
	"list_of_attachments : list_of_attachments attachment",
	"list_of_attachments : attachment",
	"attachment : type_specifier block_id LEFT_PAREN list_of_parameters RIGHT_PAREN SEMICOLON",
	"attachment : EXTERN variable SEMICOLON",
	"type_specifier : type_name",
	"type_specifier : /* empty */",
	"class : struct_part class_part",
	"class_tag : string",
	"struct_part : CLASS class_tag LEFT_CURLY list_of_members",
	"class_part : typeless_block RIGHT_CURLY SEMICOLON",
	"list_of_members : list_of_members member",
	"list_of_members : member",
	"member : type_name string SEMICOLON",
	"member : type_name string LEFT_SQUARE expression RIGHT_SQUARE SEMICOLON",
	"declared_variable : initialized_variable",
	"declared_variable : KVM initialized_variable",
	"initialized_variable : variable initializer SEMICOLON",
	"variable : type_name string",
	"variable : type_name string LEFT_SQUARE array_size RIGHT_SQUARE",
	"array_size : expression",
	"array_size : /* empty */",
	"initializer : ASSIGN expression",
	"initializer : ASSIGN aggregate",
	"initializer : /* empty */",
	"aggregate : LEFT_CURLY list_of_inits RIGHT_CURLY",
	"list_of_inits : list_of_inits COMMA init",
	"list_of_inits : init",
	"init : expression",
	"init : aggregate",
	"type_name : STRING_TYPE",
	"type_name : CHAR_TYPE",
	"type_name : SHORT_TYPE",
	"type_name : LONG_TYPE",
	"type_name : LONGLONG_TYPE",
	"type_name : UCHAR_TYPE",
	"type_name : USHORT_TYPE",
	"type_name : ULONG_TYPE",
	"type_name : ULONGLONG_TYPE",
	"type_name : DOUBLE_TYPE",
	"type_name : USER_TYPE",
	"pragma : PRAGMA string string SEMICOLON",
	"block : type_name typeless_block",
	"typeless_block : block_id LEFT_PAREN list_of_parameters RIGHT_PAREN LEFT_CURLY local_variables list_of_statements RIGHT_CURLY",
	"block_id : string",
	"local_variables : list_of_variables",
	"local_variables : /* empty */",
	"list_of_variables : list_of_variables declared_variable",
	"list_of_variables : declared_variable",
	"list_of_parameters : parameter_list",
	"list_of_parameters : /* empty */",
	"parameter_list : parameter_list COMMA param",
	"parameter_list : param",
	"param : variable",
	"param : ELLIPSIS",
	"string : STRING",
	"qstring : QSTRING",
	"list_of_statements : statement_list",
	"statement_list : statement_list statement",
	"statement_list : statement",
	"statement : control_statement",
	"statement : sequence_statement SEMICOLON",
	"statement : SEMICOLON",
	"control_statement : if_statement",
	"control_statement : while_statement",
	"control_statement : for_statement",
	"control_statement : do_statement",
	"control_statement : switch_statement",
	"control_statement : return_statement",
	"control_statement : break_statement",
	"control_statement : continue_statement",
	"sequence_statement : call_statement",
	"sequence_statement : assign_statement",
	"sequence_statement : increment_statement",
	"sequence_statement : decrement_statement",
	"increment_statement : lvalue INCREMENT",
	"increment_statement : INCREMENT lvalue",
	"decrement_statement : lvalue DECREMENT",
	"decrement_statement : DECREMENT lvalue",
	"for_statement : for_id LEFT_PAREN before_part SEMICOLON while_part SEMICOLON before_part RIGHT_PAREN LEFT_CURLY list_of_statements RIGHT_CURLY",
	"do_statement : do_id LEFT_CURLY list_of_statements RIGHT_CURLY WHILE LEFT_PAREN l_expression RIGHT_PAREN SEMICOLON",
	"for_id : FOR",
	"do_id : DO",
	"for_list : for_list COMMA sequence_statement",
	"for_list : sequence_statement",
	"before_part : for_list",
	"before_part : /* empty */",
	"while_part : l_expression",
	"while_part : /* empty */",
	"switch_statement : switch_id LEFT_PAREN expression RIGHT_PAREN LEFT_CURLY list_of_cases RIGHT_CURLY",
	"switch_id : SWITCH",
	"list_of_cases : case_list",
	"case_list : case_list case_part",
	"case_list : case_part",
	"case_part : case_id constant_value COLON case_statement_list",
	"case_part : default_id COLON case_statement_list",
	"case_statement_list : list_of_statements",
	"case_statement_list : /* empty */",
	"case_id : CASE",
	"default_id : DEFAULT",
	"break_statement : BREAK SEMICOLON",
	"continue_statement : CONTINUE SEMICOLON",
	"return_statement : LRETURN SEMICOLON",
	"return_statement : LRETURN expression SEMICOLON",
	"if_statement : IF LEFT_PAREN l_expression RIGHT_PAREN LEFT_CURLY list_of_statements RIGHT_CURLY else_part",
	"else_part : ELSE LEFT_CURLY list_of_statements RIGHT_CURLY",
	"else_part : /* empty */",
	"l_expression : plain_l_expression",
	"l_expression : LEFT_PAREN plain_l_expression RIGHT_PAREN",
	"l_expression : EXCLAMATION LEFT_PAREN plain_l_expression RIGHT_PAREN",
	"plain_l_expression : expression LT expression",
	"plain_l_expression : expression GT expression",
	"plain_l_expression : expression LE expression",
	"plain_l_expression : expression GE expression",
	"plain_l_expression : expression EQ expression",
	"plain_l_expression : expression RE_EQ expression",
	"plain_l_expression : expression RE_NEQ expression",
	"plain_l_expression : expression NE expression",
	"plain_l_expression : l_expression AND l_expression",
	"plain_l_expression : l_expression OR l_expression",
	"call_statement : string LEFT_PAREN list_of_args RIGHT_PAREN",
	"while_statement : while_id LEFT_PAREN l_expression RIGHT_PAREN LEFT_CURLY list_of_statements RIGHT_CURLY",
	"while_id : WHILE",
	"l_value : string",
	"l_value : l_value DOT l_value",
	"l_value : string left_square expression right_square",
	"left_square : LEFT_SQUARE",
	"right_square : RIGHT_SQUARE",
	"lvalue : l_value",
	"assign_statement : plain_assignment",
	"assign_statement : compound_assignment",
	"plain_assignment : lvalue ASSIGN expression",
	"plain_assignment : lvalue ASSIGN aggregate",
	"compound_assignment : lvalue PLUS_EQ expression",
	"compound_assignment : lvalue MINUS_EQ expression",
	"compound_assignment : lvalue TIMES_EQ expression",
	"compound_assignment : lvalue SLASH_EQ expression",
	"compound_assignment : lvalue MOD_EQ expression",
	"compound_assignment : lvalue AND_EQ expression",
	"compound_assignment : lvalue OR_EQ expression",
	"compound_assignment : lvalue XOR_EQ expression",
	"compound_assignment : lvalue SHIFT_LEFT_EQ expression",
	"compound_assignment : lvalue SHIFT_RIGHT_EQ expression",
	"list_of_args : arg_list",
	"list_of_args : /* empty */",
	"arg_list : arg_list COMMA expression",
	"arg_list : expression",
	"digit : INTEGER",
	"digit : REAL",
	"digit : PLUS INTEGER",
	"digit : PLUS REAL",
	"digit : MINUS INTEGER",
	"digit : MINUS REAL",
	"value : constant_value",
	"value : lvalue",
	"constant_value : digit",
	"constant_value : qstring",
	"constant_value : NIL",
	"expression : plain_expression",
	"expression : LEFT_PAREN plain_expression RIGHT_PAREN",
	"expression : LEFT_PAREN l_expression QUESTION expression COLON expression RIGHT_PAREN",
	"expression : LEFT_PAREN assign_statement RIGHT_PAREN",
	"size_spec : LEFT_SQUARE expression RIGHT_SQUARE",
	"plain_expression : value",
	"plain_expression : call_statement",
	"plain_expression : lvalue INCREMENT",
	"plain_expression : INCREMENT lvalue",
	"plain_expression : lvalue DECREMENT",
	"plain_expression : DECREMENT lvalue",
	"plain_expression : AMPERSAND lvalue",
	"plain_expression : LNEW type_name size_spec",
	"plain_expression : LRENEW string size_spec",
	"plain_expression : expression PLUS expression",
	"plain_expression : expression MINUS expression",
	"plain_expression : expression ASTERISK expression",
	"plain_expression : expression SLASH expression",
	"plain_expression : expression PERCENT expression",
	"plain_expression : expression AMPERSAND expression",
	"plain_expression : expression PIPE expression",
	"plain_expression : expression HAT expression",
	"plain_expression : expression SHIFT_LEFT expression",
	"plain_expression : expression SHIFT_RIGHT expression",
	"plain_expression : LEFT_PAREN LEFT_PAREN type_name RIGHT_PAREN expression RIGHT_PAREN",
	"plain_expression : ASTERISK LEFT_PAREN LEFT_PAREN type_name ASTERISK RIGHT_PAREN expression RIGHT_PAREN",
	"plain_expression : TILDE expression",
};
#endif /* YYDEBUG */
/*
 * Copyright (c) 1993 by Sun Microsystems, Inc.
 */

#pragma ident	"@(#)yaccpar	6.16	99/01/20 SMI"

/*
** Skeleton parser driver for yacc output
*/

/*
** yacc user known macros and defines
*/
#define YYERROR		goto yyerrlab
#define YYACCEPT	return(0)
#define YYABORT		return(1)
#define YYBACKUP( newtoken, newvalue )\
{\
	if ( yychar >= 0 || ( yyr2[ yytmp ] >> 1 ) != 1 )\
	{\
		yyerror( "syntax error - cannot backup" );\
		goto yyerrlab;\
	}\
	yychar = newtoken;\
	yystate = *yyps;\
	yylval = newvalue;\
	goto yynewstate;\
}
#define YYRECOVERING()	(!!yyerrflag)
#define YYNEW(type)	malloc(sizeof(type) * yynewmax)
#define YYCOPY(to, from, type) \
	(type *) memcpy(to, (char *) from, yymaxdepth * sizeof (type))
#define YYENLARGE( from, type) \
	(type *) realloc((char *) from, yynewmax * sizeof(type))
#ifndef YYDEBUG
#	define YYDEBUG	1	/* make debugging available */
#endif

/*
** user known globals
*/
int yydebug;			/* set to 1 to get debugging */

/*
** driver internal defines
*/
#define YYFLAG		(-10000000)

/*
** global variables used by the parser
*/
YYSTYPE *yypv;			/* top of value stack */
int *yyps;			/* top of state stack */

int yystate;			/* current state */
int yytmp;			/* extra var (lasts between blocks) */

int yynerrs;			/* number of errors */
int yyerrflag;			/* error recovery flag */
int yychar;			/* current input token number */



#ifdef YYNMBCHARS
#define YYLEX()		yycvtok(yylex())
/*
** yycvtok - return a token if i is a wchar_t value that exceeds 255.
**	If i<255, i itself is the token.  If i>255 but the neither 
**	of the 30th or 31st bit is on, i is already a token.
*/
#if defined(__STDC__) || defined(__cplusplus)
int yycvtok(int i)
#else
int yycvtok(i) int i;
#endif
{
	int first = 0;
	int last = YYNMBCHARS - 1;
	int mid;
	wchar_t j;

	if(i&0x60000000){/*Must convert to a token. */
		if( yymbchars[last].character < i ){
			return i;/*Giving up*/
		}
		while ((last>=first)&&(first>=0)) {/*Binary search loop*/
			mid = (first+last)/2;
			j = yymbchars[mid].character;
			if( j==i ){/*Found*/ 
				return yymbchars[mid].tvalue;
			}else if( j<i ){
				first = mid + 1;
			}else{
				last = mid -1;
			}
		}
		/*No entry in the table.*/
		return i;/* Giving up.*/
	}else{/* i is already a token. */
		return i;
	}
}
#else/*!YYNMBCHARS*/
#define YYLEX()		yylex()
#endif/*!YYNMBCHARS*/

/*
** yyparse - return 0 if worked, 1 if syntax error not recovered from
*/
#if defined(__STDC__) || defined(__cplusplus)
int yyparse(void)
#else
int yyparse()
#endif
{
	register YYSTYPE *yypvt = 0;	/* top of value stack for $vars */

#if defined(__cplusplus) || defined(lint)
/*
	hacks to please C++ and lint - goto's inside
	switch should never be executed
*/
	static int __yaccpar_lint_hack__ = 0;
	switch (__yaccpar_lint_hack__)
	{
		case 1: goto yyerrlab;
		case 2: goto yynewstate;
	}
#endif

	/*
	** Initialize externals - yyparse may be called more than once
	*/
	yypv = &yyv[-1];
	yyps = &yys[-1];
	yystate = 0;
	yytmp = 0;
	yynerrs = 0;
	yyerrflag = 0;
	yychar = -1;

#if YYMAXDEPTH <= 0
	if (yymaxdepth <= 0)
	{
		if ((yymaxdepth = YYEXPAND(0)) <= 0)
		{
			yyerror("yacc initialization error");
			YYABORT;
		}
	}
#endif

	{
		register YYSTYPE *yy_pv;	/* top of value stack */
		register int *yy_ps;		/* top of state stack */
		register int yy_state;		/* current state */
		register int  yy_n;		/* internal state number info */
	goto yystack;	/* moved from 6 lines above to here to please C++ */

		/*
		** get globals into registers.
		** branch to here only if YYBACKUP was called.
		*/
	yynewstate:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;
		goto yy_newstate;

		/*
		** get globals into registers.
		** either we just started, or we just finished a reduction
		*/
	yystack:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;

		/*
		** top of for (;;) loop while no reductions done
		*/
	yy_stack:
		/*
		** put a state and value onto the stacks
		*/
#if YYDEBUG
		/*
		** if debugging, look up token value in list of value vs.
		** name pairs.  0 and negative (-1) are special values.
		** Note: linear search is used since time is not a real
		** consideration while debugging.
		*/
		if ( yydebug )
		{
			register int yy_i;

			printf( "State %d, token ", yy_state );
			if ( yychar == 0 )
				printf( "end-of-file\n" );
			else if ( yychar < 0 )
				printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ++yy_ps >= &yys[ yymaxdepth ] )	/* room on stack? */
		{
			/*
			** reallocate and recover.  Note that pointers
			** have to be reset, or bad things will happen
			*/
			long yyps_index = (yy_ps - yys);
			long yypv_index = (yy_pv - yyv);
			long yypvt_index = (yypvt - yyv);
			int yynewmax;
#ifdef YYEXPAND
			yynewmax = YYEXPAND(yymaxdepth);
#else
			yynewmax = 2 * yymaxdepth;	/* double table size */
			if (yymaxdepth == YYMAXDEPTH)	/* first time growth */
			{
				char *newyys = (char *)YYNEW(int);
				char *newyyv = (char *)YYNEW(YYSTYPE);
				if (newyys != 0 && newyyv != 0)
				{
					yys = YYCOPY(newyys, yys, int);
					yyv = YYCOPY(newyyv, yyv, YYSTYPE);
				}
				else
					yynewmax = 0;	/* failed */
			}
			else				/* not first time */
			{
				yys = YYENLARGE(yys, int);
				yyv = YYENLARGE(yyv, YYSTYPE);
				if (yys == 0 || yyv == 0)
					yynewmax = 0;	/* failed */
			}
#endif
			if (yynewmax <= yymaxdepth)	/* tables not expanded */
			{
				yyerror( "yacc stack overflow" );
				YYABORT;
			}
			yymaxdepth = yynewmax;

			yy_ps = yys + yyps_index;
			yy_pv = yyv + yypv_index;
			yypvt = yyv + yypvt_index;
		}
		*yy_ps = yy_state;
		*++yy_pv = yyval;

		/*
		** we have a new state - find out what to do
		*/
	yy_newstate:
		if ( ( yy_n = yypact[ yy_state ] ) <= YYFLAG )
			goto yydefault;		/* simple state */
#if YYDEBUG
		/*
		** if debugging, need to mark whether new token grabbed
		*/
		yytmp = yychar < 0;
#endif
		if ( ( yychar < 0 ) && ( ( yychar = YYLEX() ) < 0 ) )
			yychar = 0;		/* reached EOF */
#if YYDEBUG
		if ( yydebug && yytmp )
		{
			register int yy_i;

			printf( "Received token " );
			if ( yychar == 0 )
				printf( "end-of-file\n" );
			else if ( yychar < 0 )
				printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ( ( yy_n += yychar ) < 0 ) || ( yy_n >= YYLAST ) )
			goto yydefault;
		if ( yychk[ yy_n = yyact[ yy_n ] ] == yychar )	/*valid shift*/
		{
			yychar = -1;
			yyval = yylval;
			yy_state = yy_n;
			if ( yyerrflag > 0 )
				yyerrflag--;
			goto yy_stack;
		}

	yydefault:
		if ( ( yy_n = yydef[ yy_state ] ) == -2 )
		{
#if YYDEBUG
			yytmp = yychar < 0;
#endif
			if ( ( yychar < 0 ) && ( ( yychar = YYLEX() ) < 0 ) )
				yychar = 0;		/* reached EOF */
#if YYDEBUG
			if ( yydebug && yytmp )
			{
				register int yy_i;

				printf( "Received token " );
				if ( yychar == 0 )
					printf( "end-of-file\n" );
				else if ( yychar < 0 )
					printf( "-none-\n" );
				else
				{
					for ( yy_i = 0;
						yytoks[yy_i].t_val >= 0;
						yy_i++ )
					{
						if ( yytoks[yy_i].t_val
							== yychar )
						{
							break;
						}
					}
					printf( "%s\n", yytoks[yy_i].t_name );
				}
			}
#endif /* YYDEBUG */
			/*
			** look through exception table
			*/
			{
				register YYCONST int *yyxi = yyexca;

				while ( ( *yyxi != -1 ) ||
					( yyxi[1] != yy_state ) )
				{
					yyxi += 2;
				}
				while ( ( *(yyxi += 2) >= 0 ) &&
					( *yyxi != yychar ) )
					;
				if ( ( yy_n = yyxi[1] ) < 0 )
					YYACCEPT;
			}
		}

		/*
		** check for syntax error
		*/
		if ( yy_n == 0 )	/* have an error */
		{
			/* no worry about speed here! */
			switch ( yyerrflag )
			{
			case 0:		/* new error */
				yyerror( "syntax error" );
				goto skip_init;
			yyerrlab:
				/*
				** get globals into registers.
				** we have a user generated syntax type error
				*/
				yy_pv = yypv;
				yy_ps = yyps;
				yy_state = yystate;
			skip_init:
				yynerrs++;
				/* FALLTHRU */
			case 1:
			case 2:		/* incompletely recovered error */
					/* try again... */
				yyerrflag = 3;
				/*
				** find state where "error" is a legal
				** shift action
				*/
				while ( yy_ps >= yys )
				{
					yy_n = yypact[ *yy_ps ] + YYERRCODE;
					if ( yy_n >= 0 && yy_n < YYLAST &&
						yychk[yyact[yy_n]] == YYERRCODE)					{
						/*
						** simulate shift of "error"
						*/
						yy_state = yyact[ yy_n ];
						goto yy_stack;
					}
					/*
					** current state has no shift on
					** "error", pop stack
					*/
#if YYDEBUG
#	define _POP_ "Error recovery pops state %d, uncovers state %d\n"
					if ( yydebug )
						printf( _POP_, *yy_ps,
							yy_ps[-1] );
#	undef _POP_
#endif
					yy_ps--;
					yy_pv--;
				}
				/*
				** there is no state on stack with "error" as
				** a valid shift.  give up.
				*/
				YYABORT;
			case 3:		/* no shift yet; eat a token */
#if YYDEBUG
				/*
				** if debugging, look up token in list of
				** pairs.  0 and negative shouldn't occur,
				** but since timing doesn't matter when
				** debugging, it doesn't hurt to leave the
				** tests here.
				*/
				if ( yydebug )
				{
					register int yy_i;

					printf( "Error recovery discards " );
					if ( yychar == 0 )
						printf( "token end-of-file\n" );
					else if ( yychar < 0 )
						printf( "token -none-\n" );
					else
					{
						for ( yy_i = 0;
							yytoks[yy_i].t_val >= 0;
							yy_i++ )
						{
							if ( yytoks[yy_i].t_val
								== yychar )
							{
								break;
							}
						}
						printf( "token %s\n",
							yytoks[yy_i].t_name );
					}
				}
#endif /* YYDEBUG */
				if ( yychar == 0 )	/* reached EOF. quit */
					YYABORT;
				yychar = -1;
				goto yy_newstate;
			}
		}/* end if ( yy_n == 0 ) */
		/*
		** reduction by production yy_n
		** put stack tops, etc. so things right after switch
		*/
#if YYDEBUG
		/*
		** if debugging, print the string that is the user's
		** specification of the reduction which is just about
		** to be done.
		*/
		if ( yydebug )
			printf( "Reduce by (%d) \"%s\"\n",
				yy_n, yyreds[ yy_n ] );
#endif
		yytmp = yy_n;			/* value to switch over */
		yypvt = yy_pv;			/* $vars top of value stack */
		/*
		** Look in goto table for next state
		** Sorry about using yy_state here as temporary
		** register variable, but why not, if it works...
		** If yyr2[ yy_n ] doesn't have the low order bit
		** set, then there is no action to be done for
		** this reduction.  So, no saving & unsaving of
		** registers done.  The only difference between the
		** code just after the if and the body of the if is
		** the goto yy_stack in the body.  This way the test
		** can be made before the choice of what to do is needed.
		*/
		{
			/* length of production doubled with extra bit */
			register int yy_len = yyr2[ yy_n ];

			if ( !( yy_len & 01 ) )
			{
				yy_len >>= 1;
				yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
				yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
					*( yy_ps -= yy_len ) + 1;
				if ( yy_state >= YYLAST ||
					yychk[ yy_state =
					yyact[ yy_state ] ] != -yy_n )
				{
					yy_state = yyact[ yypgo[ yy_n ] ];
				}
				goto yy_stack;
			}
			yy_len >>= 1;
			yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
			yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
				*( yy_ps -= yy_len ) + 1;
			if ( yy_state >= YYLAST ||
				yychk[ yy_state = yyact[ yy_state ] ] != -yy_n )
			{
				yy_state = yyact[ yypgo[ yy_n ] ];
			}
		}
					/* save until reenter driver code */
		yystate = yy_state;
		yyps = yy_ps;
		yypv = yy_pv;
	}
	/*
	** code supplied by user is placed in this switch
	*/
	switch( yytmp )
	{
		
case 1:{
                        T_FCALL *cp;
                        T_BLOCK *bp;

                        if (Se_errors == 0) {
                          symbol_check();
                          bp = GET_BLOCK("main");
                          if (bp == 0)
                            yyerror("undeclared block: main", ERR_FATAL);
                          do_main_check(bp);
                          for(cp=call_list; cp; cp=cp->c_next) {
                            cp->c_block = GET_BLOCK(cp->c_name);
                            if (cp->c_block)
                              do_param_check(cp);
                          }
                        }
                        } break;
case 4:{ } break;
case 5:{ } break;
case 6:{ } break;
case 7:{ } break;
case 8:{ } break;
case 9:{ } break;
case 10:{ } break;
case 11:{ } break;
case 12:{ } break;
case 13:{
                        T_RETURN *rp;

                        for(rp=return_list; rp; rp=rp->ret_next)
                          if (rp->ret_expr) {
                            snprintf(error_buf, sizeof error_buf,
                              "typeless function: %s may not return a value",
                               yypvt[-0].block->b_name);
                            yyerror(error_buf, ERR_NONFATAL);
                          }
                        } break;
case 14:{
                        char name[BUFSIZ];
                        T_VARIABLE *vp;

                        yyval.structure = NEW(T_STRUCT);
                        yyval.structure->st_flags = SF_KSTAT;
                        yyval.structure->st_kname = yypvt[-5].string;
                        yyval.structure->st_name = yypvt[-4].string;
                        yyval.structure->st_missing = 1;
                        yyval.structure->st_members = reverse_member_list(yypvt[-2].variable);
                        for(vp=yyval.structure->st_members; vp; vp=vp->var_next) {
                          if (vp->var_name[0] == '\0') {
                            snprintf(name, sizeof name,
                              "missing%d", yyval.structure->st_missing++);
                            se_new_string(&vp->var_name, name);
                            vp->var_qname = se_string_save("");
                          }
                        }
                        PUT_STRUCT(yypvt[-4].string, yyval.structure, NO_DUPS);
                        do_structure_check(yyval.structure);
                        if (yypvt[-5].string)
                          se_add_kstat_type(yyval.structure);
                        in_local_scope = 0;
                        current_scope = 0;
                        } break;
case 15:{
                          yyval.structure = yypvt[-0].structure;
                          yyval.structure->st_flags = SF_KSTAT;
                          } break;
case 16:{
                        yyval.structure = NEW(T_STRUCT);
                        yyval.structure->st_flags = SF_NDD;
                        yyval.structure->st_kname = yypvt[-5].string;
                        yyval.structure->st_name = yypvt[-4].string;
                        yyval.structure->st_missing = 1;
                        yyval.structure->st_members = reverse_member_list(yypvt[-2].variable);
                        PUT_STRUCT(yypvt[-4].string, yyval.structure, NO_DUPS);
                        do_structure_check(yyval.structure);
                        se_add_ndd_type(yyval.structure);
                        in_local_scope = 0;
                        current_scope = 0;
                        } break;
case 17:{
                          yyval.structure = yypvt[-0].structure;
                          yyval.structure->st_flags = SF_MIB;
                          } break;
case 18:{
                        yypvt[-0].variable->var_next = current_scope;
                        current_scope = yypvt[-0].variable;
                        yyval.variable = yypvt[-0].variable;
                        } break;
case 19:{
                        yypvt[-0].variable->var_next = current_scope;
                        current_scope = yypvt[-0].variable;
                        yyval.variable = yypvt[-0].variable;
                        } break;
case 20:{
                        char name[BUFSIZ];
                        T_VARIABLE *vp;

                        yyval.variable = NEW(T_VARIABLE);
                        yyval.variable->var_type = yypvt[-2].var_type;
                        yyval.variable->var_name = yypvt[-1].string;
                        if (yypvt[-2].var_type == VAR_USER)
                          yyerror("kstat contains no structures", ERR_FATAL);
                        if (se_get_keyword(yypvt[-1].string)) {
                          yyval.variable->var_qname = se_string_save(yypvt[-1].string);
                          snprintf(name, sizeof name, "SYM_%s", yypvt[-1].string);
                          se_new_string(&(yypvt[-1].string), name);
                        } else {
                          yyval.variable->var_qname = se_string_save(yypvt[-1].string);
                          if (se_cleanup_tok_syms(yypvt[-1].string) == 0) {
                            se_free(yyval.variable->var_qname);
                            yyval.variable->var_qname = 0;
                          }
                        }
                        /* do the missing thing in kstat_struct */
                        if (yypvt[-1].string[0] && (valid_name(yypvt[-1].string) == 0)) {
                          snprintf(error_buf, sizeof error_buf,
                            "invalid member name: %s", yypvt[-1].string);
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        for(vp=current_scope; vp; vp=vp->var_next)
                          if (yypvt[-1].string[0] && (strcmp(vp->var_name, yypvt[-1].string) == 0)) {
                            snprintf(error_buf, sizeof error_buf,
                              "redeclaration of %s", yypvt[-1].string);
                            yyerror(error_buf, ERR_NONFATAL);
                          }
                        } break;
case 21:{
                        yyval.string = yypvt[-0].string;
                        } break;
case 22:{
                        yyval.string = yypvt[-0].string;
                        } break;
case 23:{
                        T_VARIABLE *vp;
                        int size;

                        yyval.structure = NEW(T_STRUCT);
                        yyval.structure->st_name = yypvt[-4].string;
                        yyval.structure->st_members = reverse_member_list(yypvt[-2].variable);
                        PUT_STRUCT(yypvt[-4].string, yyval.structure, NO_DUPS);
                        do_structure_check(yyval.structure);
                        in_local_scope = 0;
                        current_scope = 0;
                        } break;
case 24:{
                        if (valid_name(yypvt[-0].string) == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "invalid struct name: %s", yypvt[-0].string);
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        in_local_scope = 1;
                        } break;
case 25:{
                        T_BLOCK *bp;
                        T_BLOCK *current = 0;
                        T_BLOCK *next;

                        do_attach_check(yypvt[-4].string, yypvt[-2].block);
                        for(bp=yypvt[-2].block; bp; bp=next) {
                          /* extern variable declaration within attach */
                          next = bp->b_next;
                          if (bp->b_flags == B_EXTERN) {
                            T_VARIABLE *vp = bp->b_variables;

                            vp->var_flags |= VF_EXTERN;
                            vp->var_address = (caddr_t) bp->b_attachment;
                            vp->var_attach_lib = yypvt[-4].string;
                            if (vp->var_type == VAR_USER)
                              se_address_inherit(vp, vp->var_address);
                            member_inherit(vp, VF_EXTERN);
                            se_free(bp);
                          } else {
                            bp->b_attach_lib = yypvt[-4].string;
                            if (current == 0)
                              current = bp;
                            else
                              current = current->b_next = bp;
                          }
                        }
                        } break;
case 26:{
                        do_attach_check(yypvt[-1].string, 0);
                        se_free(yypvt[-1].string);
                        } break;
case 27:{
                        yypvt[-0].block->b_next = yypvt[-1].block;
                        yyval.block = yypvt[-0].block;
                        } break;
case 28:{
                        yyval.block = yypvt[-0].block;
                        } break;
case 29:{
                        T_VARIABLE *vp;
                        int i;

                        /* count the params */
                        for(i=0, vp=yypvt[-2].variable; vp; vp=vp->var_next, i++) {
#ifdef _LP64
                          if (vp->var_type == VAR_DOUBLE)
                            yyerror( 
                              "cannot pass double values to attached functions",
                               ERR_NONFATAL);
#else
                          if (Se_type_sizes[vp->var_type] == 8)
                            yyerror( 
                              "cannot pass 8 byte values to attached functions",
                               ERR_NONFATAL);
#endif
                          if (vp->var_type == VAR_ELLIPSIS)
                            if (vp->var_next)
                              yyerror("ellipsis must be last parameter",
                                       ERR_NONFATAL);
                        }
                        yyval.block = NEW(T_BLOCK);
                        yyval.block->b_name = yypvt[-4].string;
                        yyval.block->b_parameters = yypvt[-2].variable;
                        yyval.block->b_param_count = i;
                        if (block_already_called)
                          yyval.block->b_flags = B_REFERENCED;
                        block_already_called = 0;
                        if (i > MAX_ATT_ARGS) {
                          snprintf(error_buf, sizeof error_buf,
                          "cannot send more than %d args to attached functions",
                             MAX_ATT_ARGS);
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        PUT_BLOCK(yypvt[-4].string, yyval.block, NO_DUPS);
                        if (get_builtin(yypvt[-4].string)) {
                          snprintf(error_buf, sizeof error_buf,
                            "redeclaration of builtin: %s",yypvt[-4].string);
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        if (yypvt[-5].var_type) {
                          vp = NEW(T_VARIABLE);
                          vp->var_type = yypvt[-5].var_type;
                          if (yypvt[-5].var_type == VAR_USER) {
                            vp->var_struct = GET_STRUCT(block_type);
                            vp->var_un.var_user = new_user_type(vp);
                            fix_offsets(vp->var_un.var_user, 0, 0);
                          }
                          yyval.block->b_return = vp;
                        }
                        current_scope = 0;
                        in_local_scope = 0;
                        } break;
case 30:{
                        yyval.block = NEW(T_BLOCK);
                        yyval.block->b_flags = B_EXTERN;
                        yyval.block->b_variables = yypvt[-1].variable;
                        yyval.block->b_name = yypvt[-1].variable->var_name;
                        } break;
case 31:{
                      yyval.var_type = yypvt[-0].var_type;
                      } break;
case 32:{
                      yyval.var_type = 0;
                      } break;
case 33:{
                        if (yypvt[-0].block->b_variables) {
                          T_VARIABLE *vp;
                          T_STRUCT *sp;

                          /* build the struct */
                          sp = NEW(T_STRUCT);
                          sp->st_members = yypvt[-0].block->b_variables;

                          /* build a variable of this struct */
                          vp = NEW(T_VARIABLE);
                          vp->var_type = VAR_USER;
                          vp->var_name =
                            se_string_save("class_local_variables");
                          vp->var_struct = sp;
                          vp->var_un.var_user = sp;
                          yypvt[-1].structure->st_local_vars = vp;
                        }
                        yypvt[-1].structure->st_class = yypvt[-0].block;
                        yyval.structure = yypvt[-1].structure;
                        current_class_name = 0;
                        } break;
case 34:{
                        current_class_name = yypvt[-0].string;
                        } break;
case 35:{
                        T_VARIABLE *vp;

                        in_class_scope = 1;
                        if (valid_name(yypvt[-2].string) == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "invalid class name: %s", yypvt[-2].string);
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        yyval.structure = NEW(T_STRUCT);
                        yyval.structure->st_name = yypvt[-2].string;
                        yyval.structure->st_members = reverse_member_list(yypvt[-0].variable);
                        /* arrays must be allocated */
                        for(vp=yyval.structure->st_members; vp; vp=vp->var_next)
                          if (vp->var_dimension)
                            vp->var_un.var_array = new_array_type(vp);
                          /* as do structures */
                          else if (vp->var_type == VAR_USER)
                            vp->var_un.var_user = new_user_type(vp);
                        class_scope = yyval.structure->st_members;
                        PUT_STRUCT(yypvt[-2].string, yyval.structure, NO_DUPS);
                        do_structure_check(yyval.structure);
                        } break;
case 36:{
                        yyval.block = yypvt[-2].block;
                        if (yypvt[-2].block->b_parameters)
                          yyerror("class code may not accept parameters",
                                   ERR_NONFATAL);
                        in_class_scope = 0;
                        class_scope = 0;
                        } break;
case 37:{
                        yypvt[-0].variable->var_next = current_scope;
                        current_scope = yypvt[-0].variable;
                        yyval.variable = yypvt[-0].variable;
                        } break;
case 38:{
                        yypvt[-0].variable->var_next = current_scope;
                        current_scope = yypvt[-0].variable;
                        yyval.variable = yypvt[-0].variable;
                        } break;
case 39:{
                        T_VARIABLE *vp;

                        if (valid_name(yypvt[-1].string) == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "invalid member name: %s", yypvt[-1].string);
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        yyval.variable = NEW(T_VARIABLE);
                        yyval.variable->var_type = yypvt[-2].var_type;
                        yyval.variable->var_name = yypvt[-1].string;
                        if (get_special_name(yypvt[-1].string))
                          yyerror(
                            "structure members may not be active variables",
                               ERR_NONFATAL);
                        if (yypvt[-2].var_type == VAR_USER)
                          yyval.variable->var_struct = GET_STRUCT(type_name);
                        if (in_class_scope) {
                          for(vp=class_scope; vp; vp=vp->var_next)
                            if (strcmp(vp->var_name, yypvt[-1].string) == 0) {
                              snprintf(error_buf, sizeof error_buf,
                                "redeclaration of %s", yypvt[-1].string);
                              yyerror(error_buf, ERR_NONFATAL);
                            }
                        } else
                          for(vp=current_scope; vp; vp=vp->var_next)
                            if (strcmp(vp->var_name, yypvt[-1].string) == 0) {
                              snprintf(error_buf, sizeof error_buf,
                                "redeclaration of %s", yypvt[-1].string);
                              yyerror(error_buf, ERR_NONFATAL);
                            }
                        } break;
case 40:{
                        int n = 1;	/* if bad dimension, size is 1 */
                        T_VARIABLE *vp;
                        T_VARIABLE var;

                        if (valid_name(yypvt[-4].string) == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "invalid member name: %s", yypvt[-4].string);
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        if (yypvt[-2].expression) {
                          if (integral_constant_expression(yypvt[-2].expression, INT_TYPES) == 0)
                            yyerror("integral constant expression expected",
                                     ERR_NONFATAL);
                          else {
                            var = zero_variable;
                            se_resolve_expression(&var, yypvt[-2].expression, 0);
                            n = var.var_un.var_register;
                            if (n <= 0) {
                              snprintf(error_buf, sizeof error_buf,
                                      "absurd subscript value: %d", n);
                              yyerror(error_buf, ERR_NONFATAL);
                              n = 1;
                            }
                          }
                        } else
                          n = -1;
                        yyval.variable = NEW(T_VARIABLE);
                        yyval.variable->var_type = yypvt[-5].var_type;
                        yyval.variable->var_name = yypvt[-4].string;
                        yyval.variable->var_dimension = n;
                        if (n == -1)
                          yyval.variable->var_flags = VF_EMPTY;
                        if (get_special_name(yypvt[-4].string))
                          yyerror(
                            "structure members may not be active variables",
                               ERR_NONFATAL);
                        if (yypvt[-5].var_type == VAR_USER)
                          yyval.variable->var_struct = GET_STRUCT(type_name);
                        if (in_class_scope) {
                          for(vp=class_scope; vp; vp=vp->var_next)
                            if (strcmp(vp->var_name, yypvt[-4].string) == 0) {
                              snprintf(error_buf, sizeof error_buf,
                                "redeclaration of %s", yypvt[-4].string);
                              yyerror(error_buf, ERR_NONFATAL);
                            }
                        } else
                          for(vp=current_scope; vp; vp=vp->var_next)
                            if (strcmp(vp->var_name, yypvt[-4].string) == 0) {
                              snprintf(error_buf, sizeof error_buf,
                                "redeclaration of %s", yypvt[-4].string);
                              yyerror(error_buf, ERR_NONFATAL);
                            }
                        } break;
case 41:{
                        yyval.variable = yypvt[-0].variable;
                        } break;
case 42:{
                        yyval.variable = yypvt[-0].variable;
                        yyval.variable->var_special = SS_KVM;
                        } break;
case 43:{
                        yypvt[-2].variable->var_initial = yypvt[-1].expression;
                        if (yypvt[-1].expression) {
                          if (yypvt[-2].variable->var_dimension ||
                               ((yypvt[-2].variable->var_type == VAR_USER) &&
                                (yypvt[-1].expression->e_type == E_AGGREGATE))) {
                            T_VARIABLE *vp = 0;
                            char *op = "\"CALL\"";

                            switch (yypvt[-1].expression->e_type) {
                            case E_EXPRESSION:
                              yyerror("{}-enclosed initializer required",
                                       ERR_NONFATAL);
                              break;
                            case E_VALUE:
                              if ((yypvt[-2].variable->var_type == VAR_CHAR) &&
                                  (yypvt[-1].expression->e_variable->var_type == VAR_STRING)) {
                                vp = yypvt[-1].expression->e_variable;
                                break;
                              }
                              /* fall through */
                            default:
                              op = "\"VALUE\"";
                              /* fall through */
                            case E_CALL:
                              snprintf(error_buf, sizeof error_buf,
                                "non-constant initializer: op %s", op);
                              yyerror(error_buf, ERR_NONFATAL);
                              break;
                            case E_AGGREGATE:
                              vp = yypvt[-1].expression->e_variable;
                              yypvt[-1].expression->e_type = E_VALUE;
                              break;
                            }
                            if (vp) {
                              do_aggregate_check(yypvt[-2].variable, vp);
                              free_aggregate(yypvt[-1].expression->e_variable);
                              se_free(yypvt[-1].expression);
                              yypvt[-2].variable->var_flags |= VF_AGGREGATE;
                            }
                            yypvt[-2].variable->var_initial = 0;
                          } else
                            do_assign_check(yypvt[-2].variable, yypvt[-1].expression, "initialization", 0);
                        }
                        yyval.variable = yypvt[-2].variable;
                        } break;
case 44:{
                        if (valid_name(yypvt[-0].string) == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "invalid variable name: %s", yypvt[-0].string);
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        yyval.variable = NEW(T_VARIABLE);
                        yyval.variable->var_type = yypvt[-1].var_type;
                        yyval.variable->var_name = yypvt[-0].string;
                        if (in_local_scope) {
                          /* ok to redeclare global, not local */
                          if (GET_VARIABLE(yyval.variable->var_name)) {
                            snprintf(error_buf, sizeof error_buf,
                                "declaration of %s hides earlier one",
                                yyval.variable->var_name);
                            yyerror(error_buf, ERR_WARNING);
                          } else if (get_variable(yyval.variable->var_name)) {
                            snprintf(error_buf, sizeof error_buf,
                              "redeclaration of %s", yyval.variable->var_name);
                            yyerror(error_buf, ERR_NONFATAL);
                          }
                        } else
                          PUT_VARIABLE(yypvt[-0].string, yyval.variable, NO_DUPS);

                        if (yypvt[-1].var_type == VAR_USER) {
                          yyval.variable->var_struct = GET_STRUCT(type_name);
                          if (in_class_scope &&
                             (strcmp(type_name, current_class_name) == 0)) {
                              snprintf(error_buf, sizeof error_buf,
                                "incomplete type: %s", type_name);
                              yyerror(error_buf, ERR_FATAL);
                          } else {
                            yyval.variable->var_un.var_user = new_user_type(yyval.variable);
                            fix_offsets(yyval.variable->var_un.var_user, 0, 0);
                          }
                        }
                        do_special_check(yypvt[-0].string, yyval.variable);
                        } break;
case 45:{
                        int i;
                        int n = 1;	/* if bad dimension, size is 1 */
                        T_VARIABLE var;

                        if (valid_name(yypvt[-3].string) == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "invalid variable name: %s", yypvt[-3].string);
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        if (yypvt[-1].expression) {
                          if (integral_constant_expression(yypvt[-1].expression, INT_TYPES) == 0)
                            yyerror("integral constant expression expected",
                                     ERR_NONFATAL);
                          else {
                            var = zero_variable;
                            se_resolve_expression(&var, yypvt[-1].expression, 0);
                            n = var.var_un.var_register;
                            if (n <= 0) {
                              snprintf(error_buf, sizeof error_buf,
                                      "absurd subscript value: %d", n);
                              yyerror(error_buf, ERR_NONFATAL);
                              n = 1;
                            }
                          }
                        } else
                          n = -1;
                        yyval.variable = NEW(T_VARIABLE);
                        yyval.variable->var_type = yypvt[-4].var_type;
                        yyval.variable->var_name = yypvt[-3].string;
                        yyval.variable->var_dimension = n;
                        if (n == -1)
                          yyval.variable->var_flags = VF_EMPTY;
                        if (yypvt[-4].var_type == VAR_USER)
                          yyval.variable->var_struct = GET_STRUCT(type_name);
                        yyval.variable->var_un.var_array = new_array_type(yyval.variable);
                        if ((yypvt[-4].var_type == VAR_USER) && (n != -1)) {
                          T_STRUCT **spp;
                          int size;

                          spp = ((T_STRUCT **) yyval.variable->var_un.var_array);
                          size = spp[0]->st_size;
                          for(i=0; i<n; i++)
                            fix_offsets(spp[i], size * i, 1);
                        }
                        if (in_local_scope) {
                          if (get_variable(yyval.variable->var_name)) {
                            snprintf(error_buf, sizeof error_buf,
                              "redeclaration of %s", yyval.variable->var_name);
                            yyerror(error_buf, ERR_NONFATAL);
                          }
                        } else
                          PUT_VARIABLE(yypvt[-3].string, yyval.variable, NO_DUPS);
                        do_special_check(yypvt[-3].string, yyval.variable);
                        if ((yyval.variable->var_flags & VF_SPECIAL) == VF_CLASS)
                          yyerror(
                            "arrays of active class variables not allowed",
                            ERR_NONFATAL);
                        if (((yyval.variable->var_flags & VF_KVM) == VF_KVM) &&
                             (yypvt[-1].expression == 0))
                          yyerror(
                            "dynamic arrays of kvm variables not allowed",
                            ERR_NONFATAL);
                        } break;
case 46:{
                        yyval.expression = yypvt[-0].expression;
                        } break;
case 47:{
                        yyval.expression = 0;
                        } break;
case 48:{
                        yyval.expression = yypvt[-0].expression;
                        } break;
case 49:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_AGGREGATE;
                        yyval.expression->e_variable = yypvt[-0].variable;
                        } break;
case 50:{
                        yyval.expression = 0;
                        } break;
case 51:{
                        yyval.variable = NEW(T_VARIABLE);
                        yyval.variable->var_name = se_string_save("aggregate");
                        yyval.variable->var_type = VAR_USER;
                        yyval.variable->var_struct = NEW(T_STRUCT);
                        yyval.variable->var_struct->st_members = reverse_member_list(yypvt[-1].variable);
                        } break;
case 52:{
                        yypvt[-0].variable->var_next = yypvt[-2].variable;
                        yyval.variable = yypvt[-0].variable;
                        } break;
case 53:{
                        yyval.variable = yypvt[-0].variable;
                        } break;
case 54:{
                        yyval.variable = NEW(T_VARIABLE);
                        if (integral_constant_expression(yypvt[-0].expression, AGG_TYPES) == 0) {
                          yyerror("integral constant expression expected",
                                   ERR_NONFATAL);
                          yyval.variable->var_type = VAR_BOGUS;
                        } else
                          se_resolve_expression(yyval.variable, yypvt[-0].expression, 0);
                        } break;
case 55:{
                        yyval.variable = yypvt[-0].variable;
                        } break;
case 56:{
                        yyval.var_type = VAR_STRING;
                        } break;
case 57:{
                        yyval.var_type = VAR_CHAR;
                        } break;
case 58:{
                        yyval.var_type = VAR_SHORT;
                        } break;
case 59:{
                        yyval.var_type = VAR_LONG;
                        } break;
case 60:{
                        yyval.var_type = VAR_LONGLONG;
                        } break;
case 61:{
                        yyval.var_type = VAR_UCHAR;
                        } break;
case 62:{
                        yyval.var_type = VAR_USHORT;
                        } break;
case 63:{
                        yyval.var_type = VAR_ULONG;
                        } break;
case 64:{
                        yyval.var_type = VAR_ULONGLONG;
                        } break;
case 65:{
                        yyval.var_type = VAR_DOUBLE;
                        } break;
case 66:{
                        /* the scanner will do a symbol table lookup and *
                         * return this token.  Grab the type name from   *
                         * Lex_currtok.                                  */
                        strcpy(type_name,  Lex_currtok);
                        if (in_local_scope == 0)
                          strcpy(block_type, Lex_currtok);
                        yyval.var_type = VAR_USER;
                        } break;
case 67:{
                        if (strcmp(yypvt[-2].string, "referenced") == 0) {
                          T_VARIABLE *vp;

                          vp = get_variable(yypvt[-1].string);
                          if (vp == 0) {
                            snprintf(error_buf, sizeof error_buf,
                              "pragma: variable %s is not declared", yypvt[-1].string);
                            yyerror(error_buf, ERR_WARNING);
                          } else
                            vp->var_flags = (T_VFTYPE)
                              ((int) vp->var_flags | (int) (VF_REFERENCED | VF_PRAGMA_REF));
                        } else {
                          snprintf(error_buf, sizeof error_buf,
                            "unknown pragma: %s", yypvt[-2].string);
                          yyerror(error_buf, ERR_WARNING);
                        }
                        se_free(yypvt[-2].string);
                        se_free(yypvt[-1].string);
                        } break;
case 68:{
                        T_VARIABLE *vp;
                        T_RETURN *rp;

                        vp = NEW(T_VARIABLE);
                        vp->var_type = yypvt[-1].var_type;
                        if (yypvt[-1].var_type == VAR_USER) {
                          vp->var_struct = GET_STRUCT(block_type);
                          vp->var_un.var_user = new_user_type(vp);
                        }
                        if (return_list == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "function: %s returns no value", yypvt[-0].block->b_name);
                          yyerror(error_buf, ERR_WARNING);
                        }
                        for(rp=return_list; rp; rp=rp->ret_next)
                          do_return_check(vp, rp);
                        yypvt[-0].block->b_return = vp;
                        yyval.block = yypvt[-0].block;
                        } break;
case 69:{
                        T_RETURN *rp;
                        T_VARIABLE *vp;
                        int i;
                        int ellipsis = 0;

                        /* count the params */
                        for(i=0, vp=yypvt[-5].variable; vp; vp=vp->var_next, i++)
                          if (vp->var_type == VAR_ELLIPSIS)
                            ellipsis++;
                        if (ellipsis)
                         yyerror("ellipsis only allowed for attached functions",
                                   ERR_NONFATAL);
                        /* unlink the local var list from the param list */
                        if (last_variable) {
                          last_variable->var_next = 0;
                          last_variable = 0;
                        }
                        yyval.block = NEW(T_BLOCK);
                        yyval.block->b_name = yypvt[-7].string;
                        yyval.block->b_parameters = yypvt[-5].variable;
                        yyval.block->b_param_count = i;
                        yyval.block->b_variables = reverse_member_list(yypvt[-2].variable);
                        yyval.block->b_statements = yypvt[-1].statement;
                        if (in_class_scope)
                          add_special_name(yypvt[-7].string);
                        else
                          PUT_BLOCK(yypvt[-7].string, yyval.block, ALLOW_DUPS);
                        current_scope = 0;
                        in_local_scope = 0;
                        for(rp=return_list; rp; rp=rp->ret_next)
                          rp->ret_block = yyval.block;
                        current_scope_name = 0;
                        if (get_builtin(yypvt[-7].string)) {
                          snprintf(error_buf, sizeof error_buf,
                            "redeclaration of builtin: %s",yypvt[-7].string);
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        block_already_called = 0;
                        } break;
case 70:{
                        if (valid_name(yypvt[-0].string) == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "invalid block name: %s", yypvt[-0].string);
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        if (in_class_scope == 0) {
                          if (avlget(Se_symbol_table, yypvt[-0].string))
                            block_already_called = 1;
                          /* this will check for dups */
                          PUT_BLOCK(yypvt[-0].string, 0, NO_DUPS);
                        }
                        in_local_scope = 1;
                        current_scope_name = yypvt[-0].string;
                        return_list = 0;
                        yyval.string = yypvt[-0].string;
                        } break;
case 71:{
                        yyval.variable = yypvt[-0].variable;
                        } break;
case 72:{
                        yyval.variable = 0;
                        } break;
case 73:{
                        yypvt[-0].variable->var_next = current_scope;
                        current_scope = yypvt[-0].variable;
                        yyval.variable = yypvt[-0].variable;
                        } break;
case 74:{
                        yypvt[-0].variable->var_next = current_scope;
                        current_scope = yypvt[-0].variable;
                        last_variable = yypvt[-0].variable;
                        yyval.variable = yypvt[-0].variable;
                        } break;
case 75:{
                        T_VARIABLE *vp;

                        yyval.variable = reverse_member_list(yypvt[-0].variable);
                        current_scope = yyval.variable;
                        for(vp=current_scope; vp; vp=vp->var_next)
                          if (vp->var_flags & VF_SPECIAL)
                            yyerror("special variables cannot be parameters",
                                     ERR_NONFATAL);
                        } break;
case 76:{
                        yyval.variable = 0;
                        } break;
case 77:{
                        yypvt[-0].variable->var_next = current_scope;
                        current_scope = yypvt[-0].variable;
                        yyval.variable = yypvt[-0].variable;
                        /* last_parameter = $3; */
                        } break;
case 78:{
                        last_parameter = yypvt[-0].variable;
                        yyval.variable = yypvt[-0].variable;
                        current_scope = yypvt[-0].variable;
                        } break;
case 79:{
                        yyval.variable = yypvt[-0].variable;
                        } break;
case 80:{
                        yyval.variable = NEW(T_VARIABLE);
                        yyval.variable->var_type = VAR_ELLIPSIS;
                        yyval.variable->var_name = se_string_save("ellipsis");
                        } break;
case 81:{
                        yyval.string = se_string_save(Lex_currtok);
                        } break;
case 82:{
                        yyval.string = se_string_save(se_kill_double_quotes(Lex_currtok));
                        } break;
case 83:{
                        yyval.statement = reverse_statement_list(yypvt[-0].statement);
                        } break;
case 84:{
                        yypvt[-0].statement->s_next = yypvt[-1].statement;
                        yypvt[-0].statement->s_line_no = Lex_line_no;
                        yyval.statement = yypvt[-0].statement;
                        } break;
case 85:{
                        yyval.statement = yypvt[-0].statement;
                        } break;
case 86:{
                        yyval.statement = yypvt[-0].statement;
                        } break;
case 87:{
                        yyval.statement = yypvt[-1].statement;
                        } break;
case 88:{
                        yyval.statement = NEW(T_STATEMENT);
                        yyval.statement->s_type = S_NULL;
                        yyval.statement->s_function = Se_functions[S_NULL];
                        } break;
case 89:{
                        yyval.statement = NEW(T_STATEMENT);
                        yyval.statement->s_type = S_IF;
                        yyval.statement->s_un.s_if = yypvt[-0].if_statement;
                        yyval.statement->s_function = Se_functions[S_IF];
                        } break;
case 90:{
                        yyval.statement = NEW(T_STATEMENT);
                        yyval.statement->s_type = S_WHILE;
                        yyval.statement->s_un.s_while = yypvt[-0].while_statement;
                        yyval.statement->s_function = Se_functions[S_WHILE];
                        } break;
case 91:{
                        yyval.statement = NEW(T_STATEMENT);
                        yyval.statement->s_type = S_FOR;
                        yyval.statement->s_un.s_for = yypvt[-0].for_statement;
                        yyval.statement->s_function = Se_functions[S_FOR];
                        } break;
case 92:{
                        yyval.statement = NEW(T_STATEMENT);
                        yyval.statement->s_type = S_DO;
                        yyval.statement->s_un.s_do = yypvt[-0].do_statement;
                        yyval.statement->s_function = Se_functions[S_DO];
                        } break;
case 93:{
                        yyval.statement = NEW(T_STATEMENT);
                        yyval.statement->s_type = S_SWITCH;
                        yyval.statement->s_un.s_switch = yypvt[-0].switch_statement;
                        yyval.statement->s_function = Se_functions[S_SWITCH];
                        } break;
case 94:{
                        yyval.statement = NEW(T_STATEMENT);
                        yyval.statement->s_type = S_RETURN;
                        yyval.statement->s_un.s_return = yypvt[-0].return_statement;
                        yyval.statement->s_function = Se_functions[S_RETURN];
                        } break;
case 95:{
                        yyval.statement = NEW(T_STATEMENT);
                        yyval.statement->s_type = S_BREAK;
                        yyval.statement->s_un.s_break = yypvt[-0].break_statement;
                        yyval.statement->s_function = Se_functions[S_BREAK];
                        } break;
case 96:{
                        yyval.statement = NEW(T_STATEMENT);
                        yyval.statement->s_type = S_CONTINUE;
                        yyval.statement->s_un.s_continue = yypvt[-0].continue_statement;
                        yyval.statement->s_function = Se_functions[S_CONTINUE];
                        } break;
case 97:{
                        yyval.statement = NEW(T_STATEMENT);
                        yyval.statement->s_type = S_CALL;
                        yyval.statement->s_un.s_call = yypvt[-0].call_statement;
                        yyval.statement->s_function = Se_functions[S_CALL];
                        } break;
case 98:{
                        T_VARIABLE *vp = yypvt[-0].assign_statement->a_variable;

                        yyval.statement = NEW(T_STATEMENT);
                        yyval.statement->s_type = S_ASSIGN;
                        yyval.statement->s_un.s_assign = yypvt[-0].assign_statement;
                        yyval.statement->s_function = Se_functions[S_ASSIGN];
                        if (is_lazy(vp))
                          yyval.statement = do_lazy_lvalue(yyval.statement);
                        } break;
case 99:{
                        yyval.statement = NEW(T_STATEMENT);
                        yyval.statement->s_type = S_INCREMENT;
                        yyval.statement->s_un.s_variable = yypvt[-0].variable;
                        yyval.statement->s_function = Se_functions[S_INCREMENT];
                        if (is_lazy(yypvt[-0].variable))
                          yyval.statement = do_lazy_lvalue(yyval.statement);
                        } break;
case 100:{
                        yyval.statement = NEW(T_STATEMENT);
                        yyval.statement->s_type = S_DECREMENT;
                        yyval.statement->s_un.s_variable = yypvt[-0].variable;
                        yyval.statement->s_function = Se_functions[S_DECREMENT];
                        if (is_lazy(yypvt[-0].variable))
                          yyval.statement = do_lazy_lvalue(yyval.statement);
                        } break;
case 101:{
                        yyval.variable = yypvt[-1].variable;
                        if (yyval.variable && (((yyval.variable->var_type & VAR_INTEGRAL) == 0) ||
                                   ((yyval.variable->var_dimension &&
                                    (yyval.variable->var_subscript == 0))))) {
                          yyerror("operands must have scalar type: op \"++\"",
                                   ERR_NONFATAL);
                        }
                        } break;
case 102:{
                        yyval.variable = yypvt[-0].variable;
                        if (yyval.variable && (((yyval.variable->var_type & VAR_INTEGRAL) == 0)) ||
                                   ((yyval.variable->var_dimension &&
                                    (yyval.variable->var_subscript == 0)))) {
                          yyerror("operands must have scalar type: op \"++\"",
                                   ERR_NONFATAL);
                        }
                        } break;
case 103:{
                        yyval.variable = yypvt[-1].variable;
                        if (yyval.variable && (((yyval.variable->var_type & VAR_INTEGRAL) == 0)) ||
                                   ((yyval.variable->var_dimension &&
                                    (yyval.variable->var_subscript == 0)))) {
                          yyerror("operands must have scalar type: op \"--\"",
                                   ERR_NONFATAL);
                        }
                        } break;
case 104:{
                        yyval.variable = yypvt[-0].variable;
                        if (yyval.variable && (((yyval.variable->var_type & VAR_INTEGRAL) == 0)) ||
                                   ((yyval.variable->var_dimension &&
                                    (yyval.variable->var_subscript == 0)))) {
                          yyerror("operands must have scalar type: op \"--\"",
                                   ERR_NONFATAL);
                        }
                        } break;
case 105:{
                        yyval.for_statement = NEW(T_FOR);
                        yyval.for_statement->f_before = yypvt[-8].statement;
                        yyval.for_statement->f_while = yypvt[-6].l_expression;
                        yyval.for_statement->f_after = yypvt[-4].statement;
                        yyval.for_statement->f_statements = yypvt[-1].statement;
                        do_for_check(yyval.for_statement);
                        break_list = (T_BREAK *) pop(&break_stack);
                        continue_list = (T_CONTINUE *) pop(&continue_stack);
                        } break;
case 106:{
                        yyval.do_statement = NEW(T_DO);
                        yyval.do_statement->do_statements = yypvt[-6].statement;
                        yyval.do_statement->do_while = yypvt[-2].l_expression;
                        do_do_check(yyval.do_statement);
                        break_list = (T_BREAK *) pop(&break_stack);
                        continue_list = (T_CONTINUE *) pop(&continue_stack);
                        } break;
case 107:{
                        push(break_list, &break_stack);
                        push(continue_list, &continue_stack);
                        } break;
case 108:{
                        push(break_list, &break_stack);
                        push(continue_list, &continue_stack);
                        } break;
case 109:{
                        yypvt[-0].statement->s_next = yypvt[-2].statement;
                        yyval.statement = yypvt[-0].statement;
                        } break;
case 110:{
                        yyval.statement = yypvt[-0].statement;
                        } break;
case 111:{
                        yyval.statement = reverse_statement_list(yypvt[-0].statement);
                        } break;
case 112:{
                        yyval.statement = 0;
                        } break;
case 113:{
                        yyval.l_expression = yypvt[-0].l_expression;
                        } break;
case 114:{
                        yyval.l_expression = 0;
                        } break;
case 115:{
                        yyval.switch_statement = NEW(T_SWITCH);
                        yyval.switch_statement->sw_expr = yypvt[-4].expression;
                        yyval.switch_statement->sw_case_list = yypvt[-1].case_statement;
                        do_switch_check(yyval.switch_statement);
                        break_list = (T_BREAK *) pop(&break_stack);
                        } break;
case 116:{
                        push(break_list, &break_stack);
                        } break;
case 117:{
                        yyval.case_statement = reverse_case_list(yypvt[-0].case_statement);
                        } break;
case 118:{
                        yypvt[-0].case_statement->ca_next = yypvt[-1].case_statement;
                        yyval.case_statement = yypvt[-0].case_statement;
                        } break;
case 119:{
                        yyval.case_statement = yypvt[-0].case_statement;
                        } break;
case 120:{
                        yyval.case_statement = yypvt[-3].case_statement;
                        yyval.case_statement->ca_value = yypvt[-2].variable;
                        yyval.case_statement->ca_statements = yypvt[-0].statement;
                        } break;
case 121:{
                        yyval.case_statement = yypvt[-2].case_statement;
                        yyval.case_statement->ca_statements = yypvt[-0].statement;
                        } break;
case 122:{
                        yyval.statement = yypvt[-0].statement;
                        } break;
case 123:{
                        yyval.statement = 0;
                        } break;
case 124:{
                        yyval.case_statement = NEW(T_CASE);
                        yyval.case_statement->ca_line_no = Lex_line_no;
                        } break;
case 125:{
                        yyval.case_statement = NEW(T_CASE);
                        yyval.case_statement->ca_line_no = Lex_line_no;
                        } break;
case 126:{
                        yyval.break_statement = NEW(T_BREAK);
                        if (break_stack.st_top == 0)
                          yyerror("\"break\" outside loop or switch",
                                    ERR_NONFATAL);
                        else {
                          yyval.break_statement->brk_next = break_list;
                          break_list = yyval.break_statement;
                        }
                        } break;
case 127:{
                        yyval.continue_statement = NEW(T_CONTINUE);
                        if (continue_stack.st_top == 0)
                          yyerror("\"continue\" outside loop",
                                    ERR_NONFATAL);
                        else {
                          yyval.continue_statement->con_next = continue_list;
                          continue_list = yyval.continue_statement;
                        }
                        } break;
case 128:{
                        yyval.return_statement = NEW(T_RETURN);
                        yyval.return_statement->ret_line_no = Lex_line_no;
                        yyval.return_statement->ret_next = return_list;
                        return_list = yyval.return_statement;
                        } break;
case 129:{
                        yyval.return_statement = NEW(T_RETURN);
                        yyval.return_statement->ret_expr = yypvt[-1].expression;
                        yyval.return_statement->ret_line_no = Lex_line_no;
                        yyval.return_statement->ret_next = return_list;
                        return_list = yyval.return_statement;
                        } break;
case 130:{
                        yyval.if_statement = NEW(T_IF);
                        yyval.if_statement->i_if = yypvt[-5].l_expression;
                        yyval.if_statement->i_then = yypvt[-2].statement;
                        yyval.if_statement->i_else = yypvt[-0].statement;
                        } break;
case 131:{
                        yyval.statement = yypvt[-1].statement;
                        } break;
case 132:{
                        yyval.statement = 0;
                        } break;
case 133:{
                        yyval.l_expression = yypvt[-0].l_expression;
                        } break;
case 134:{
                        yyval.l_expression = NEW(T_LEXPR);
                        yyval.l_expression->le_left = (T_EXPR *) yypvt[-1].l_expression;
                        yyval.l_expression->le_op = LE_PREC;
                        } break;
case 135:{
                        yyval.l_expression = NEW(T_LEXPR);
                        yyval.l_expression->le_left = (T_EXPR *) yypvt[-1].l_expression;
                        yyval.l_expression->le_op = LE_NOT;
                        } break;
case 136:{
                        yyval.l_expression = NEW(T_LEXPR);
                        yyval.l_expression->le_left = yypvt[-2].expression;
                        yyval.l_expression->le_op = LE_LT;
                        yyval.l_expression->le_right = yypvt[-0].expression;
                        l_expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, "<");
                        } break;
case 137:{
                        yyval.l_expression = NEW(T_LEXPR);
                        yyval.l_expression->le_left = yypvt[-2].expression;
                        yyval.l_expression->le_op = LE_GT;
                        yyval.l_expression->le_right = yypvt[-0].expression;
                        l_expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, ">");
                        } break;
case 138:{
                        yyval.l_expression = NEW(T_LEXPR);
                        yyval.l_expression->le_left = yypvt[-2].expression;
                        yyval.l_expression->le_op = LE_LE;
                        yyval.l_expression->le_right = yypvt[-0].expression;
                        l_expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, "<=");
                        } break;
case 139:{
                        yyval.l_expression = NEW(T_LEXPR);
                        yyval.l_expression->le_left = yypvt[-2].expression;
                        yyval.l_expression->le_op = LE_GE;
                        yyval.l_expression->le_right = yypvt[-0].expression;
                        l_expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, ">=");
                        } break;
case 140:{
                        yyval.l_expression = NEW(T_LEXPR);
                        yyval.l_expression->le_left = yypvt[-2].expression;
                        yyval.l_expression->le_op = LE_EQ;
                        yyval.l_expression->le_right = yypvt[-0].expression;
                        l_expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, "==");
                        } break;
case 141:{
                        yyval.l_expression = NEW(T_LEXPR);
                        yyval.l_expression->le_left = yypvt[-2].expression;
                        yyval.l_expression->le_op = LE_RE_EQ;
                        yyval.l_expression->le_right = yypvt[-0].expression;
                        l_expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, "=~");
                        } break;
case 142:{
                        yyval.l_expression = NEW(T_LEXPR);
                        yyval.l_expression->le_left = yypvt[-2].expression;
                        yyval.l_expression->le_op = LE_RE_NEQ;
                        yyval.l_expression->le_right = yypvt[-0].expression;
                        l_expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, "!=~");
                        } break;
case 143:{
                        yyval.l_expression = NEW(T_LEXPR);
                        yyval.l_expression->le_left = yypvt[-2].expression;
                        yyval.l_expression->le_op = LE_NE;
                        yyval.l_expression->le_right = yypvt[-0].expression;
                        l_expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, "!=");
                        } break;
case 144:{
                        yyval.l_expression = NEW(T_LEXPR);
                        yyval.l_expression->le_left = (T_EXPR *) yypvt[-2].l_expression;
                        yyval.l_expression->le_op = LE_AND;
                        yyval.l_expression->le_right = (T_EXPR *) yypvt[-0].l_expression;
                        } break;
case 145:{
                        yyval.l_expression = NEW(T_LEXPR);
                        yyval.l_expression->le_left = (T_EXPR *) yypvt[-2].l_expression;
                        yyval.l_expression->le_op = LE_OR;
                        yyval.l_expression->le_right = (T_EXPR *) yypvt[-0].l_expression;
                        } break;
case 146:{
                        T_BMAP *bp;
                        T_EXPR *ep;
                        int i;

                        /* count the args */
                        for(i=0, ep=yypvt[-1].expression; ep; ep=ep->e_next, i++)
                          ;
                        yyval.call_statement = NEW(T_FCALL);
                        yyval.call_statement->c_name = yypvt[-3].string;
                        yyval.call_statement->c_args = yypvt[-1].expression;
                        yyval.call_statement->c_arg_count = i;
                        yyval.call_statement->c_line_no = Lex_line_no;
                        yyval.call_statement->c_block = GET_BLOCK(yypvt[-3].string);
                        bp = get_builtin(yypvt[-3].string);
                        if (bp) {
                          do_builtin_check(bp, 0, yyval.call_statement, yypvt[-1].expression, i);
                          yyval.call_statement->c_builtin = Se_functions[bp->bm_stype];
                        } else {
                          yyval.call_statement->c_next = call_list;
                          call_list = yyval.call_statement;
                          if (yyval.call_statement->c_block) {
                            if (current_scope_name &&
                               (strcmp(yypvt[-3].string, current_scope_name) == 0)) {
                              snprintf(error_buf, sizeof error_buf,
                                "recursive call to: %s", yypvt[-3].string);
                              yyerror(error_buf, ERR_NONFATAL);
                            }
                            if (yyval.call_statement->c_block->b_attachment) {
                              if (yyval.call_statement->c_arg_count > MAX_ATT_ARGS) {
                                snprintf(error_buf, sizeof error_buf,
                          "cannot send more than %d args to attached functions",
                                   MAX_ATT_ARGS);
                                yyerror(error_buf, ERR_NONFATAL);
                              }
                              yyval.call_statement->c_block->b_flags |= B_REFERENCED;
                              yyval.call_statement->c_builtin = Se_functions[S_ATTACHMENT];
                            }
                          } else {
                            PUT_BLOCK(yypvt[-3].string, 0, ALLOW_DUPS);
                          }
                        }
                        } break;
case 147:{
                        yyval.while_statement = NEW(T_WHILE);
                        yyval.while_statement->w_expr = yypvt[-4].l_expression;
                        yyval.while_statement->w_statements = yypvt[-1].statement;
                        do_while_check(yyval.while_statement);
                        break_list = (T_BREAK *) pop(&break_stack);
                        continue_list = (T_CONTINUE *) pop(&continue_stack);
                        } break;
case 148:{
                        push(break_list, &break_stack);
                        push(continue_list, &continue_stack);
                        } break;
case 149:{
                        T_VARIABLE *vp;

                        if (last_dot_component) {
                          yyval.variable = last_dot_component;
                          last_dot_component =
                            do_dot_check(yyval.variable->var_name, yypvt[-0].string, yyval.variable, 0);
                          if (last_dot_component)
                            last_dot_component->var_parent = yyval.variable;
                          yyval.variable = last_dot_component;
                        } else {
                          yyval.variable = get_variable(yypvt[-0].string);
                          if (yyval.variable == 0) {
                            snprintf(error_buf, sizeof error_buf,
                              "undeclared variable: %s", yypvt[-0].string);
                            yyerror(error_buf, ERR_NONFATAL);
                          } else {
                            yyval.variable->var_flags |= VF_REFERENCED;
                            if (yyval.variable->var_type == VAR_USER)
                              yyval.variable->var_struct->st_flags |= SF_REFERENCED;
                          }
                          last_dot_component = yyval.variable;
                        }
                        } break;
case 150:{
                        yyval.variable = yypvt[-0].variable;
                        } break;
case 151:{
                        int already_new = 0;

                        if (last_dot_component) {
                          yyval.variable = last_dot_component;
                          last_dot_component =
                            do_dot_check(yyval.variable->var_name, yypvt[-3].string, yyval.variable, &already_new);
                          if (last_dot_component)
                            last_dot_component->var_parent = yyval.variable;
                          yyval.variable = last_dot_component;
                        } else {
                          yyval.variable = get_variable(yypvt[-3].string);
                          if (yyval.variable == 0) {
                            snprintf(error_buf, sizeof error_buf,
                              "undeclared variable: %s", yypvt[-3].string);
                            yyerror(error_buf, ERR_NONFATAL);
                          } else {
                            yyval.variable->var_flags |= VF_REFERENCED;
                            if (yyval.variable->var_type == VAR_USER)
                              yyval.variable->var_struct->st_flags |= SF_REFERENCED;
                          }
                          last_dot_component = yyval.variable;
                        }
                        if (yyval.variable) {
                          T_VARIABLE *vp;

                          if (already_new)
                            vp = yyval.variable;
                          else {
                            vp = NEW(T_VARIABLE);
                            *vp = *yyval.variable;
                            vp->var_next = yyval.variable->var_instances;
                            yyval.variable->var_instances = vp;
                          }
                          yyval.variable = do_array_check(yypvt[-3].string, yypvt[-1].expression, vp);
                          last_dot_component = vp;
                        }
                        } break;
case 152:{
                        push(last_dot_component, &component_stack);
                        last_dot_component = 0;
                        } break;
case 153:{
                      last_dot_component = (T_VARIABLE *) pop(&component_stack);
                        } break;
case 154:{
                        T_VARIABLE *vp;
                        T_VARIABLE *last;
                        T_VARIABLE *parent;

                        last_dot_component = 0;
                        yyval.variable = yypvt[-0].variable;

                        /* trim trailing instances from previous lvalues     *
                         * collected by already_new code in l_value nonterm. */

                        if (yypvt[-0].variable && (yypvt[-0].variable->var_flags & VF_MEMBER) &&
                                   yypvt[-0].variable->var_instances) {
                          parent = yypvt[-0].variable->var_instances->var_parent;
                          for(vp=yypvt[-0].variable->var_instances; vp; vp=vp->var_next) {
                            if (vp->var_parent != parent) {
                              last->var_next = 0;
                              break;
                            }
                            last = vp;
                          }
                        }
/*
{
printf("%s: 0x%x\n", $1->var_name, $1);
for(vp=$1->var_instances; vp; vp=vp->var_next)
  printf("\t0x%x: 0x%x\n", vp, vp->var_parent);
}
*/
                        } break;
case 155:{
                        yyval.assign_statement = yypvt[-0].assign_statement;
                        } break;
case 156:{
                        yyval.assign_statement = yypvt[-0].assign_statement;
                        } break;
case 157:{
                        yyval.assign_statement = NEW(T_ASSIGN);
                        yyval.assign_statement->a_variable = yypvt[-2].variable;
                        yyval.assign_statement->a_op = A_ASSIGN;
                        yyval.assign_statement->a_expression = yypvt[-0].expression;
                        if (yypvt[-0].expression->e_type == E_CALL &&
                            yypvt[-0].expression->e_call->c_name &&
                            (strcmp(yypvt[-0].expression->e_call->c_name, "new") == 0) &&
                            (yypvt[-2].variable && (yypvt[-2].variable->var_flags & VF_EMPTY) == 0))
                            yyerror("cannot new non-dynamic array",
                                     ERR_NONFATAL);
                        do_assign_check(yypvt[-2].variable, yypvt[-0].expression, "assignment", 0);
                        } break;
case 158:{
                        T_VARIABLE *vp = new_variable(yypvt[-2].variable);

                        if (yypvt[-2].variable->var_dimension == -1)
                          yyerror("too many array initializers", ERR_NONFATAL);
                        else {
                          /* init a clone of the assigned var with an agg */
                          do_aggregate_check(vp, yypvt[-0].variable);
                          vp->var_flags |= VF_AGGREGATE;
                        }

                        /* now, it's just a variable assignment */
                        yyval.assign_statement = NEW(T_ASSIGN);
                        yyval.assign_statement->a_variable = yypvt[-2].variable;
                        yyval.assign_statement->a_op = A_ASSIGN;
                        yyval.assign_statement->a_expression = NEW(T_EXPR);
                        yyval.assign_statement->a_expression->e_type = E_VALUE;
                        yyval.assign_statement->a_expression->e_variable = vp;
                        } break;
case 159:{
                        yyval.assign_statement = NEW(T_ASSIGN);
                        yyval.assign_statement->a_variable = yypvt[-2].variable;
                        yyval.assign_statement->a_op = A_ADD;
                        yyval.assign_statement->a_expression = yypvt[-0].expression;
                        do_compound_check(yypvt[-2].variable, yypvt[-0].expression, "+=");
                        } break;
case 160:{
                        yyval.assign_statement = NEW(T_ASSIGN);
                        yyval.assign_statement->a_variable = yypvt[-2].variable;
                        yyval.assign_statement->a_op = A_SUBTRACT;
                        yyval.assign_statement->a_expression = yypvt[-0].expression;
                        do_compound_check(yypvt[-2].variable, yypvt[-0].expression, "-=");
                        } break;
case 161:{
                        yyval.assign_statement = NEW(T_ASSIGN);
                        yyval.assign_statement->a_variable = yypvt[-2].variable;
                        yyval.assign_statement->a_op = A_MULTIPLY;
                        yyval.assign_statement->a_expression = yypvt[-0].expression;
                        do_compound_check(yypvt[-2].variable, yypvt[-0].expression, "*=");
                        } break;
case 162:{
                        yyval.assign_statement = NEW(T_ASSIGN);
                        yyval.assign_statement->a_variable = yypvt[-2].variable;
                        yyval.assign_statement->a_op = A_DIVIDE;
                        yyval.assign_statement->a_expression = yypvt[-0].expression;
                        do_compound_check(yypvt[-2].variable, yypvt[-0].expression, "/=");
                        } break;
case 163:{
                        yyval.assign_statement = NEW(T_ASSIGN);
                        yyval.assign_statement->a_variable = yypvt[-2].variable;
                        yyval.assign_statement->a_op = A_MODULUS;
                        yyval.assign_statement->a_expression = yypvt[-0].expression;
                        do_compound_check(yypvt[-2].variable, yypvt[-0].expression, "%=");
                        } break;
case 164:{
                        yyval.assign_statement = NEW(T_ASSIGN);
                        yyval.assign_statement->a_variable = yypvt[-2].variable;
                        yyval.assign_statement->a_op = A_BIT_AND;
                        yyval.assign_statement->a_expression = yypvt[-0].expression;
                        do_compound_check(yypvt[-2].variable, yypvt[-0].expression, "&=");
                        } break;
case 165:{
                        yyval.assign_statement = NEW(T_ASSIGN);
                        yyval.assign_statement->a_variable = yypvt[-2].variable;
                        yyval.assign_statement->a_op = A_BIT_OR;
                        yyval.assign_statement->a_expression = yypvt[-0].expression;
                        do_compound_check(yypvt[-2].variable, yypvt[-0].expression, "|=");
                        } break;
case 166:{
                        yyval.assign_statement = NEW(T_ASSIGN);
                        yyval.assign_statement->a_variable = yypvt[-2].variable;
                        yyval.assign_statement->a_op = A_BIT_XOR;
                        yyval.assign_statement->a_expression = yypvt[-0].expression;
                        do_compound_check(yypvt[-2].variable, yypvt[-0].expression, "^=");
                        } break;
case 167:{
                        yyval.assign_statement = NEW(T_ASSIGN);
                        yyval.assign_statement->a_variable = yypvt[-2].variable;
                        yyval.assign_statement->a_op = A_SHIFT_LEFT;
                        yyval.assign_statement->a_expression = yypvt[-0].expression;
                        do_compound_check(yypvt[-2].variable, yypvt[-0].expression, "<<=");
                        } break;
case 168:{
                        yyval.assign_statement = NEW(T_ASSIGN);
                        yyval.assign_statement->a_variable = yypvt[-2].variable;
                        yyval.assign_statement->a_op = A_SHIFT_RIGHT;
                        yyval.assign_statement->a_expression = yypvt[-0].expression;
                        do_compound_check(yypvt[-2].variable, yypvt[-0].expression, ">>=");
                        } break;
case 169:{
                        yyval.expression = reverse_arg_list(yypvt[-0].expression);
                        } break;
case 170:{
                        yyval.expression = 0;
                        } break;
case 171:{
                        yypvt[-0].expression->e_next = yypvt[-2].expression;
                        yyval.expression = yypvt[-0].expression;
                        } break;
case 172:{
                        yyval.expression = yypvt[-0].expression;
                        } break;
case 173:{
                        yyval.var_type = VAR_CONSTANT;
                        } break;
case 174:{
                        yyval.var_type = VAR_DOUBLE;
                        } break;
case 175:{
                        yyval.var_type = VAR_CONSTANT;
                        } break;
case 176:{
                        yyval.var_type = VAR_DOUBLE;
                        } break;
case 177:{
                        Lex_integerValue = Lex_integerValue * -1;
                        yyval.var_type = VAR_CONSTANT;
                        } break;
case 178:{
                        Lex_doubleValue = -Lex_doubleValue;
                        yyval.var_type = VAR_DOUBLE;
                        } break;
case 179:{
                        yyval.variable = yypvt[-0].variable;
                        } break;
case 180:{
                        yyval.variable = yypvt[-0].variable;
                        } break;
case 181:{
                        yyval.variable = NEW(T_VARIABLE);
                        yyval.variable->var_type = yypvt[-0].var_type;
                        if (yypvt[-0].var_type == VAR_CONSTANT)
                          yyval.variable->var_un.var_register = Lex_integerValue;
                        else
                          yyval.variable->var_un.var_rdigit = Lex_doubleValue;
                        } break;
case 182:{
                        yyval.variable = NEW(T_VARIABLE);
                        yyval.variable->var_type = VAR_STRING;
                        yyval.variable->var_un.var_string = yypvt[-0].string;
                        } break;
case 183:{
                        yyval.variable = NEW(T_VARIABLE);
                        yyval.variable->var_type = VAR_STRING;
                        yyval.variable->var_un.var_string = 0;
                        } break;
case 184:{
                        yyval.expression = yypvt[-0].expression;
                        } break;
case 185:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_EXPRESSION;
                        yyval.expression->e_op   = EO_PRECEDENCE;
                        yyval.expression->e_left = yypvt[-1].expression;
                        } break;
case 186:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_QCOP;
                        yyval.expression->e_lexpr = yypvt[-5].l_expression;
                        yyval.expression->e_left = yypvt[-3].expression;
                        yyval.expression->e_right = yypvt[-1].expression;
                        expr_clash_check(yypvt[-3].expression, yypvt[-1].expression, "?:");
                        } break;
case 187:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_ASSIGN;
                        yyval.expression->e_assign = yypvt[-1].assign_statement;
                        } break;
case 188:{
                        yyval.expression = yypvt[-1].expression;
                        } break;
case 189:{
                        yyval.expression = NEW(T_EXPR);
                        /* inline a call to the lazy evaluator */
                        if (is_lazy(yypvt[-0].variable))
                          do_lazy_value(yyval.expression, yypvt[-0].variable);
                        else {
                          yyval.expression->e_type = E_VALUE;
                          yyval.expression->e_variable = yypvt[-0].variable;
                        }
                        } break;
case 190:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_CALL;
                        yyval.expression->e_call = yypvt[-0].call_statement;
                        } break;
case 191:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_variable = yypvt[-1].variable;
                        yyval.expression->e_type = is_lazy(yypvt[-1].variable) ? E_LAZY_INCRA : E_INCRA;
                        } break;
case 192:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_variable = yypvt[-0].variable;
                        yyval.expression->e_type = is_lazy(yypvt[-0].variable) ? E_LAZY_INCRB : E_INCRB;
                        } break;
case 193:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_variable = yypvt[-1].variable;
                        yyval.expression->e_type = is_lazy(yypvt[-1].variable) ? E_LAZY_DECRA : E_DECRA;
                        } break;
case 194:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_variable = yypvt[-0].variable;
                        yyval.expression->e_type = is_lazy(yypvt[-0].variable) ? E_LAZY_DECRB : E_DECRB;
                        } break;
case 195:{
                        T_FCALL *cp;
                        T_EXPR *ep;
                        T_BMAP bp;

                        yyval.expression = NEW(T_EXPR);
                        if (yypvt[-0].variable && (yypvt[-0].variable->var_type == VAR_USER) || is_lazy(yypvt[-0].variable))
                          yyerror("cannot take structure addresses",
                                   ERR_NONFATAL);

                        ep = NEW(T_EXPR);
                        ep->e_type = E_VALUE;
                        ep->e_variable = yypvt[-0].variable;

                        cp = NEW(T_FCALL);
                        cp->c_name = "address_of";
                        cp->c_line_no = Lex_line_no;
                        cp->c_builtin = Se_functions[S_ADDR_OF];
                        cp->c_args = ep;
                        cp->c_arg_count = 1;

                        yyval.expression->e_type = E_CALL;
                        yyval.expression->e_call = cp;

                        /* spoof a builtin to build the return value */
                        bp.bm_name = cp->c_name;
                        bp.bm_stype = 0;
                        bp.bm_param_count = 1;
                        bp.bm_return_type = VAR_REGISTER;
                        bp.bm_check = 0;
                        do_builtin_check(&bp, 0, cp, ep, 1);
                        } break;
case 196:{
                        T_VARIABLE *vp;
                        T_FCALL *cp;
                        T_EXPR *ep;
                        T_BMAP bp;

                        vp = NEW(T_VARIABLE);
                        vp->var_type = yypvt[-1].var_type;
                        if (vp->var_type == VAR_USER)
                          vp->var_struct = GET_STRUCT(type_name);
                        vp->var_initial = yypvt[-0].expression;

                        ep = NEW(T_EXPR);
                        ep->e_type = E_VALUE;
                        ep->e_variable = vp;

                        cp = NEW(T_FCALL);
                        cp->c_name = "new";
                        cp->c_line_no = Lex_line_no;
                        cp->c_builtin = Se_functions[S_NEW];
                        cp->c_args = ep;
                        cp->c_arg_count = 2;

                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_CALL;
                        yyval.expression->e_call = cp;

                        /* spoof a builtin to build the return value */
                        bp.bm_name = cp->c_name;
                        bp.bm_stype = 0;
                        bp.bm_param_count = 1;
                        bp.bm_return_type = yypvt[-1].var_type;
                        if (yypvt[-1].var_type == VAR_USER)
                          bp.bm_user_type = type_name;
                        bp.bm_check = 0;
                        do_builtin_check(&bp, 0, cp, ep, 1);
                        vp = cp->c_block->b_return;
                        if (yypvt[-1].var_type == VAR_USER) {
                          /* new will allocate this, free this version */
                          free_user_type(vp->var_un.var_user);
                          vp->var_un.var_user = 0;
                        }
                        /* note vp's array-ness for semantics */
                        vp->var_dimension = -1;
                        } break;
case 197:{
                        T_VARIABLE *vp;
                        T_FCALL *cp;
                        T_EXPR *ep;
                        T_BMAP bp;
                        T_VARTYPE type;

                        vp = get_variable(yypvt[-1].string);
                        if (vp == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "undeclared variable: %s", yypvt[-1].string);
                          yyerror(error_buf, ERR_NONFATAL);
                          type = VAR_BOGUS;
                        } else {
                          type = vp->var_type;
                          if (vp->var_dimension == 0)
                            yyerror("cannot renew non-array type",
                                     ERR_NONFATAL);
                          if ((vp->var_flags & VF_EMPTY) == 0)
                            yyerror("cannot renew non-dynamic array",
                                     ERR_NONFATAL);
                        }

                        /* build renew(variable, size) function call */

                        /* here's the variable arg */
                        ep = NEW(T_EXPR);
                        ep->e_type = E_VALUE;
                        ep->e_variable = vp;

                        /* here's the size arg */
                        ep->e_next = yypvt[-0].expression;

                        /* here's the function call */
                        cp = NEW(T_FCALL);
                        cp->c_name = "renew";
                        cp->c_line_no = Lex_line_no;
                        cp->c_builtin = Se_functions[S_RENEW];
                        cp->c_args = ep;
                        cp->c_arg_count = 2;

                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_CALL;
                        yyval.expression->e_call = cp;

                        /* spoof a builtin to build the return value */
                        bp.bm_name = cp->c_name;
                        bp.bm_stype = 0;
                        bp.bm_param_count = 1;
                        bp.bm_return_type = type;
                        if (type == VAR_USER)
                          bp.bm_user_type = vp->var_struct->st_name;
                        bp.bm_check = 0;
                        do_builtin_check(&bp, 0, cp, ep, 1);
                        vp = cp->c_block->b_return;
                        if (type == VAR_USER) {
                          /* new will allocate this, free this version */
                          free_user_type(vp->var_un.var_user);
                          vp->var_un.var_user = 0;
                        }
                        /* note vp's array-ness for semantics */
                        vp->var_dimension = -1;
                        } break;
case 198:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_EXPRESSION;
                        yyval.expression->e_left = yypvt[-2].expression;
                        yyval.expression->e_op = EO_ADD;
                        yyval.expression->e_right = yypvt[-0].expression;
                        expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, "+");
                        } break;
case 199:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_EXPRESSION;
                        yyval.expression->e_left = yypvt[-2].expression;
                        yyval.expression->e_op = EO_SUBTRACT;
                        yyval.expression->e_right = yypvt[-0].expression;
                        expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, "-");
                        } break;
case 200:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_EXPRESSION;
                        yyval.expression->e_left = yypvt[-2].expression;
                        yyval.expression->e_op = EO_MULTIPLY;
                        yyval.expression->e_right = yypvt[-0].expression;
                        expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, "*");
                        } break;
case 201:{
                        if (yypvt[-0].expression->e_type == E_VALUE) {
                          T_VARIABLE *vp = yypvt[-0].expression->e_variable;
                          int byzero = 0;

                          if (vp && ((vp->var_type & VAR_NUMERIC) &&
                             (vp->var_name == 0))) {
                            switch(vp->var_type) {
                            case VAR_LONG:
                              byzero = (vp->var_un.var_udigit == 0);
                              break;
                            case VAR_DOUBLE:
                              byzero = (vp->var_un.var_rdigit == 0);
                              break;
                            }
                          }
                          if (byzero)
                            yyerror("division by zero", ERR_NONFATAL);
                        }
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_EXPRESSION;
                        yyval.expression->e_left = yypvt[-2].expression;
                        yyval.expression->e_op = EO_DIVIDE;
                        yyval.expression->e_right = yypvt[-0].expression;
                        expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, "/");
                        } break;
case 202:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_EXPRESSION;
                        yyval.expression->e_left = yypvt[-2].expression;
                        yyval.expression->e_op = EO_MODULUS;
                        yyval.expression->e_right = yypvt[-0].expression;
                        expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, "%");
                        } break;
case 203:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_EXPRESSION;
                        yyval.expression->e_left = yypvt[-2].expression;
                        yyval.expression->e_op = EO_BIT_AND;
                        yyval.expression->e_right = yypvt[-0].expression;
                        expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, "&");
                        } break;
case 204:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_EXPRESSION;
                        yyval.expression->e_left = yypvt[-2].expression;
                        yyval.expression->e_op = EO_BIT_OR;
                        yyval.expression->e_right = yypvt[-0].expression;
                        expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, "|");
                        } break;
case 205:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_EXPRESSION;
                        yyval.expression->e_left = yypvt[-2].expression;
                        yyval.expression->e_op = EO_BIT_XOR;
                        yyval.expression->e_right = yypvt[-0].expression;
                        expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, "^");
                        } break;
case 206:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_EXPRESSION;
                        yyval.expression->e_left = yypvt[-2].expression;
                        yyval.expression->e_op = EO_SHIFT_LEFT;
                        yyval.expression->e_right = yypvt[-0].expression;
                        expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, "<<");
                        } break;
case 207:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_EXPRESSION;
                        yyval.expression->e_left = yypvt[-2].expression;
                        yyval.expression->e_op = EO_SHIFT_RIGHT;
                        yyval.expression->e_right = yypvt[-0].expression;
                        expr_clash_check(yypvt[-2].expression, yypvt[-0].expression, ">>");
                        } break;
case 208:{
                        T_FCALL *cp;
                        T_BMAP bp;
                        T_VARTYPE etype = type_value(yypvt[-1].expression);

                        if (Se_type_sizes[yypvt[-3].var_type] < 0)
                          yyerror("illegal type cast", ERR_NONFATAL);
                        else {
                          if (Se_type_sizes[yypvt[-3].var_type] != Se_type_sizes[etype]) {
                            if (((yypvt[-3].var_type & VAR_NUMERIC) &&
                                (type_value(yypvt[-1].expression) & VAR_NUMERIC)) == 0) {
                              yyerror("invalid cast expression", ERR_NONFATAL);
                            }
                          }
                        }

                        cp = NEW(T_FCALL);
                        cp->c_name = "type_cast";
                        cp->c_line_no = Lex_line_no;
                        cp->c_builtin = Se_functions[S_TYPE_CAST];
                        cp->c_args = yypvt[-1].expression;
                        cp->c_arg_count = 1;

                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_CALL;
                        yyval.expression->e_call = cp;

                        /* spoof a builtin to build the return value */
                        bp.bm_name = cp->c_name;
                        bp.bm_stype = 0;
                        bp.bm_param_count = 1;
                        bp.bm_return_type = yypvt[-3].var_type;
                        bp.bm_check = 0;
                        do_builtin_check(&bp, 0, cp, yyval.expression, 1);
                        } break;
case 209:{
                        T_FCALL *cp;
                        T_BMAP bp;

                        if (type_value(yypvt[-1].expression) != VAR_REGISTER)
                          yyerror("indirection only on ulong types",
                                  ERR_NONFATAL);

                        cp = NEW(T_FCALL);
                        cp->c_name = "indirection";
                        cp->c_line_no = Lex_line_no;
                        cp->c_builtin = Se_functions[S_INDIRECT];
                        cp->c_args = yypvt[-1].expression;
                        cp->c_arg_count = 1;

                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_CALL;
                        yyval.expression->e_call = cp;

                        /* spoof a builtin to build the return value */
                        bp.bm_name = cp->c_name;
                        bp.bm_stype = 0;
                        bp.bm_param_count = 1;
                        bp.bm_return_type = yypvt[-4].var_type;
                        if (yypvt[-4].var_type == VAR_USER)
                          bp.bm_user_type = type_name;
                        bp.bm_check = 0;
                        do_builtin_check(&bp, 0, cp, yypvt[-1].expression, 1);
                        } break;
case 210:{
                        yyval.expression = NEW(T_EXPR);
                        yyval.expression->e_type = E_EXPRESSION;
                        yyval.expression->e_left = yypvt[-0].expression;
                        yyval.expression->e_op = EO_BIT_NOT;
                        expr_clash_check(yypvt[-0].expression, 0, "~");
                        } break;
	}
	goto yystack;		/* reset registers in driver code */
}

