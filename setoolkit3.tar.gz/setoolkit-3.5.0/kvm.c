/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <nlist.h>
#include <kvm.h>
#include "avl.h"
#include "se.h"

static kvm_t *kd = 0;  /* open kernel file descriptor */
static int           nindex;
static struct nlist *name_list;
static T_VARIABLE  **vp_list;
static char          error_buf[BUFSIZ];
static T_VARIABLE    zero_variable;
static T_EXPR        zero_expr;
static int           kvm_read_failures = 0;

static int accumulate_kvars(anode *, int, void *);

#ifndef MIN
#define MIN(a, b)  ((a) < (b) ? (a) : (b))
#endif

void
se_init_kvm(void)
{
  static int told_em = 0;
  int i;
  int j;
  int n;
  int error = 0;
  int size;
  int offset;
  int name_match;
  T_VARIABLE *vvp;

  if (Se_kvm_var_count == 0)
    return;

  /* already done */
  if (kd)
    return;

  /* open kvm */
  setegid(SYS_GID);
  kd = kvm_open(Se_kernel, Se_core_file, Se_paging_file, Se_kvm_open_flags, 0);
  if (kd == 0) {
    if (told_em == 0) {
      se_warning("Cannot init kvm: %s", strerror(errno));
      told_em = 1;
    }
    setegid(getgid());
    return;
  }

  /* need one more for the null entry */
  n = Se_kvm_var_count + 1;
  name_list = (struct nlist *) se_alloc(n * sizeof(struct nlist));
  vp_list = (T_VARIABLE **) se_alloc(n * sizeof(T_VARIABLE *));
  avldepth(Se_symbol_table, accumulate_kvars, 0);
  if (nindex == 0)
    se_fatal("cannot find any kvm variables");

  if (kvm_nlist(kd, name_list) == -1)
    se_fatal("unable to nlist kvm");

  /* assign the addresses */
  for(i=0; i<nindex; i++) {
    /* duplicate name */
    if ((name_list[i].n_value == 0) || (name_list[i].n_type == 0))
      continue;

    for(name_match=j=0; j<nindex; j++) {
      if (((vp_list[j]->var_flags & VF_SPECIAL) == VF_KVM) &&
        (strcmp(vp_list[j]->var_name+KVM_PREFIX_LEN, name_list[i].n_name) == 0))
          name_match = 1;
      else if ((vp_list[j]->var_special == SS_KVM) &&
               (strcmp(vp_list[j]->var_name, name_list[i].n_name) == 0))
          name_match = 1;

      if (name_match) {
        vp_list[i]->var_address = (caddr_t) name_list[i].n_value;

        /* give the instances the parents address for recomputation later */
        if (vp_list[i]->var_instances)
          for(vvp=vp_list[i]->var_instances; vvp; vvp=vvp->var_next) {
            vvp->var_address = (caddr_t) name_list[i].n_value;
            se_address_inherit(vvp, vvp->var_address);
          }
      }
    }
  }
  se_free(name_list);
  se_free(vp_list);
  setegid(getgid());
}

unsigned long
se_kvm_address(char *name)
{
  struct nlist nl[2];

  /* obviously, called by an initialization in the parser. */
  if (kd == 0) {
    se_init_kvm();
    if (kd == 0)
      return 0;
  }
  nl[0].n_name = name;
  nl[1].n_name = 0;
  if (kvm_nlist(kd, nl) == -1)
    return 0;
  return nl[0].n_value;
}

void
se_address_inherit(T_VARIABLE *vp, caddr_t address)
{
  int i;
  caddr_t addr;
  int z = sizeof addr;
  T_VARIABLE *vvp;
  T_VARIABLE var;
  T_STRUCT **spp;

  if (vp->var_type != VAR_USER)
    return;
  if (vp->var_dimension && (vp->var_subscript == 0)) {
    spp = (T_STRUCT **) vp->var_un.var_array;
    var = zero_variable;
    var.var_type = VAR_USER;
    for(i=0; i<vp->var_dimension; i++) {
      var.var_un.var_user = spp[i];
      se_address_inherit(&var, address);
    }
  } else {
    for(vvp=vp->var_un.var_user->st_members; vvp; vvp=vvp->var_next) {
      vvp->var_address = address + vvp->var_offset;
      switch(vvp->var_type) {
      case VAR_USER:
        se_address_inherit(vvp, address);
        break;
      case VAR_STRING:
        if (vvp->var_dimension == 0)
          /* vvp->var_address is the address of the address.  Fix this. */
          if (kvm_read(kd, (u_long) vvp->var_address, (char *) &addr, z) == z)
            vvp->var_address = addr;
        break;
      }
    }
  }
}

static void
process(T_VARIABLE *vp)
{
  if ((vp->var_flags & VF_SPECIAL) == VF_KVM) {
    /* increment past the kvm_ prefix */
    name_list[nindex].n_name = vp->var_name + KVM_PREFIX_LEN;
    vp_list[nindex++] = vp;
  } else if (vp->var_special == SS_KVM) {
    name_list[nindex].n_name = vp->var_name;
    vp_list[nindex++] = vp;
  }
}

static int
accumulate_kvars(anode *anp, int depth, void *param)
{
  T_SYMBOL *sp = (T_SYMBOL *) anp->an_data;
  T_VARIABLE *vp;

  if (sp == 0)
    return 0;

  switch(sp->sym_type) {
  case SYM_BLOCK:
    for(vp=sp->sym_un.sym_block->b_variables; vp; vp=vp->var_next)
      process(vp);
    return 0;
  case SYM_VARIABLE:
    process(sp->sym_un.sym_variable);
    return 0;
  case SYM_STRUCT:
    if (sp->sym_un.sym_struct->st_class == 0)
      return 0;
    for(vp=sp->sym_un.sym_struct->st_class->b_variables; vp; vp=vp->var_next)
      process(vp);
    return 0;
  default:
    return 0;
  }
}

static void
fixup_struct(uchar_t *buf, T_VARIABLE *vp)
{
  int i;
  int size;
  T_VARIABLE *vvp;
  T_VARIABLE var;

  if (vp->var_dimension) {
    if (vp->var_subscript) {
      i = se_compute_subscript(vp, 1);
      var = *vp;
      var.var_dimension = 0;
      var.var_subscript = 0;
      var.var_un.var_user = ((T_STRUCT **) vp->var_un.var_array)[i];
      fixup_struct(buf, &var);
    } else {
      var = *vp;
      var.var_dimension = 0;
      var.var_subscript = 0;
      for(i=0; i<vp->var_dimension; i++) {
        var.var_un.var_user = ((T_STRUCT **) vp->var_un.var_array)[i];
        fixup_struct(buf, &var);
      }
    }
    return;
  }
  /* at this point I should be dealing with only plain structures */
  for(vvp=vp->var_un.var_user->st_members; vvp; vvp=vvp->var_next) {
    switch(vvp->var_type) {
    case VAR_STRING:
      /* arrays of structs with instances have no address, get it first */
      if (vvp->var_address == 0) {
        var = *vvp;
        var.var_dimension = 0;
        var.var_subscript = 0;
        var.var_type = VAR_REGISTER;
        se_refresh_kvm_variable(&var);
        vvp->var_address = (caddr_t) var.var_un.var_register;
      }
      se_refresh_kvm_variable(vvp);
      size = sizeof(char *);
      if (vvp->var_dimension) {
        size *= vvp->var_dimension;
        memcpy(buf + vvp->var_offset, vvp->var_un.var_array, size);
      } else
        memcpy(buf + vvp->var_offset, &vvp->var_un.var_string, size);
      break;
    case VAR_USER:
      fixup_struct(buf, vvp);
      break;
    default:
      break;
    }
  }
}

void
se_refresh_kvm_variable(T_VARIABLE *vp)
{
  static char *buf = 0;
  static int bufsiz = 0;
  static int told_em = 0;
  uchar_t *area;
  char *p;
  char **pp;
  int i;
  int size;
  int subscript;
  int ouch = 0;
  void *array;

  /* obviously, called by an initialization in the parser. */
  if (kd == 0)
    se_init_kvm();
  if (kd == 0) {
    if (told_em == 0) {
      se_warning("Kvm not initialized: Variables will have invalid values");
      told_em = 1;
    }
    return;
  }

  if (vp->var_address == 0)
    if (vp->var_parent == 0)
      se_fatal("kvm variable: %s has no address", vp->var_name);
    else
      vp->var_address = vp->var_parent->var_address + vp->var_offset;

  switch(vp->var_type) {
  case VAR_CHAR:
  case VAR_UCHAR:
    size = sizeof(char);
    break;
  case VAR_SHORT:
  case VAR_USHORT:
    size = sizeof(short);
    break;
  case VAR_LONG:
  case VAR_ULONG:
    size = sizeof(int);
    break;
  case VAR_LONGLONG:
  case VAR_ULONGLONG:
    size = sizeof(T_LLONG);
    break;
  case VAR_DOUBLE:
    size = sizeof(double);
    break;
  case VAR_STRING:
    if (vp->var_dimension && (vp->var_subscript == 0)) {
      size = sizeof(char *);
      ouch = 1;
    } else
      size = BUFSIZ;
    break;
  case VAR_USER:
    size = vp->var_struct->st_size;
    if (vp->var_dimension)
      size *= vp->var_dimension;
    break;
  }

  if ((vp->var_type != VAR_USER) &&
      vp->var_dimension && (vp->var_subscript == 0))
    size *= vp->var_dimension;

  /* insure size of buf */
  if (size > bufsiz) {
    if (buf)
      se_free(buf);
    buf = (char *) se_alloc(size);
    bufsiz = size;
  }

  /* do the deed */
  setegid(SYS_GID);
  if (kvm_read(kd, (u_long) vp->var_address, buf, size) != size)
#if 0
    se_warning("kvm_read of %s(0x%x) failed", vp->var_name, vp->var_address);
#else
    kvm_read_failures++;
#endif

  /* oof! array of strings */
  if (ouch) {
    /* grab a buf to read the strings into */
    p = (char *) se_alloc(BUFSIZ);

    /* kvm read the individual strings */
    for(i=0; i<vp->var_dimension; i++) {
      if (kvm_read(kd, ((u_long *) buf)[i], p, BUFSIZ) != BUFSIZ)
#if 0
        se_warning("kvm_read of %s[%d](0x%x) failed", vp->var_name, i,
                   ((u_long *) buf)[i]);
#else
        kvm_read_failures++;
#endif
      ((char **) buf)[i] = se_string_save(p);
    }

    se_free(p);
  }
  setegid(getgid());

  if (vp->var_subscript) {
    if (vp->var_type != VAR_USER) {
      subscript = se_compute_subscript(vp, 1);
      array = vp->var_un.var_array;
    }
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      ((unsigned char *) array)[subscript] = *((unsigned char *) buf);
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      ((unsigned short *) array)[subscript] = *((unsigned short *) buf);
      break;
    case VAR_LONG:
    case VAR_ULONG:
      ((unsigned int *) array)[subscript] = *((unsigned int *) buf);
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      ((T_ULLONG *) array)[subscript] = *((T_ULLONG *) buf);
      break;
    case VAR_DOUBLE:
      ((double *) array)[subscript] = *((double *) buf);
      break;
    case VAR_STRING:
      pp = (char **) array;
      se_new_string(pp + subscript, buf);
      break;
    case VAR_USER:
      area = (uchar_t *) se_alloc(bufsiz);
      memcpy(area, buf, bufsiz);
      fixup_struct(area, vp);
      se_area_into_struct(area, vp);
      se_free(area);
      break;
    }
  } else if (vp->var_dimension) {
    switch(vp->var_type) {
    case VAR_USER:
      area = (uchar_t *) se_alloc(bufsiz);
      memcpy(area, buf, bufsiz);
      fixup_struct(area, vp);
      se_area_into_struct(area, vp);
      se_free(area);
      break;
    case VAR_STRING:
      for(i=0; i<vp->var_dimension; i++)
        if (((char **) vp->var_un.var_array)[i])
          se_free(((char **) vp->var_un.var_array)[i]);
      /* individual strings were read and saved above */
      memcpy(vp->var_un.var_array, buf, size);
      break;
    case VAR_CHAR:
    case VAR_UCHAR:
      /* with interchangability of char[] and string, may be any size */
      if (vp->var_un.var_array)
        se_free(vp->var_un.var_array);
      vp->var_un.var_array = se_alloc(size);
      memcpy(vp->var_un.var_array, buf, size);
      break;
    default:
      memcpy(vp->var_un.var_array, buf, size);
      break;
    }
  } else {
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      vp->var_un.var_udigit = *((unsigned char *) buf);
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      vp->var_un.var_udigit = *((unsigned short *) buf);
      break;
    case VAR_LONG:
    case VAR_ULONG:
      vp->var_un.var_udigit = *((unsigned int *) buf);
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      vp->var_un.var_uldigit = *((T_ULLONG *) buf);
      break;
    case VAR_DOUBLE:
      vp->var_un.var_rdigit = *((double *) buf);
      break;
    case VAR_STRING:
      se_new_string(&vp->var_un.var_string, buf);
      break;
    case VAR_USER:
      area = (uchar_t *) se_alloc(bufsiz);
      memcpy(area, buf, bufsiz);
      fixup_struct(area, vp);
      se_area_into_struct(area, vp);
      se_free(area);
      break;
    }
  }
}

static void
update_kvm_member(T_VARIABLE *vp)
{
  char buf[BUFSIZ];
  char *p;
  char **pp;
  int n;
  int ouch = 0;
  int size;
  int subscript;
  void *array;
  double d;
  unsigned char c;
  unsigned short s;
  unsigned int l;
  T_ULLONG ll;

  if (vp->var_address == 0)
    if (vp->var_parent == 0)
      se_fatal("kvm variable: %s has no address", vp->var_name);
    else
      vp->var_address = vp->var_parent->var_address + vp->var_offset;

  if (vp->var_type == VAR_USER) {
    se_update_kvm_variable(vp);
    return;
  }

  /* nothing but simple types past this point */
  if (vp->var_subscript) {
    subscript = se_compute_subscript(vp, 1);
    array = vp->var_un.var_array;
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      c = ((unsigned char *) array)[subscript];
      p = (char *) &c;
      size = sizeof(char);
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      s = ((unsigned short *) array)[subscript];
      p = (char *) &s;
      size = sizeof(short);
      break;
    case VAR_LONG:
    case VAR_ULONG:
      l = ((unsigned int *) array)[subscript];
      p = (char *) &l;
      size = sizeof(int);
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      ll = ((T_ULLONG *) array)[subscript];
      p = (char *) &ll;
      size = sizeof(T_LLONG);
      break;
    case VAR_DOUBLE:
      d = ((double *) array)[subscript];
      p = (char *) &d;
      size = sizeof(double);
      break;
    case VAR_STRING:
      if (((char **) array)[subscript]) {
        strcpy(buf, ((char **) array)[subscript]);
        size = strlen(buf);
      } else {
        buf[0] = '\0';
        size = 1;
      }
      p = buf;
      break;
    }
  } else {
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      c = (unsigned char) vp->var_un.var_udigit;
      p = (char *) &c;
      size = sizeof(char);
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      s = (unsigned short) vp->var_un.var_udigit;
      p = (char *) &s;
      size = sizeof(short);
      break;
    case VAR_LONG:
    case VAR_ULONG:
      l = vp->var_un.var_udigit;
      p = (char *) &l;
      size = sizeof(int);
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      ll = vp->var_un.var_uldigit;
      p = (char *) &ll;
      size = sizeof(T_LLONG);
      break;
    case VAR_DOUBLE:
      d = vp->var_un.var_rdigit;
      p = (char *) &d;
      size = sizeof(double);
      break;
    case VAR_STRING:
      if (vp->var_dimension)
        ouch = 1;
      else {
        strcpy(buf, vp->var_un.var_string);
        p = buf;
        size = strlen(buf) + 1;  /* account for null termination */
      }
      break;
    }
    /* var_subscript == 0 but var_dimension != 0:  array update */
    if (vp->var_dimension) {
      p = (char *) vp->var_un.var_array;
      size *= vp->var_dimension;
    }
  }

  setegid(SYS_GID);
  if (ouch) {
    /* this is so freakin' dangerous I can't even tell you */
    char **carray = (char **) vp->var_un.var_array;
    int i;
    int n;

    /* how big is it in the kernel */
    size = sizeof(char *) * vp->var_dimension;

    /* gimme space for it */
    p = (char *) se_alloc(size);

    /* read the array of kvm addresses */
    if (kvm_read(kd, (u_long) vp->var_address, p, size) != size)
#if 0
      se_warning("kvm_read (pre-read) of %s(0x%x) failed",
                 vp->var_name, vp->var_address);
#else
      kvm_read_failures++;
#endif

    /* traverse the array and put the strings back where kvm sez they belong */
    for(i=0; i<vp->var_dimension; i++) {
      n = strlen(carray[i]);

      /* this could overwrite kernel memory and cause a panic ... */
      if (kvm_write(kd, ((u_long *) p)[i], carray[i], n) != n)
        se_fatal("kvm_write of %s[%d](0x%x) failed", vp->var_name, i,
                 ((u_long *) p)[i]);
    }

    /* give it back */
    se_free(p);
  } else {
    /* ... but then so could this */
    n = kvm_kwrite(kd, (u_long) vp->var_address, (char *) p, size);
    if (n != size)
      se_fatal("kvm_write of %s failed", vp->var_name);
  }
  setegid(getgid());
}

void
se_update_kvm_variable(T_VARIABLE *vp)
{
  static int told_em = 0;
  int i;
  T_VARIABLE *vvp;
  T_STRUCT **spp;

  /* obviously, called by an initialization in the parser. */
  if (kd == 0)
    se_init_kvm();
  if (kd == 0) {
    if (told_em == 0) {
      se_warning(
       "the kvm system is not initialized, variables will have invalid values");
      told_em = 1;
    }
    return;
  }
  if (vp->var_type != VAR_USER) {
    update_kvm_member(vp);
    return;
  }
  /* ook. array of structures */
  if (vp->var_dimension && (vp->var_subscript == 0)) {
    spp = (T_STRUCT **) vp->var_un.var_array;
    for(i=0; i<vp->var_dimension; i++)
      for(vvp=spp[i]->st_members; vvp; vvp=vvp->var_next)
        update_kvm_member(vvp);
  } else
    for(vvp=vp->var_un.var_user->st_members; vvp; vvp=vvp->var_next)
      update_kvm_member(vvp);
}

void
se_end_kvm(void)
{
  if (kd)
    kvm_close(kd);
}
