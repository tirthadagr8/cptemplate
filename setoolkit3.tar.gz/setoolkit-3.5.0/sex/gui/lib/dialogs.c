/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/*
 * dialogs.c - Dialog box utilities
 *
 * Written by: Rich Pettit, SMCC Consultant
 *             Richard.Pettit@West.Sun.COM
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <X11/Intrinsic.h>
#include <Xm/Xm.h>
#include <Xm/MessageB.h>
#include "gui.h"
#include "gui_defines.h"

extern void *se_function_call(char *, ...);

typedef struct {
  char     *callback;
  char     *callback_data;
} cbd_t;

static Widget
init_info_dialog(Widget parent, Arg *args, int arg_count,
                 Widget (*f)(Widget, String, ArgList, Cardinal),
                 XmString title, char *fmt, va_list ap)
{
  char msg[BUFSIZ];
  int i;
  int n;
  XmString xs;
  Widget w;
  Widget info_dialog;

  vsprintf(msg, fmt, ap);
  xs = XmStringCreateLtoR(msg, XmFONTLIST_DEFAULT_TAG);
  n = arg_count;
  XtSetArg(args[n], XmNdialogStyle, XmDIALOG_APPLICATION_MODAL);  n++;
  XtSetArg(args[n], XmNmessageString, xs);  n++;
  XtSetArg(args[n], XmNdialogTitle, title);  n++;
  info_dialog = (*f)(parent, "info_dialog", args, n);
  w = XmMessageBoxGetChild(info_dialog, XmDIALOG_OK_BUTTON);
  n = 0;
  XtSetArg(args[n], XmNhighlightThickness, GuiHIGHLIGHT_THICKNESS); n++;
  XtSetValues(w, args, n);
  XmStringFree(xs);
  return info_dialog;
}

static void
destroy_callback(Widget w, void *client_data, void *call_data)
{
  XtDestroyWidget(w);
}

static void
fatal_callback(Widget w, void *client_data, void *call_data)
{
  exit(0);
}

static void
warning_dialog(Widget parent, Arg *args, int arg_count, char *fmt, va_list ap)
{
  static XmString title = 0;
  Widget info_dialog;
  Widget w;
  Arg arg;

  if (title == 0)
    title = XmStringCreateLtoR("Warning", XmFONTLIST_DEFAULT_TAG);
  info_dialog = init_info_dialog(parent, args, arg_count,
                                 XmCreateWarningDialog, title, fmt, ap);
  XtAddCallback(info_dialog, XmNokCallback, destroy_callback, 0);
  w = XmMessageBoxGetChild(info_dialog, XmDIALOG_CANCEL_BUTTON);
  XtUnmanageChild(w);
  w = XmMessageBoxGetChild(info_dialog, XmDIALOG_HELP_BUTTON);
  XtUnmanageChild(w);
  XtManageChild(info_dialog);
}

void
gui_warning_dialog(char *fmt, ...)
{
  Arg args[16];
  int n;
  va_list ap;

  va_start(ap, fmt);
  n = 0;
  XtSetArg(args[n], XmNbuttonFontList, Gui_AppData.mediumFont);  n++;
  XtSetArg(args[n], XmNlabelFontList, Gui_AppData.mediumFont);  n++;
  warning_dialog(Gui_toplevel, args, n, fmt, ap);
}

static void
fatal_dialog(Widget parent, Arg *args, int arg_count, char *fmt, va_list ap)
{
  XmString title;
  Arg warg;
  XmString ok;
  Widget info_dialog;
  Widget cancel_button;
  Widget help_button;

  title = XmStringCreateLtoR("Fatal Error", XmFONTLIST_DEFAULT_TAG);
  info_dialog = init_info_dialog(parent, args, arg_count,
                                 XmCreateErrorDialog, title, fmt, ap);

  ok = XmStringCreateLtoR("EXIT", XmFONTLIST_DEFAULT_TAG);
  XtSetArg(warg, XmNokLabelString, ok);
  XtSetValues(info_dialog, &warg, 1);

  XtAddCallback(info_dialog, XmNokCallback, fatal_callback, 0);

  cancel_button = XmMessageBoxGetChild(info_dialog, XmDIALOG_CANCEL_BUTTON);
  help_button = XmMessageBoxGetChild(info_dialog, XmDIALOG_HELP_BUTTON);
  XtUnmanageChild(cancel_button);
  XtUnmanageChild(help_button);

  XtManageChild(info_dialog);
}

void
gui_fatal_dialog(char *fmt, ...)
{
  Arg args[16];
  int n;
  va_list ap;

  va_start(ap, fmt);
  n = 0;
  XtSetArg(args[n], XmNbuttonFontList, Gui_AppData.mediumFont);  n++;
  XtSetArg(args[n], XmNlabelFontList, Gui_AppData.mediumFont);  n++;
  fatal_dialog(Gui_toplevel, args, n, fmt, ap);
}

static void
info_dialog(Widget parent, Arg *args, int arg_count, char *fmt, va_list ap)
{
  static XmString title = 0;
  Widget info_dialog;
  Widget cancel_button;
  Widget help_button;

  if (title == 0)
    title = XmStringCreateLtoR("Note", XmFONTLIST_DEFAULT_TAG);
  info_dialog = init_info_dialog(parent, args, arg_count,
                                 XmCreateInformationDialog, title, fmt, ap);

  XtAddCallback(info_dialog, XmNokCallback, destroy_callback, 0);

  cancel_button = XmMessageBoxGetChild(info_dialog, XmDIALOG_CANCEL_BUTTON);
  help_button = XmMessageBoxGetChild(info_dialog, XmDIALOG_HELP_BUTTON);
  XtUnmanageChild(cancel_button);
  XtUnmanageChild(help_button);

  XtManageChild(info_dialog);
}

void
gui_info_dialog(char *fmt, ...)
{
  Arg args[16];
  int n;
  va_list ap;

  va_start(ap, fmt);
  n = 0;
  XtSetArg(args[n], XmNbuttonFontList, Gui_AppData.mediumFont);  n++;
  XtSetArg(args[n], XmNlabelFontList, Gui_AppData.mediumFont);  n++;
  info_dialog(Gui_toplevel, args, n, fmt, ap);
}

static void
yes_or_no_dialog(Widget parent, Arg *args, int arg_count,
                 XtCallbackProc yes_callback, XtCallbackProc no_callback,
                 XtPointer client_data, char *fmt, va_list ap)
{
  int n;
  static XmString title = 0;
  static XmString yes = 0;
  static XmString no = 0;
  Widget info_dialog;
  Widget help_button;

  if (title == 0) {
    title = XmStringCreateLtoR("Question", XmFONTLIST_DEFAULT_TAG);
    yes = XmStringCreateLtoR("Yes", XmFONTLIST_DEFAULT_TAG);
    no = XmStringCreateLtoR("No", XmFONTLIST_DEFAULT_TAG);
  }
  info_dialog = init_info_dialog(parent, args, arg_count,
                                 XmCreateQuestionDialog, title, fmt, ap);
  n = 0;
  XtSetArg(args[n], XmNokLabelString, yes);  n++;
  XtSetArg(args[n], XmNcancelLabelString, no);  n++;
  XtSetValues(info_dialog, args, n);

  XtAddCallback(info_dialog, XmNokCallback, yes_callback, client_data);
  XtAddCallback(info_dialog, XmNcancelCallback, no_callback, client_data);

  help_button = XmMessageBoxGetChild(info_dialog, XmDIALOG_HELP_BUTTON);
  XtUnmanageChild(help_button);

  XtManageChild(info_dialog);
}

static void
yes_callback(Widget w, XtPointer client_data, XtPointer call_data)
{
  cbd_t *cp = (cbd_t *) client_data;

  se_function_call(cp->callback, 0, cp->callback_data, ANS_YES);
  se_free(cp);
}

static void
no_callback(Widget w, XtPointer client_data, XtPointer call_data)
{
  cbd_t *cp = (cbd_t *) client_data;

  se_function_call(cp->callback, 0, cp->callback_data, ANS_NO);
  se_free(cp);
}

void
gui_yes_or_no_dialog(char *callback, char *callback_data, char *fmt, ...)
{
  cbd_t *cp;
  Arg args[16];
  int n;
  va_list ap;

  va_start(ap, fmt);
  cp = (cbd_t *) se_alloc(sizeof(cbd_t));
  if (cp == 0) {
    perror("gui_yes_or_no_dialog: se_alloc");
    exit(1);
  }
  cp->callback = callback;
  cp->callback_data = callback_data;
  n = 0;
  XtSetArg(args[n], XmNbuttonFontList, Gui_AppData.mediumFont);  n++;
  XtSetArg(args[n], XmNlabelFontList, Gui_AppData.mediumFont);  n++;
  yes_or_no_dialog(Gui_toplevel, args, n, yes_callback, no_callback,
                   (XtPointer) cp, fmt, ap);
}
