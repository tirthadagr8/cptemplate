/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef _GUI_H_
#define _GUI_H_

/* allocation macro */
#define NEW(T) ((T *) se_alloc(sizeof(T)))

/* names */
#define GuiNboldFont     "boldFont"
#define GuiNmediumFont   "mediumFont"
#define GuiNtextFont     "textFont"

/* resource defaults */
#define GuiBOLD_FONT     "9x15bold"
#define GuiMEDIUM_FONT   "9x15"
#define GuiTEXT_FONT     "8x13"

/* misc defines */
#define GuiSCROLLED_TEXT_NAME   "GuiScrolledText"
#define GuiHIGHLIGHT_THICKNESS  2

#ifndef _SOLARIS
# define hrtime_t long long
#endif

/* Brian's suggestion
 *
 * #define GuiBOLD_FONT     \
 *"-b&h-lucida sans typewriter-bold-r-normal-sans-14-140-72-72-m-90-iso8859-1"
 * #define GuiMEDIUM_FONT   \
 *"-b&h-lucida sans typewriter-medium-r-normal-sans-14-140-72-72-m-90-iso8859-1"
 * #define GuiTEXT_FONT     \
 *"-b&h-lucida sans typewriter-medium-r-normal-sans-12-120-72-72-m-70-iso8859-1"
 *
 */

/* for scale */
#define GuiINACTIVE        0
#define GuiDOWN_ARMED      1
#define GuiUP_ARMED        2
#define GuiPAUSE_INTERVAL  ((hrtime_t) 100000000)

/* resource list */
#define GuiMAX_FIELDS    8      /* max fields in m_data record */

#define GuiHORIZONTAL    0	/* horizontal orientation */
#define GuiVERTICAL      1	/* vertical orientation */
#define GuiNONSPEC       2	/* don't worry about it */

/* give widgets names */
#define GuiNAME(a, b)  (a ? a : b)

typedef struct {
  XmFontList boldFont;
  XmFontList mediumFont;
  XmFontList textFont;
} ApplicationData, *ApplicationDataPtr;

typedef struct _member member_t;
typedef struct _resource resource_t;
typedef struct _counter_data cd_t;
typedef struct _bar_data bd_t; 

struct _member {
  int        m_type;
  int        m_foreground;
  int        m_background;
  char      *m_label;
  char      *m_data;
  char      *m_callback;
  char      *m_callback_data;
  member_t  *m_head;
  member_t  *m_tail;
  member_t  *m_agg_head;
  member_t  *m_agg_tail;
  member_t  *m_next;
  Widget     m_primary;
  Widget     m_secondary;
  void      *m_wdata;
};

struct _resource {
  int        r_type;          /* R_BUTTON, etc. */
  int        r_foreground;    /* one of ST_WHITE, ST_BLUE, etc. */
  int        r_background;    /* ditto */
  char      *r_label;         /* label */
  char      *r_data;          /* additional data for the widget */
  char      *r_callback;      /* name of func to call if button is pressed */
  char      *r_callback_data; /* data to pass to callback */
  char      *r_container;     /* name of variable into which to store handle */
};

struct _counter_data {
  hrtime_t   c_timestamp;
  int        c_button_state;
  Widget     c_row_column;
  Widget     c_label;
  Widget     c_up_arrow;
  Widget     c_counter;
  Widget     c_down_arrow;
  int        c_minimum;
  int        c_maximum;
};

struct _bar_data {
  Widget     b_label;
  Widget     b_value;
  Widget     b_upper;
  Widget     b_lower;
  Widget     b_bar;
};

extern ApplicationData Gui_AppData;
extern Widget Gui_output_window;
extern Widget Gui_toplevel;
extern XtAppContext Gui_app;
extern unsigned long Gui_loop_interval;

extern void     *se_alloc(int);
extern void      se_free(void *);
extern char     *se_string_save(char *);
extern void      se_new_string(char **, char *);

extern Widget    gui_create_top_panel(member_t *, Widget, int);

extern void      gui_update_widget(member_t *);
extern Widget    gui_create_menu_bar(Widget, member_t *);
extern Widget    gui_create_counter(Widget, member_t *);
extern void      gui_cb_cb(Widget, XtPointer, XtPointer);

extern Pixel     gui_get_pixel(int);
extern void      gui_record_split(char *, char *[]);
extern Boolean   gui_read_bitmap(member_t *, Pixmap *,
                                 Dimension *, Dimension *);

/* frames, groups and objects */
extern member_t *gui_create_frame(int, char *[], resource_t []);
extern void      gui_add_group(member_t *, resource_t []);
extern member_t *gui_get_object(member_t *, int);
extern void      gui_update_object(member_t *, resource_t *);
extern void      gui_update_group(member_t *, resource_t[]);
extern void      gui_main_loop(char *, char *, int);
extern void      gui_set_loop_interval (char *, char *, int);

/* printf style functions */
extern void      gui_warning_dialog(char *, ...);
extern void      gui_fatal_dialog(char *, ...);
extern void      gui_info_dialog(char *, ...);
extern void      gui_yes_or_no_dialog(char *, char *, char *, ...);

/* text functions */
extern void      gui_append_text(member_t *, char *);
extern void      gui_set_text(member_t *, char *);
extern void      gui_get_text(member_t *, char *, int);
extern void      gui_load_text_file(member_t *, char *);
extern void      gui_save_text_file(member_t *, char *);

/* selection list */
extern void      gui_add_list_items(member_t *, char *[], int);

/* icons */
extern Pixmap    gui_load_bitmap(char *, int, int);
extern void      gui_set_icon(Pixmap, Pixmap);
extern void      gui_blink_icon(Pixmap, Pixmap, int);

/* subframes */
extern member_t *gui_create_subframe(char *, resource_t []);
extern void      gui_popup_subframe(member_t *);
extern void      gui_popdown_subframe(member_t *);
extern member_t *gui_get_frame(member_t *);

/* misc */
extern void      gui_grey_option(member_t *, int);
extern void      gui_add_color(char *, int);

#endif
