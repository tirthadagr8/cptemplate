/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>
#include <Xm/TextF.h>
#include "gui.h"
#include "gui_defines.h"
#include "../../../avl.h"
#include "../../../se.h"

#define ENTRY_BUMP         4      /* amount to bump user color table by */

typedef struct {
  int   cm_code;
  char *cm_name;
  Pixel cm_pixel;
} colormap_t;

static colormap_t builtin_colors[] = {
  { ST_WHITE,        "white"            },
  { ST_BLUE,         "blue"             },
  { ST_GREEN,        "green"            },
  { ST_AMBER,        "orange"           },
  { ST_RED,          "red"              },
  { ST_BLACK,        "black"            },
  { ST_YELLOW,       "yellow2"          },
  { ST_LIGHTBLUE,    "light blue"       },
  { ST_CYAN,         "cyan"             },
  { ST_MIDNIGHTBLUE, "midnight blue"    },
  { ST_OLIVEGREEN,   "dark olive green" },
  { ST_GOLDENROD,    "pale goldenrod"   },
  { ST_FIREBRICK,    "firebrick"        },
  { ST_LIGHTGREY,    "light grey"       },
  { ST_NAVY,         "navy"             },
  { ST_MAROON,       "maroon"           },
  { -1                                  }
};
static colormap_t *user_colors;
static int n_user_colors;
static int n_user_entries;

static void
pixel_color_init(colormap_t *table)
{
  colormap_t *cp;
  Display *dpy;
  Screen *scn;
  Colormap cmap;
  XColor rgb;
  XColor hw;

  /* not ready yet */
  if (Gui_toplevel == 0)
    return;

  dpy = XtDisplay(Gui_toplevel);
  scn = DefaultScreenOfDisplay(dpy);
  cmap = DefaultColormapOfScreen(scn);

  for(cp=table; cp->cm_name; cp++) {
    if (XAllocNamedColor(dpy, cmap, cp->cm_name, &rgb, &hw) == 0) {
      fprintf(stderr, "gui_get_pixel: Cannot find color: %s\n", cp->cm_name);
      cp->cm_pixel = BlackPixelOfScreen(scn);
      continue;
    }
    cp->cm_pixel = (Pixel) rgb.pixel;
  }
}

Pixel
gui_get_pixel(int color)
{
  int i;
  static int initialized = 0;

  if (initialized == 0) {
    pixel_color_init(builtin_colors);
    if (user_colors)
      pixel_color_init(user_colors);
    initialized = 1;
  }
  if (color >= 0) {
    if (color <= ST_MAROON)
      return builtin_colors[color].cm_pixel;
    for(i=0; i<n_user_colors; i++)
      if (user_colors[i].cm_code == color)
        return user_colors[i].cm_pixel;
  }
  fprintf(stderr, "gui_get_pixel: Invalid color code: %d\n", color);
  return builtin_colors[ST_BLACK].cm_pixel;
}

int
gui_get_color(Pixel pixel)
{
  int i;

  for(i=0; builtin_colors[i].cm_code != -1; i++)
    if (builtin_colors[i].cm_pixel == pixel)
      return builtin_colors[i].cm_code;
  return -1;
}

void
gui_add_color(char *name, int code)
{
  int n;
  colormap_t *tmp;

  if (n_user_entries == n_user_colors) {
    n_user_entries += ENTRY_BUMP;
    /* one extra for nullness at the end of the table */
    n = (n_user_entries + 1) * sizeof(colormap_t);
    if (user_colors) {
      tmp = (colormap_t *) se_alloc(n);
      if (tmp == 0) {
        perror("gui_add_color: realloc");
        exit(1);
      }
      memset(tmp, '\0', n);
      memcpy(tmp, user_colors, n_user_colors * sizeof(colormap_t));
      user_colors = tmp;
    } else
      user_colors = (colormap_t *) se_alloc(n);
  }
  user_colors[n_user_colors].cm_code = code;
  user_colors[n_user_colors].cm_name = name;
  pixel_color_init(&user_colors[n_user_colors]);
  n_user_colors++;
}

void
gui_record_split(char *src, char *fields[])
{
  static char buf[BUFSIZ];
  char *p;
  int i = 0;

  strcpy(buf, src);
  for(p=strtok(buf, ":"); p; p=strtok(0, ":"))
    fields[i++] = p;
  fields[i] = 0;
}

void
gui_cb_cb(Widget w, XtPointer client_data, XtPointer call_data)
{
  char *text;
  char buf[32];
  char *fields[GuiMAX_FIELDS];
  int n;
  int interval;
  double *dvalue;
  member_t *mp = (member_t *) client_data;
  cd_t *cdp;
  XmString cs;
  Arg args[8];
  XmFileSelectionBoxCallbackStruct *fsbp;
  XmSelectionBoxCallbackStruct *sbp;
  T_VARIABLE *vp;

  switch(mp->m_type) {
  case R_BUTTON:
  case R_BGROUP:
  case R_OPTION:
  case R_TBUTTON:
    se_function_call(mp->m_callback, mp, mp->m_callback_data, 0);
    break;
  case R_VSCALE:
  case R_HSCALE:
    n = 0;
    XtSetArg(args[n], XmNvalue, &interval); n++;
    XtGetValues(mp->m_primary, args, n);
    sprintf(buf, "%d", interval);
    se_function_call(mp->m_callback, mp, mp->m_callback_data, buf);
    break;
  case R_COUNTER:
    cdp = (cd_t *) mp->m_wdata;
    n = 0;
    XtSetArg(args[n], XmNlabelString, &cs); n++;
    XtGetValues(cdp->c_counter, args, n);
    XmStringGetLtoR(cs, XmFONTLIST_DEFAULT_TAG, &text);
    se_function_call(mp->m_callback, mp, mp->m_callback_data, text);
    XtFree(text);
    break;
  case R_FSBOX:
    gui_record_split(mp->m_callback, fields);
    fsbp = (XmFileSelectionBoxCallbackStruct *) call_data;
    XmStringGetLtoR(fsbp->value, XmFONTLIST_DEFAULT_TAG, &text);
    if (fsbp->reason == XmCR_OK)
      se_function_call(fields[0], mp, mp->m_callback_data, text);
    else if ((fsbp->reason == XmCR_CANCEL) && fields[1])
      se_function_call(fields[1], mp, mp->m_callback_data, text);
    XtFree(text);
    break;
  case R_SELBOX:
    gui_record_split(mp->m_callback, fields);
    sbp = (XmSelectionBoxCallbackStruct *) call_data;
    XmStringGetLtoR(sbp->value, XmFONTLIST_DEFAULT_TAG, &text);
    if (sbp->reason == XmCR_OK)
      se_function_call(fields[0], mp, mp->m_callback_data, text);
    else if ((sbp->reason == XmCR_CANCEL) && fields[1])
      se_function_call(fields[1], mp, mp->m_callback_data, text);
    XtFree(text);
    break;
  case R_TFIELD:
    text = XmTextFieldGetString(mp->m_primary);
    se_function_call(mp->m_callback, mp, mp->m_callback_data, text);
    XtFree(text);
    break;
  case R_STRIPCHART:
  case R_POINTCHART:
    dvalue = (double *) call_data;
    if (mp->m_callback == 0) {
      *dvalue = 0;
      break;
    }
    vp = se_function_call(mp->m_callback, mp, mp->m_callback_data, 0);
    if (vp == 0)
      break;
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
    case VAR_SHORT:
    case VAR_USHORT:
    case VAR_LONG:
    case VAR_ULONG:
      *dvalue = (double) vp->var_un.var_udigit;
      break;
    case VAR_STRING:
    case VAR_USER:
      *dvalue = 0;
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      *dvalue = (double) vp->var_un.var_uldigit;
      break;
    case VAR_DOUBLE:
      /* in the event they actually decided to do it correctly */
      *dvalue = vp->var_un.var_rdigit;
      break;
    }
    break;
  }
}
