/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/utsname.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <Xm/Xm.h>
#include <Xm/Text.h>
#include <Xm/TextF.h>
#include <Xm/PushB.h>
#include <Xm/RowColumn.h>
#include <Xm/Separator.h>
#include <Xm/ToggleB.h>
#include <Xm/Scale.h>
#include <Xm/Form.h>
#include <Xm/Label.h>
#include <Xm/FileSB.h>
#include <Xm/SelectioB.h>
#include <Xm/PanedW.h>
#include <X11/Xaw/StripChart.h>
#include "Clock.h"
#include "gui.h"
#include "gui_defines.h"
#include "BarChart.h"
#include "PointChart.h"
#include "../../../avl.h"
#include "../../../se.h"

#define BUTTONS_PER_ROW    10     /* default buttons in a button group row */

static Widget  build_button       (member_t *, Widget, int, Arg *, int, int);
static Widget  build_group        (member_t *, Widget, int, Arg *, int);
static Widget  build_scale        (member_t *, int, Widget, int, Arg *, int);
static Widget  build_radiobox     (member_t *, int, Widget, int, Arg *, int);
static Widget  build_bar          (member_t *, Widget, int, Arg *, int);
static Widget  build_label        (member_t *, Widget, int, Arg *, int);
static Widget  build_text         (member_t *, Widget, int, Arg *, int);
static Widget  build_tfield       (member_t *, Widget, int, Arg *, int);
static Widget  build_fsbox        (member_t *, Widget, int, Arg *, int);
static Widget  build_selbox       (member_t *, Widget, int, Arg *, int);
static Widget  build_strip_chart  (member_t *, int, Widget, int, Arg *, int);
static Widget  build_clock        (member_t *, Widget, int, Arg *, int);
static Widget  build_paned        (member_t *, Widget, int, Arg *, int);

static char *no_label = "NO LABEL";
#ifndef linux
static char tfield_translations[] = {
  "#override\
  Ctrl<Key>u: delete-to-start-of-line()\n\
  Ctrl<Key>w: delete-previous-word()\n\
  <Key>Return: activate()"
};
static char text_translations[] = {
  "#override\
  Ctrl<Key>u: delete-to-start-of-line()\n\
  Ctrl<Key>w: delete-previous-word()"
};
static XtTranslations tt;
static XtTranslations tft;
static int solaris_version;
#endif

Widget
gui_create_top_panel(member_t *frame, Widget top, int orientation)
{
  int n;
  int i;
  int j;
  char v[8];
  int separator_orientation;
  member_t *mp;
  Widget above_me = 0;
  Arg args[32];
  struct utsname ubuf;

#ifndef linux
  if (tt == 0) {
    tt  = XtParseTranslationTable(text_translations);
    tft = XtParseTranslationTable(tfield_translations);
    if (uname(&ubuf) == -1)
      return 0;
    for(i=j=0; ubuf.release[i]; i++)
      if (isdigit(ubuf.release[i]))
        v[j++] = ubuf.release[i];
    v[j] = '\0';
    solaris_version = atoi(v);
    if (solaris_version < 100)
      solaris_version *= 10;
  }
#endif
  if (orientation == GuiVERTICAL)
    separator_orientation = XmHORIZONTAL;
  else
    separator_orientation = XmVERTICAL;
  for(mp=frame; mp; mp=mp->m_next) {
    if ((mp->m_type != R_HFRAME) && (mp->m_type != R_VFRAME)) {
      n = 0;
      XtSetArg(args[n], XmNnavigationType, XmEXCLUSIVE_TAB_GROUP);  n++;
      switch(orientation) {
      case GuiVERTICAL:
        XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM);  n++;
        XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM);  n++;
        if (above_me == 0) {
          XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM);  n++;
        } else {
          XtSetArg(args[n], XmNtopAttachment, XmATTACH_WIDGET);  n++;
          XtSetArg(args[n], XmNtopWidget, above_me);  n++;
        }
        if (mp->m_next == 0) {
          XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM);  n++;
        }
        break;
      case GuiHORIZONTAL:
        XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM);  n++;
        XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM);  n++;
        if (above_me == 0) {
          XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM);  n++;
        } else {
          XtSetArg(args[n], XmNleftAttachment, XmATTACH_WIDGET);  n++;
          XtSetArg(args[n], XmNleftWidget, above_me);  n++;
        }
        if (mp->m_next == 0) {
          XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM);  n++;
        }
        break;
      case GuiNONSPEC:
        break;
      }
    }
    switch(mp->m_type) {
    case R_HFRAME:
    case R_VFRAME:
      break;
    case R_BUTTON:
      above_me = build_button(mp, top, orientation, args, n, 0);
      break;
    case R_TBUTTON:
      above_me = build_button(mp, top, orientation, args, n, 1);
      break;
    case R_GROUP:
    case R_BGROUP:
    case R_LGROUP:
      above_me = build_group(mp, top, orientation, args, n);
      break;
    case R_HSCALE:
      above_me = build_scale(mp, XmHORIZONTAL, top, orientation, args, n);
      break;
    case R_VSCALE:
      above_me = build_scale(mp, XmVERTICAL, top, orientation, args, n);
      break;
    case R_MENUBAR:
      mp->m_primary = gui_create_menu_bar(top, mp);
      XtSetValues(mp->m_primary, args, n);
      XtManageChild(mp->m_primary);
      above_me = mp->m_primary;
      break;
    case R_HRADIOBOX:
      above_me = build_radiobox(mp, XmHORIZONTAL, top, orientation, args, n);
      break;
    case R_VRADIOBOX:
      above_me = build_radiobox(mp, XmVERTICAL, top, orientation, args, n);
      break;
    case R_COUNTER:
      mp->m_primary = gui_create_counter(top, mp);
      XtSetValues(mp->m_primary, args, n);
      XtManageChild(mp->m_primary);
      above_me = mp->m_primary;
      break;
    case R_ROW:
      XtSetArg(args[n], XmNforeground, gui_get_pixel(mp->m_foreground));  n++;
      XtSetArg(args[n], XmNbackground, gui_get_pixel(mp->m_background));  n++;
      XtSetArg(args[n], XmNhighlightThickness, GuiHIGHLIGHT_THICKNESS);  n++;
      mp->m_primary = XmCreateForm(top, mp->m_label, args, n);
      gui_create_top_panel(mp->m_agg_head, mp->m_primary, 0);
      XtManageChild(mp->m_primary);
      above_me = mp->m_primary;
      break;
    case R_COLUMN:
      XtSetArg(args[n], XmNforeground, gui_get_pixel(mp->m_foreground));  n++;
      XtSetArg(args[n], XmNbackground, gui_get_pixel(mp->m_background));  n++;
      XtSetArg(args[n], XmNhighlightThickness, GuiHIGHLIGHT_THICKNESS);  n++;
      XtSetArg(args[n], XmNorientation, XmVERTICAL);  n++;
      mp->m_primary = XmCreateForm(top, mp->m_label, args, n);
      gui_create_top_panel(mp->m_agg_head, mp->m_primary, 1);
      XtManageChild(mp->m_primary);
      above_me = mp->m_primary;
      break;
    case R_VBAR:
    case R_HBAR:
    case R_VBAR_CHART:
    case R_HBAR_CHART:
      above_me = build_bar(mp, top, orientation, args, n);
      break;
    case R_LABEL:
      above_me = build_label(mp, top, orientation, args, n);
      break;
    case R_TEXT:
      above_me = build_text(mp, top, orientation, args, n);
      break;
    case R_TFIELD:
      above_me = build_tfield(mp, top, orientation, args, n);
      break;
    case R_FSBOX:
      above_me = build_fsbox(mp, top, orientation, args, n);
      break;
    case R_SELBOX:
      above_me = build_selbox(mp, top, orientation, args, n);
      break;
    case R_EDITOR:
      above_me = build_text(mp, top, orientation, args, n);
      n = 0;
      XtSetArg(args[n], XmNeditable, True);  n++;
      XtSetArg(args[n], XmNcursorPositionVisible, True);  n++;
      XtSetValues(above_me, args, n);
      break;
    case R_SEPARATOR:
      XtSetArg(args[n], XmNorientation, separator_orientation);  n++;
      mp->m_primary = XmCreateSeparator(top, mp->m_label, args, n);
      XtManageChild(mp->m_primary);
      above_me = mp->m_primary;
      break;
    case R_STRIPCHART:
      above_me = build_strip_chart(mp, 1, top, orientation, args, n);
      break;
    case R_POINTCHART:
      above_me = build_strip_chart(mp, 0, top, orientation, args, n);
      break;
    case R_CLOCK:
      above_me = build_clock(mp, top, orientation, args, n);
      break;
    case R_HPANED:
      above_me = build_paned(mp, top, XmHORIZONTAL, args, n);
      break;
    case R_VPANED:
      above_me = build_paned(mp, top, XmVERTICAL, args, n);
      break;
    default:
      fprintf(stderr, "gui_create_top_panel: Invalid type: %d\n", mp->m_type);
      exit(1);
    }
  }
  return top;
}

static Widget
build_button(member_t *mp, Widget top,
             int orientation, Arg *args, int n, int toggle)
{
  char *p = 0;
  XmString cs = 0;
  Pixmap pixmap;
  Dimension width;
  Dimension height;

  if (mp->m_label)
    p = mp->m_label;
  else {
    if (mp->m_data) {
      if (gui_read_bitmap(mp, &pixmap, &width, &height) == False)
        p = no_label;
    } else
      p = no_label;
  }
  if (p) {
    cs = XmStringCreateLtoR(p, XmFONTLIST_DEFAULT_TAG);
    XtSetArg(args[n], XmNforeground, gui_get_pixel(mp->m_foreground));  n++;
    XtSetArg(args[n], XmNbackground, gui_get_pixel(mp->m_background));  n++;
    XtSetArg(args[n], XmNlabelString, cs);  n++;
    XtSetArg(args[n], XmNfontList, Gui_AppData.mediumFont);  n++;
  } else {
    XtSetArg(args[n], XmNlabelType, XmPIXMAP);  n++;
    XtSetArg(args[n], XmNlabelPixmap, pixmap);  n++;
    XtSetArg(args[n], XmNwidth, width + 6);  n++;
    XtSetArg(args[n], XmNheight, height + 6);  n++;
  }
  XtSetArg(args[n], XmNhighlightThickness, GuiHIGHLIGHT_THICKNESS);  n++;
  p = (p ? p : mp->m_data);
  if (toggle) {
    mp->m_primary = XmCreateToggleButton(top, p, args, n);
    if (mp->m_callback) {
      XtAddCallback(mp->m_primary, XmNvalueChangedCallback, gui_cb_cb, mp);
    }
  } else {
    mp->m_primary = XmCreatePushButton(top, p, args, n);
    if (mp->m_callback) {
      XtAddCallback(mp->m_primary, XmNactivateCallback, gui_cb_cb, mp);
    }
  }
  if (cs)
    XmStringFree(cs);
  XtManageChild(mp->m_primary);
  return mp->m_primary;
}

static Widget
build_group(member_t *mp, Widget top, int orientation, Arg *args, int n)
{
  char *fields[GuiMAX_FIELDS];
  int count;
  int buttons_per_row = BUTTONS_PER_ROW;
  Dimension width;
  Dimension height;
  Dimension tallest = 0;
  Position x;
  Position y;
  Widget form;
  member_t *xp;

  if (mp->m_data) {
    memset(fields, '\0', sizeof fields);
    gui_record_split(mp->m_data, fields);
    if (fields[0])
      buttons_per_row = atoi(fields[0]);
  }
  /* don't want this on plain groups */
  if (mp->m_type != R_GROUP) {
    /* build the form for the Button/Label and the RowColumn */
    form = XmCreateForm(top, "BGroupForm", args, n);

    n = 0;
    XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM);  n++;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM);  n++;
    XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM);  n++;
    if (mp->m_type == R_BGROUP)
      (void) build_button(mp, form, GuiVERTICAL, args, n, 0);
    else
      (void) build_label(mp, form, GuiVERTICAL, args, n);

    /* the button/label has been made with mediumFont, I want boldFont. */
    n = 0;
    XtSetArg(args[n], XmNfontList, Gui_AppData.boldFont);  n++;
    XtSetValues(mp->m_primary, args, n);

    /* the button is built, now make the button group */
    n = 0;
    XtSetArg(args[n], XmNtopAttachment, XmATTACH_WIDGET);  n++;
    XtSetArg(args[n], XmNtopWidget, mp->m_primary);  n++;
    XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM);  n++;
    XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM);  n++;
    XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM);  n++;
    XtSetArg(args[n], XmNorientation, XmHORIZONTAL);  n++;
    XtSetArg(args[n], XmNpacking, XmPACK_NONE);  n++;
    XtSetArg(args[n], XmNnumColumns, buttons_per_row);  n++;
    mp->m_secondary = XmCreateRowColumn(form, mp->m_label, args, n);
    gui_create_top_panel(mp->m_agg_head, mp->m_secondary, GuiNONSPEC);
  } else {
    /* for R_GROUP, n is passed from calling func. */
    XtSetArg(args[n], XmNorientation, XmHORIZONTAL);  n++;
    XtSetArg(args[n], XmNpacking, XmPACK_NONE);  n++;
    XtSetArg(args[n], XmNnumColumns, buttons_per_row);  n++;
    mp->m_primary = XmCreateRowColumn(top, mp->m_label, args, n);
    gui_create_top_panel(mp->m_agg_head, mp->m_primary, GuiNONSPEC);
  }
  x = 0;
  y = 2;
  count = 0;
  for(xp=mp->m_agg_head; xp; xp=xp->m_next) {
    /* set the x, y */
    n = 0;
    XtSetArg(args[n], XmNx, x);  n++;
    XtSetArg(args[n], XmNy, y);  n++;
    XtSetValues(xp->m_primary, args, n);

    /* get the width and height for increasing x and y */
    n = 0;
    XtSetArg(args[n], XmNwidth, &width);  n++;
    XtSetArg(args[n], XmNheight, &height);  n++;
    XtGetValues(xp->m_primary, args, n);
    if (height > tallest)
      tallest = height;

    /* compute new x, y */
    x += (width + 2);
    if (++count == buttons_per_row) {
      x = 0;
      y += (tallest + 2);
      count = 0;
    }
  }
  if (mp->m_type != R_GROUP) {
    XtManageChild(form);
    XtManageChild(mp->m_secondary);
    return mp->m_secondary;
  } else {
    XtManageChild(mp->m_primary);
    return mp->m_primary;
  }
}

static Widget
build_scale(member_t *mp, int scale_orient, Widget top, int orientation,
            Arg *args, int n)
{
  char *fields[GuiMAX_FIELDS];
  int minimum;
  int maximum;
  int initial;
  XmString cs;
  Widget w;

  minimum = 1;
  maximum = 100;
  initial = 1;
  if (mp->m_data) {
    memset(fields, '\0', sizeof fields);
    gui_record_split(mp->m_data, fields);
    if (fields[0])
      minimum = atoi(fields[0]);
    if (fields[1])
      maximum = atoi(fields[1]);
    if (fields[2])
      initial = atoi(fields[2]);
  }
  if (mp->m_label)
    cs = XmStringCreateLtoR(mp->m_label, XmFONTLIST_DEFAULT_TAG);
  else
    cs = XmStringCreateLtoR(no_label, XmFONTLIST_DEFAULT_TAG);
  XtSetArg(args[n], XmNforeground, gui_get_pixel(mp->m_foreground));  n++;
  XtSetArg(args[n], XmNbackground, gui_get_pixel(mp->m_background));  n++;
  XtSetArg(args[n], XmNminimum, minimum);  n++;
  XtSetArg(args[n], XmNmaximum, maximum);  n++;
  XtSetArg(args[n], XmNvalue, initial);  n++;
  XtSetArg(args[n], XmNorientation, scale_orient);  n++;
  XtSetArg(args[n], XmNshowValue, True);  n++;
  XtSetArg(args[n], XmNtitleString, cs);  n++;
  XtSetArg(args[n], XmNfontList, Gui_AppData.mediumFont);  n++;
  XtSetArg(args[n], XmNhighlightThickness, GuiHIGHLIGHT_THICKNESS);  n++;
  mp->m_primary = XmCreateScale(top, mp->m_label, args, n);
  if (mp->m_callback) {
    XtAddCallback(mp->m_primary, XmNvalueChangedCallback, gui_cb_cb, mp);
  }
  XmStringFree(cs);
  if (w = XtNameToWidget(mp->m_primary, "Title"))
    XtVaSetValues(w, XmNforeground, gui_get_pixel(mp->m_foreground),
                     XmNbackground, gui_get_pixel(mp->m_background), 0);
  XtManageChild(mp->m_primary);
  return mp->m_primary;
}

static Widget
build_radiobox(member_t *mp, int radio_orient, Widget top, int orientation,
               Arg *args, int n)
{
  char *p = 0;
  XmString cs;
  Dimension width;
  Dimension height;
  Pixmap pixmap;
  member_t *xp;

  XtSetArg(args[n], XmNforeground, gui_get_pixel(mp->m_foreground));  n++;
  XtSetArg(args[n], XmNbackground, gui_get_pixel(mp->m_background));  n++;
  XtSetArg(args[n], XmNorientation, radio_orient);  n++;
  XtSetArg(args[n], XmNisHomogeneous, True);  n++;
  XtSetArg(args[n], XmNradioBehavior, True);  n++;
  mp->m_primary = XmCreateRowColumn(top, mp->m_label, args, n);
  for(xp=mp->m_agg_head; xp; xp=xp->m_next) {
    p = 0;
    if (xp->m_label)
      p = xp->m_label;
    else
      if (xp->m_data) {
        if (gui_read_bitmap(xp, &pixmap, &width, &height) == False)
          p = no_label;
      } else
        p = no_label;
    n = 0;
    if (p) {
      cs = XmStringCreateLtoR(p, XmFONTLIST_DEFAULT_TAG);
      XtSetArg(args[n], XmNforeground, gui_get_pixel(xp->m_foreground));  n++;
      XtSetArg(args[n], XmNbackground, gui_get_pixel(xp->m_background));  n++;
      XtSetArg(args[n], XmNlabelString, cs);  n++;
      XtSetArg(args[n], XmNfontList, Gui_AppData.mediumFont);  n++;
    } else {
      XtSetArg(args[n], XmNlabelType, XmPIXMAP);  n++;
      XtSetArg(args[n], XmNlabelPixmap, pixmap);  n++;
      XtSetArg(args[n], XmNwidth, width + 6);  n++;
      XtSetArg(args[n], XmNheight, height + 6);  n++;
    }
    XtSetArg(args[n], XmNhighlightThickness, GuiHIGHLIGHT_THICKNESS);  n++;
    xp->m_primary =
      XmCreateToggleButton(mp->m_primary, GuiNAME(p, xp->m_data), args, n);
    if (p)
      XmStringFree(cs);
    if (xp->m_callback)
      XtAddCallback(xp->m_primary, XmNarmCallback, gui_cb_cb, xp);
    XtManageChild(xp->m_primary);
  }
  XtManageChild(mp->m_primary);
  return mp->m_primary;
}

static Widget
build_bar(member_t *mp, Widget top, int orientation, Arg *args, int n)
{
  char *fields[GuiMAX_FIELDS];
  int minimum;
  int maximum;
  int initial;
  Dimension width;
  Dimension height;
  XmString cs;
  bd_t *bdp;

  minimum = 1;
  minimum = 100;
  initial = 1;
  if ((mp->m_type == R_VBAR) || (mp->m_type == R_VBAR_CHART)) {
    height = 64;
    width = 8;
  } else {
    width = 64;
    height = 8;
  }
  if (mp->m_data) {
    memset(fields, '\0', sizeof fields);
    gui_record_split(mp->m_data, fields);
    if (fields[0])
      width = atoi(fields[0]);
    if (fields[1])
      height = atoi(fields[1]);
    if (fields[2])
      minimum = atoi(fields[2]);
    if (fields[3]) {
      maximum = atoi(fields[3]);
      if (minimum >= maximum) {
        minimum = 0;
        maximum = 100;
        XtWarningMsg("Warning", "RangeConstraint", "Constraint",
                     "Minimum Value >= Maximum Value", 0, 0);
      }
    }
    if (fields[4])
      initial = atoi(fields[4]);
  }
  XtSetArg(args[n], XtNwidth, width);  n++;
  XtSetArg(args[n], XtNheight, height);  n++;
  XtSetArg(args[n], XtNforeground, gui_get_pixel(mp->m_foreground));  n++;
  XtSetArg(args[n], XtNbackground, gui_get_pixel(mp->m_background));  n++;
  XtSetArg(args[n], XtNminValue, minimum);  n++;
  XtSetArg(args[n], XtNmaxValue, maximum);  n++;
  XtSetArg(args[n], XmNfontList, Gui_AppData.mediumFont);  n++;
  if ((mp->m_type == R_VBAR) || (mp->m_type == R_VBAR_CHART)) {
    XtSetArg(args[n], XtNorientation, XtorientVertical);  n++;
  } else {
    XtSetArg(args[n], XtNorientation, XtorientHorizontal);  n++;
  }
  XtSetArg(args[n], XtNvalue, initial);  n++;
  if ((mp->m_type == R_VBAR_CHART) || (mp->m_type == R_HBAR_CHART)) {
    if (mp->m_label) {
      XtSetArg(args[n], XtNlabel, mp->m_label);  n++;
    }
    mp->m_primary = XtCreateBarChart(top, mp->m_label, args, n);
    bdp = (bd_t *) se_alloc(sizeof(bd_t));
    bdp->b_label = XtBarChartGetChild(mp->m_primary, BC_LABEL_CHILD);
    bdp->b_value = XtBarChartGetChild(mp->m_primary, BC_VALUE_CHILD);
    bdp->b_upper = XtBarChartGetChild(mp->m_primary, BC_UPPER_CHILD);
    bdp->b_lower = XtBarChartGetChild(mp->m_primary, BC_LOWER_CHILD);
    bdp->b_bar   = XtBarChartGetChild(mp->m_primary, BC_BAR_CHILD);
    mp->m_wdata = bdp;
  } else
    mp->m_primary = XtCreateBar(top, mp->m_label, args, n);
  XtManageChild(mp->m_primary);
  return mp->m_primary;
}

static Widget
build_label(member_t *mp, Widget top, int orientation, Arg *args, int n)
{
  char *p = 0;
  XmString cs = 0;
  Dimension width;
  Dimension height;
  Pixmap pixmap;

  if (mp->m_label)
    p = mp->m_label;
  else
    if (mp->m_data) {
      if (gui_read_bitmap(mp, &pixmap, &width, &height) == False)
        p = no_label;
    } else
      p = no_label;
  if (p) {
    cs = XmStringCreateLtoR(p, XmFONTLIST_DEFAULT_TAG);
    XtSetArg(args[n], XmNforeground, gui_get_pixel(mp->m_foreground));  n++;
    XtSetArg(args[n], XmNbackground, gui_get_pixel(mp->m_background));  n++;
    XtSetArg(args[n], XmNlabelString, cs);  n++;
    XtSetArg(args[n], XmNfontList, Gui_AppData.mediumFont);  n++;
  } else {
    XtSetArg(args[n], XmNlabelType, XmPIXMAP);  n++;
    XtSetArg(args[n], XmNlabelPixmap, pixmap);  n++;
    XtSetArg(args[n], XmNwidth, width + 6);  n++;
    XtSetArg(args[n], XmNheight, height + 6);  n++;
  }
  XtSetArg(args[n], XmNhighlightThickness, GuiHIGHLIGHT_THICKNESS);  n++;
  mp->m_primary = XmCreateLabel(top, GuiNAME(p, mp->m_data), args, n);
  if (p)
    XmStringFree(cs);
  XtManageChild(mp->m_primary);
  return mp->m_primary;
}

static Widget
build_text(member_t *mp, Widget top, int orientation, Arg *args, int n)
{
  char *fields[GuiMAX_FIELDS];
  Dimension width = 84;
  Dimension height = 28;
  XmString cs;

  if (mp->m_data) {
    memset(fields, '\0', sizeof fields);
    gui_record_split(mp->m_data, fields);
    if (fields[0])
      width = atoi(fields[0]);
    if (fields[1])
      height = atoi(fields[1]);
  }
  /* compute width and height for the ScrolledText */
  cs = XmStringCreateLtoR("X", XmFONTLIST_DEFAULT_TAG);
  width *= XmStringWidth(Gui_AppData.textFont, cs);
  height *= XmStringHeight(Gui_AppData.textFont, cs);
  XmStringFree(cs);
  XtSetArg(args[n], XmNforeground, gui_get_pixel(mp->m_foreground));  n++;
  XtSetArg(args[n], XmNbackground, gui_get_pixel(mp->m_background));  n++;
  XtSetArg(args[n], XmNwidth, width);  n++;
  XtSetArg(args[n], XmNheight, height);  n++;
  XtSetArg(args[n], XmNfontList, Gui_AppData.textFont);  n++;
  XtSetArg(args[n], XmNeditMode, XmMULTI_LINE_EDIT);  n++;
  XtSetArg(args[n], XmNeditable, False);  n++;
  XtSetArg(args[n], XmNcursorPositionVisible, False);  n++;
  XtSetArg(args[n], XmNwordWrap, True);  n++;
  XtSetArg(args[n], XmNhighlightThickness, GuiHIGHLIGHT_THICKNESS);  n++;
#ifndef linux
  if (solaris_version < 560) {
    XtSetArg(args[n], XmNtranslations, tt);  n++;
  }
#endif
  XtSetArg(args[n], XmNresizeHeight, True);  n++;
  XtSetArg(args[n], XmNresizeWidth, True);  n++;
  mp->m_primary = XmCreateScrolledText(top, GuiSCROLLED_TEXT_NAME, args, n);
  XtManageChild(mp->m_primary);
  return mp->m_primary;
}

static Widget
build_tfield(member_t *mp, Widget top, int orientation, Arg *args, int n)
{
  char *fields[GuiMAX_FIELDS];
  Dimension width = 10;

  if (mp->m_data) {
    memset(fields, '\0', sizeof fields);
    gui_record_split(mp->m_data, fields);
    if (fields[0])
      width = atoi(fields[0]);
  }
  if (mp->m_label) {
    XtSetArg(args[n], XmNvalue, mp->m_label);  n++;
  }
  XtSetArg(args[n], XmNforeground, gui_get_pixel(mp->m_foreground));  n++;
  XtSetArg(args[n], XmNbackground, gui_get_pixel(mp->m_background));  n++;
  XtSetArg(args[n], XmNfontList, Gui_AppData.textFont);  n++;
  XtSetArg(args[n], XmNhighlightThickness, GuiHIGHLIGHT_THICKNESS);  n++;
  XtSetArg(args[n], XmNcolumns, width);  n++;
#ifndef linux
  XtSetArg(args[n], XmNtranslations, tft);  n++;
#endif
  mp->m_primary = XmCreateTextField(top, "TextField", args, n);
  if (mp->m_callback)
    XtAddCallback(mp->m_primary, XmNactivateCallback, gui_cb_cb, mp);
  XtManageChild(mp->m_primary);
  return mp->m_primary;
}

static Widget
build_fsbox(member_t *mp, Widget top, int orientation, Arg *args, int n)
{
  char *fields[GuiMAX_FIELDS];
  char *dir = ".";
  char *pattern = "*";
  unsigned char file_type = XmFILE_ANY_TYPE;
  Widget w;
  XmString c_dir;
  XmString c_pattern;

  if (mp->m_data) {
    memset(fields, '\0', sizeof fields);
    gui_record_split(mp->m_data, fields);
    if (fields[0])
      dir = fields[0];
    if (fields[1])
      pattern = fields[1];
    if (fields[2]) {
      switch(atoi(fields[2])) {
      case F_REGULAR:
        file_type = XmFILE_REGULAR;
        break;
      case F_DIRECTORY:
        file_type = XmFILE_DIRECTORY;
        break;
      case F_ANY:
        file_type = XmFILE_ANY_TYPE;
        break;
      default:
        break;
      }
    }
  }
  c_dir = XmStringCreateLtoR(dir, XmFONTLIST_DEFAULT_TAG);
  c_pattern = XmStringCreateLtoR(pattern, XmFONTLIST_DEFAULT_TAG);
  XtSetArg(args[n], XmNforeground, gui_get_pixel(mp->m_foreground));  n++;
  XtSetArg(args[n], XmNbackground, gui_get_pixel(mp->m_background));  n++;
  XtSetArg(args[n], XmNbuttonFontList, Gui_AppData.mediumFont);  n++;
  XtSetArg(args[n], XmNtextFontList, Gui_AppData.textFont);  n++;
  XtSetArg(args[n], XmNbuttonFontList, Gui_AppData.mediumFont);  n++;
  XtSetArg(args[n], XmNlabelFontList, Gui_AppData.mediumFont);  n++;
  XtSetArg(args[n], XmNdirectory, c_dir);  n++;
  XtSetArg(args[n], XmNpattern, c_pattern);  n++;
  XtSetArg(args[n], XmNfileTypeMask, file_type);  n++;
#ifndef linux
  if (solaris_version < 560) {
    XtSetArg(args[n], XmNtextTranslations, tt);  n++;
  }
#endif
  mp->m_primary = XmCreateFileSelectionBox(top, "FSBox", args, n);
  XtUnmanageChild(
    XmFileSelectionBoxGetChild(mp->m_primary, XmDIALOG_HELP_BUTTON));
  if (mp->m_callback) {
    XtAddCallback(mp->m_primary, XmNokCallback, gui_cb_cb, mp);
    if (strchr(mp->m_callback, ':'))
      XtAddCallback(mp->m_primary, XmNcancelCallback, gui_cb_cb, mp);
  }
  XmStringFree(c_dir);
  XmStringFree(c_pattern);

  /* turn off the highlight nonsense */
  n = 0;
  XtSetArg(args[n], XmNhighlightThickness, GuiHIGHLIGHT_THICKNESS);  n++;
  w = XmFileSelectionBoxGetChild(mp->m_primary, XmDIALOG_OK_BUTTON);
  XtSetValues(w, args, n);
  w = XmFileSelectionBoxGetChild(mp->m_primary, XmDIALOG_APPLY_BUTTON);
  XtSetValues(w, args, n);
  w = XmFileSelectionBoxGetChild(mp->m_primary, XmDIALOG_CANCEL_BUTTON);
  XtSetValues(w, args, n);
  w = XmFileSelectionBoxGetChild(mp->m_primary, XmDIALOG_FILTER_TEXT);
  XtSetValues(w, args, n);
  w = XmFileSelectionBoxGetChild(mp->m_primary, XmDIALOG_TEXT);
  XtSetValues(w, args, n);
  XtManageChild(mp->m_primary);
  return mp->m_primary;
}

static Widget
build_selbox(member_t *mp, Widget top, int orientation, Arg *args, int n)
{
  char **pp;
  int i;
  int count;
  Widget w;
  XmString cs = 0;
  XmStringTable cst;

  if (mp->m_label)
    cs = XmStringCreateLtoR(mp->m_label, XmFONTLIST_DEFAULT_TAG);
  cst = 0;
  if (mp->m_agg_head) {
    pp = (char **) mp->m_agg_head->m_data;
    count = (int) (long) mp->m_agg_head->m_wdata;
    cst = (XmStringTable) se_alloc(count * sizeof(XmString));
    for(i=0; i<count; i++)
      cst[i] = XmStringCreateLtoR(pp[i], XmFONTLIST_DEFAULT_TAG);
    XtSetArg(args[n], XmNlistItems, cst);  n++;
    XtSetArg(args[n], XmNlistItemCount, count);  n++;
  }
  XtSetArg(args[n], XmNforeground, gui_get_pixel(mp->m_foreground));  n++;
  XtSetArg(args[n], XmNbackground, gui_get_pixel(mp->m_background));  n++;
  XtSetArg(args[n], XmNbuttonFontList, Gui_AppData.mediumFont);  n++;
  XtSetArg(args[n], XmNtextFontList, Gui_AppData.textFont);  n++;
  XtSetArg(args[n], XmNlabelFontList, Gui_AppData.mediumFont);  n++;
#ifndef linux
  if (solaris_version < 560) {
    XtSetArg(args[n], XmNtextTranslations, tt);  n++;
  }
#endif
  if (cs) {
    XtSetArg(args[n], XmNlistLabelString, cs);  n++;
  }
  mp->m_primary = XmCreateSelectionBox(top, "SelBox", args, n);
  XtUnmanageChild(
    XmSelectionBoxGetChild(mp->m_primary, XmDIALOG_HELP_BUTTON));
  if (mp->m_callback) {
    XtAddCallback(mp->m_primary, XmNokCallback, gui_cb_cb, mp);
    if (strchr(mp->m_callback, ':'))
      XtAddCallback(mp->m_primary, XmNcancelCallback, gui_cb_cb, mp);
  }

  /* turn off the highlight nonsense */
  n = 0;
  XtSetArg(args[n], XmNhighlightThickness, GuiHIGHLIGHT_THICKNESS);  n++;
  w = XmSelectionBoxGetChild(mp->m_primary, XmDIALOG_OK_BUTTON);
  XtSetValues(w, args, n);
  w = XmSelectionBoxGetChild(mp->m_primary, XmDIALOG_APPLY_BUTTON);
  XtSetValues(w, args, n);
  w = XmSelectionBoxGetChild(mp->m_primary, XmDIALOG_CANCEL_BUTTON);
  XtSetValues(w, args, n);
  w = XmSelectionBoxGetChild(mp->m_primary, XmDIALOG_TEXT);
  XtSetValues(w, args, n);

  if (cs)
    XmStringFree(cs);
  if (cst) {
    for(i=0; i<count; i++)
      XmStringFree(cst[i]);
    se_free(cst);
  }
  XtManageChild(mp->m_primary);
  return mp->m_primary;
}

static Widget
build_strip_chart(member_t *mp, int strip_chart, Widget top,
                  int orientation, Arg *args, int n)
{
  char *fields[GuiMAX_FIELDS];
  int scale = 0;
  int jump_pixels = 0;
  int interval = 2;
  Dimension width = 50;
  Dimension height = 50;

  if (mp->m_data) {
    memset(fields, '\0', sizeof fields);
    gui_record_split(mp->m_data, fields);
    if (fields[0])
      width = atoi(fields[0]);
    if (fields[1])
      height = atoi(fields[1]);
    if (fields[2])
      scale = atoi(fields[2]);
    if (fields[3])
      jump_pixels = atoi(fields[3]);
    if (fields[4])
      interval = atoi(fields[4]);
  }
  XtSetArg(args[n], XtNwidth,      width);  n++;
  XtSetArg(args[n], XtNheight,     height); n++;
  XtSetArg(args[n], XtNforeground, gui_get_pixel(mp->m_foreground));  n++;
  XtSetArg(args[n], XtNbackground, gui_get_pixel(mp->m_background));  n++;
  XtSetArg(args[n], XtNminScale,   scale);        n++;
  if (jump_pixels > 0) {
    XtSetArg(args[n], XtNjumpScroll, jump_pixels);  n++;
  }
  XtSetArg(args[n], XtNupdate,     interval);     n++;
  if (strip_chart)
    mp->m_primary = XtCreateWidget(
      "StripChart", stripChartWidgetClass, top, args, n);
  else
    mp->m_primary = XtCreateWidget(
      "PointChart", pointChartWidgetClass, top, args, n);
  XtAddCallback(mp->m_primary, XtNgetValue, gui_cb_cb, mp);
  XtManageChild(mp->m_primary);
  return mp->m_primary;
}

static Widget
build_clock(member_t *mp, Widget top, int orientation, Arg *args, int n)
{
  char *fields[GuiMAX_FIELDS];
  int update = 1;
  int chime = 0;
  Dimension width = 50;
  Dimension height = 100;
  Pixel fg;

  if (mp->m_data) {
    memset(fields, '\0', sizeof fields);
    gui_record_split(mp->m_data, fields);
    if (fields[0])
      width = atoi(fields[0]);
    if (fields[1])
      height = atoi(fields[1]);
    if (fields[2])
      update = atoi(fields[2]);
    if (fields[3])
      chime = atoi(fields[3]);
  }
  fg = gui_get_pixel(mp->m_foreground);
  XtSetArg(args[n], XtNwidth,       width);  n++;
  XtSetArg(args[n], XtNheight,      height); n++;
  XtSetArg(args[n], XtNforeground,  fg);     n++;
  XtSetArg(args[n], XtNhand, fg);            n++;
  XtSetArg(args[n], XtNbackground,  gui_get_pixel(mp->m_background));  n++;
  XtSetArg(args[n], XtNupdate,      update);  n++;
  XtSetArg(args[n], XtNchime,       chime);   n++;
  mp->m_primary = XtCreateWidget(
    "Clock", clockWidgetClass, top, args, n);
  XtManageChild(mp->m_primary);
  return mp->m_primary;
}

static Widget
build_paned(member_t *mp, Widget top, int orientation, Arg *args, int n)
{
  /* n is passed from calling func. */
  XtSetArg(args[n], XmNorientation, orientation);  n++;
  mp->m_primary = XmCreatePanedWindow(top, mp->m_label, args, n);
  gui_create_top_panel(mp->m_agg_head, mp->m_primary, GuiNONSPEC);
  XtManageChild(mp->m_primary);
  return mp->m_primary;
}

Boolean
gui_read_bitmap(member_t *mp, Pixmap *pmp, Dimension *width, Dimension *height)
{
  unsigned char *data;
  unsigned int w;
  unsigned int h;
  Display *display;
  Drawable d;
  Pixel fg;
  Pixel bg;

  if (Gui_toplevel == 0)
    return False;
  if (XReadBitmapFileData(mp->m_data, &w, &h, &data, 0, 0) != BitmapSuccess)
    return False;
  fg = gui_get_pixel(mp->m_foreground);
  bg = gui_get_pixel(mp->m_background);
  display = XtDisplay(Gui_toplevel);
  d = DefaultRootWindow(display);
  *pmp = XCreatePixmapFromBitmapData(display, d, (char *) data, w, h, fg, bg,
                                DefaultDepthOfScreen(XtScreen(Gui_toplevel)));
  se_free(data);
  *width = (Dimension) w;
  *height = (Dimension) h;
  return True;
}
