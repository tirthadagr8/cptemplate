/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/uio.h>
#include "netlib.h"
#include "netcmd.h"
#include "../../../avl.h"
#include "../../../se.h"

/* Break up a string containing multiple words into the individual words. */
static int
stringBreak (char *s, char *v[])
{
  char *p;
  int i = 0;

  /* for each word put it in the array */
  for (p = strtok(s, " \t"); p; p = strtok((char *) 0, " \t"))
    v[i++] = p;

  /* null terminate */
  v[i] = 0;
  return i;
}

/*+
 * net_recv_cmd
 *
 *  Receive a command from a client.
 *  The command must be sent by net_send_cmd.
 *
 *  long
 *  net_recv_cmd(sd, parseTable, count)
 *    int sd;                   The socket descriptor for the client
 *    net_cmd_t *parseTable;  The table of acceptable commands
 *    int count;                The number of entries in the parseTable
 *
 *  Returns:     0 - eof
 *               1 - procedure call (as an ok indication)
 *              -1 - error, see errno
 *              else the number of bytes written by the final write
-*/
/*&
 * CALL net_read_nbytes() to read NiMAX_CMD bytes
 * IF the read failed
 *   RETURN 0 if EOF or -1 if read error
 * ENDIF
 * CALL stringBreak() to break up the buffer into words
 * Search the command table for the command name
 * IF the command is not found
 *   Set errno to EINVAL
 *   RETURN -1
 * ENDIF
 * CALL the pointer-to-function in the command table
 * IF the command table specifies that this is a function call
 *   Construct the return value
 *   CALL net_writev_nbytes() to send the response
 *   RETURN the number of bytes written
 * ENDIF
 * RETURN 1
&*/

int
net_recv_cmd (int sd, net_cmd_t *parseTable, int count)
{
  static char *vslBuf = 0;
  static int vslBufLength = 0;
  static char *cmdBuf = 0;
  static int cmdBufLength = 0;
  char pkt[NiPKT_LEN+1];
  char buf[NiPKT_LEN+1];
  char *stringVector[64];
  char *cmd;
  int i;
  int failure = 0;
  int vec_size;
  unsigned int n = 0;
  int m;
  int length;
  int iovcnt;
  int cmdLength;
  int argLength;
  net_cmd_t *p = 0;
  struct iovec result;
  struct iovec arg;
  struct iovec vector[4];
  T_VARIABLE stringVar;
  T_VARIABLE argVar;
  T_VARIABLE *retVal;
  T_STRUCT *sp;

  /* zipity doo dah */
  memset(vector, '\0', sizeof vector);
  
  /* read the packet from the client */
  m = net_read_nbytes(sd, pkt, NiPKT_LEN);
  if (m != NiPKT_LEN)
    return (m) ? -1 : 0;

  /* I KNOW that this is 6 bytes */
  memset(buf, '\0', sizeof buf);
  memcpy(buf, pkt, 6);
  cmdLength = atoi(buf);
  memcpy(buf, pkt+6, 6);
  argLength = atoi(buf);
  length = cmdLength + argLength;

  /* allocate the vslBuf */
  if (vslBuf == 0) {
    vslBuf = (char *) malloc(length);
    if (vslBuf == 0)
      return -1;
    vslBufLength = length;
  } else if (length > vslBufLength) {
    vslBuf = (char *) realloc(vslBuf, length);
    if (vslBuf == 0)
      return -1;
    vslBufLength = length;
  }

  /* allocate the cmdBuf */
  if (cmdBuf == 0) {
    cmdBuf = (char *) malloc(cmdLength + 1);
    if (cmdLength == 0)
      return -1;
    cmdBufLength = cmdLength;
  } else if (cmdLength > cmdBufLength) {
    cmdBuf = (char *) realloc(cmdBuf, cmdLength + 1);
    if (cmdBuf == 0)
      return -1;
    cmdBufLength = cmdLength;
  }

  /* this stuff relies heavily on reliable transport */
  m = net_read_nbytes(sd, vslBuf, length);
  if (m != length)
    return (m) ? -1 : 0;

  /* grab the cmd please */
  memset(cmdBuf, '\0', cmdBufLength + 1);
  memcpy(cmdBuf, vslBuf, cmdLength);
  
  /* set up the arg for passing to the handler function */
  arg.iov_base = (caddr_t) vslBuf+cmdLength;
  arg.iov_len = argLength;

  /* break the string into words */
  vec_size = stringBreak(cmdBuf, stringVector);
  
  /* bogosity */
  if (stringVector[0] == 0)
    return -1;
  
  /* yield the command */
  cmd = stringVector[0];
  for (i = 0; i < count; i++) {
    if (parseTable[i].cmdCmd && (*cmd != *parseTable[i].cmdCmd))
      continue;
  
    if (strcmp(cmd, parseTable[i].cmdCmd) == 0) {
      p = &parseTable[i];
      break;
    }
  }
  
  /* if this is a valid function, call the associated function */
  if (p) {
    /* this is hell, but it needs to be done */
    memset(&stringVar, '\0', sizeof stringVar);
    memset(&argVar,    '\0', sizeof argVar);

    stringVar.var_type = VAR_STRING;
    stringVar.var_dimension = vec_size;
    stringVar.var_un.var_array = stringVector;

    argVar.var_type = VAR_USER;
    argVar.var_struct = se_get_struct("iovec_t");
    argVar.var_dimension = 1;

    se_clone_array(&argVar, &argVar);

    sp = ((T_STRUCT **) argVar.var_un.var_array)[0];
    se_free(argVar.var_un.var_array);
    argVar.var_dimension = 0;
    argVar.var_un.var_user = sp;
    sp->st_members->var_un.var_string = arg.iov_base;
    sp->st_members->var_next->var_un.var_udigit = arg.iov_len;

    retVal = se_function_call(p->cmdFunc, sd, &stringVar, &argVar, p->cmdData);

    if ((retVal == 0) || (retVal->var_type != VAR_USER) ||
        (strcmp(retVal->var_struct->st_name, "net_cmd_return_t") != 0))
      n = -1;
    else {
      T_STATEMENT st;
      T_FCALL fcall;
      T_EXPR expr;
      T_EXPR param1;
      T_EXPR param2;
      T_VARIABLE var;
      T_VARIABLE *vp;

      /* r_code member */
      vp = retVal->var_un.var_user->st_members;
      n = vp->var_un.var_digit;

      /* r_iov member */
      vp = vp->var_next;

      memset(&st,     '\0', sizeof st);
      memset(&fcall,  '\0', sizeof fcall);
      memset(&expr,   '\0', sizeof expr);
      memset(&param1, '\0', sizeof param1);
      memset(&param2, '\0', sizeof param2);
      memset(&var,    '\0', sizeof var);
      memset(&result, '\0', sizeof result);

      st.s_un.s_call = &fcall;     /* statement is a function call */
      fcall.c_args = &param1;      /* the call has paramaters */
      param1.e_type = E_VALUE;     /* the first param is a value */
      param1.e_variable = vp;      /* it's the iov structure */
      param1.e_next = &param2;     /* here's the second param */
      param2.e_type = E_VALUE;     /* it's also a value */
      param2.e_variable = &var;    /* here's the value */
      var.var_type = VAR_REGISTER; /* it's a register size */
      var.var_un.var_register = (T_REGISTER) &result;

      /* this is a nightmare */
      (*Se_functions[S_STRUCT_EMPTY])(&st);
    }
  } else {
    errno = EINVAL;
    return -1;
  }

  /* if this is a function call, send the results */
  m = 1;
  if (p->cmdReturn == NiFUNC) {
    for(;;) {

      /* default for these */
      argLength = 0;

      /* initial packet */
      vector[0].iov_base = (caddr_t) pkt;
      vector[0].iov_len = NiPKT_LEN;

      /* return code / errno */
      sprintf(buf, "%u/%d", n, errno);
      cmdLength = strlen(buf);

      /* set up the return info */
      vector[1].iov_base = (caddr_t) buf;
      vector[1].iov_len = cmdLength;
  
      /* remember how long everything is for the write */
      iovcnt = 2;
      length = NiPKT_LEN + cmdLength;

      /* if there is data to send back too, add it in */
      if ((failure == 0) && result.iov_base) {
        vector[2] = result;
        iovcnt = 3;
        argLength = result.iov_len;
        length += argLength;
      }

      if ((cmdLength + argLength) <= NiMAX_VSL)
        break;

      /* this is some indication of failure */
      n = NiRETURN_2BIG;
      errno = E2BIG;
      failure = 1;
    }

    /* set up the packet */
    sprintf(pkt, "%06d%06d", cmdLength, argLength);

    /* write it */
    m = net_writev_nbytes(sd, vector, iovcnt);
    if (m != length)
      return (m) ? -1 : 0;
  }
  
  return m;
}

/*+
 * net_send_cmd
 *
 *  Send a command to the server.  The command should be of the form:
 *  "COMMAND_NAME arguments".
 *
 *  Example:    fd = net_send_cmd(sd, "open /etc/passwd 0 0", IOV_NULL, NiFUNC);
 *
 *  long
 *  net_send_cmd(sd, cmd, data, function)
 *    int sd;                  The socket descriptor to the server
 *    char *cmd;               The cmd to be sent
 *    struct iovec *data;      The optional data to be sent with the command
 *    struct iovec *retValue;  The optional data returned from the command
 *    int function;            Is this command a function or procedure
 *
 *  Returns:    -1 - it failed, see errno
 *              else the return value of the remote call or 0 if procedure
-*/
/*&
 * Set up the iovec structures with the RPC information
 * CALL the net_writev_nbytes() to write the iovecs
 * IF the write failed
 *   RETURN -1
 * ENDIF
 * IF this is a function call
 *   CALL net_read_nbytes() to read the response
 *   IF the read failed
 *     RETURN -1
 *   ENDIF
 *   RETURN the return value of the remote RPC
 * ENDIF
 * RETURN 0
&*/

long
net_send_data_cmd (int sd, char *cmd, struct iovec *data,
                   struct iovec *retValue, int function)
{
  static char buf[NiMAX_VSL];
  char pkt[NiPKT_LEN+1];
  char *errnoPtr;
  int iovcnt = 2;
  int cmdLength = strlen(cmd);
  int argLength = 0;
  long m;
  int n;
  int length;
  struct iovec vector[4];

  /* zap the containers */
  memset(vector, '\0', sizeof vector);
  memset(pkt, '\0', sizeof pkt);
  
  /* set up these two */
  vector[0].iov_base = (caddr_t) pkt;
  vector[0].iov_len = NiPKT_LEN;
  vector[1].iov_base = (caddr_t) cmd;
  vector[1].iov_len = cmdLength;

  /* remember how long everything is for write */
  length = NiPKT_LEN + cmdLength;
  
  /* send data ? */
  if (data && data->iov_base) {
    vector[2] = *data;
    iovcnt = 3;
    argLength = data->iov_len;
    length += argLength;
  }
  
  /* no bigger than this */
  if ((cmdLength + argLength) > NiMAX_VSL) {
    errno = E2BIG;
    return -1;
  }
  /* we KNOW that the packet is 6 * 2 bytes */
  sprintf(pkt, "%06d%06d", cmdLength, argLength);

  /* send it */
  n = net_writev_nbytes(sd, vector, iovcnt);
  if (n != length)
    return (n) ? -1 : 0;
  
  /* if this is a function, read the result */
  m = 0;
  if (function == NiFUNC) {
    char c;

    /* read the initial packet */
    n = net_read_nbytes(sd, pkt, NiPKT_LEN);
    if (n != NiPKT_LEN)
      return (n) ? -1 : 0;

    /* I KNOW that this is 6 bytes */
    memset(buf, '\0', sizeof buf);
    memcpy(buf, pkt, 6);
    cmdLength = atoi(buf);
    memcpy(buf, pkt+6, 6);
    argLength = atoi(buf);
    length = cmdLength + argLength;

    /* get the response */
    n = net_read_nbytes(sd, buf, length);
    if (n != length)
      return (n) ? -1 : 0;
  
    /* extract the front of the buf */
    c = buf[cmdLength];
    buf[cmdLength] = '\0';

    /* split the string in two */
    if (errnoPtr = strchr(buf, '/')) {
      *errnoPtr++ = '\0';
      errno = atoi(errnoPtr);
    }
  
    /* get the values out of it */
    m = strtoul(buf, 0, 0);

    /* put the character back */
    buf[cmdLength] = c;

    /* give the return stuff back */
    if (retValue) {
      retValue->iov_base = (caddr_t) buf+cmdLength;
      retValue->iov_len = argLength;
    }
  }
  
  /* return the return code from the remote call */
  return m;
}

long
net_send_cmd (int sd, char *cmd, int function)
{
  return net_send_data_cmd(sd, cmd, IOV_NULL, IOV_NULL, function);
}
