/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef _NETCMDH_
#define _NETCMDH_

/* length of initial packet containing ascii length */
#define NiPKT_LEN            12

/* maximum length of cmd + arguments */
#define NiMAX_VSL         32768

/* maximum length of response string */
#define NiMAX_RESPONSE        16

/* some type of indication that the 2BIG is on the server side */
#define NiRETURN_2BIG        -11

/* kinda like true and false (ask: is it a function?) */
#define NiPROC                0
#define NiFUNC                1

/* possible last parameter to NiSend_cmd */
#define IOV_NULL               ((struct iovec *) 0)

typedef struct {
  char *cmdCmd;           /* the name of the cmd */
  char *cmdFunc;          /* func to call back   */
  char  cmdReturn;        /* NiFunc or NiProc    */
  char *cmdData;          /* client data         */
} net_cmd_t;

extern int net_recv_cmd (int, net_cmd_t *, int);
extern long net_send_data_cmd (int, char *, struct iovec *, struct iovec *, int);
extern long net_send_cmd (int, char *, int);

#endif
