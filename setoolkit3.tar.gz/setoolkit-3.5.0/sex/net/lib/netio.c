/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <unistd.h>
#include <sys/types.h>
#include <sys/uio.h>
#include "netlib.h"

/*+
 * net_read_nbytes
 *
 *  Loop on reads to assure the reading of so many bytes from a
 *  transport provider endpoint.
 *
 *  int
 *  net_read_nbytes(sd, buf, size)
 *    int  sd;     The transport provider endpoint (socket descriptor)
 *    char *buf;   The area to read the data into
 *    int  size;   The number of bytes to read
 *
 *  Returns:    The number of bytes read
 *              or a value <= 0 which signifies eof or error
 *
 *  Notes:      If an error indication is returned, the perror() function
 *              should be called to determine what type of error occurred.
-*/
/*&
 * DO forever
 *   CALL read() to read the number of bytes left needed to be read
 *   IF the value returned was less than or equal to zero
 *     RETURN the value
 *   ENDIF
 *   Decrement the number of bytes left needed to be read by
 *     the number returned by the call to read().
 *   IF the number of bytes left needed to be read is zero
 *     RETURN size
 *   ENDIF
 * ENDDO
&*/

int
net_read_nbytes (int sd, char *buf, int size)
{
  int i;
  int n;
  int left = size;

  for(;;) {
    for(i=0; i<5; i++) {
      n = read(sd, buf + (size - left), left);
      if (n == -1)
        return n;
      if (n > 0)
        break;
    }
    if (n == 0)
      return 0;

    left -= n;

    if (left == 0)
      return size;
  }
}

/*+
 * net_write_nbytes
 *
 *  Loop on writes to assure the writing of so many bytes from a
 *  transport provider endpoint.
 *
 *  int
 *  net_write_nbytes(sd, buf, size)
 *    int  sd;     The transport provider endpoint (socket descriptor)
 *    char *buf;   The area to write the data from
 *    int  size;   The number of bytes to write
 *
 *  Returns:    The number of bytes write
 *              or a value <= 0 which signifies eof or error
-*/
/*&
 * DO forever
 *   compute the smaller of the maximum allowable or what's left to write
 *   CALL write()
 *   IF it failed
 *     RETURN what did get written
 *   ENDIF
 *   IF there isn't anything left to write
 *     RETURN the number of bytes written
 *   ENDIF
 * ENDDO
&*/

#undef MIN
#define MIN(a, b) (((a) < (b)) ? (a) : (b))

int
net_write_nbytes (int sd, char *buf, int size)
{
  int n;
  int left = size;
  int writeSize;

  for(;;) {
    writeSize = MIN(left, NiMAX_WRITE);
    n = write(sd, buf + (size - left), writeSize);

    if (n <= 0)
      return n;

    left -= n;

    if (left == 0)
      return size;
  }
}
