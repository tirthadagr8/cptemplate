/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include "avl.h"
#include "se.h"

#ifdef _LP64
# define HEX_FORMAT "%s<0x%llx>"
# define HEX_STRUCT "%s<0x%llx>(STRUCTURE)"
#else
# define HEX_FORMAT "%s<0x%x>"
# define HEX_STRUCT "%s<0x%x>(STRUCTURE)"
#endif

#define MAX_DOTS    256		/* oh well */

static void dump_statement_list(T_STATEMENT *);
static void dump_lexpr(T_LEXPR *);
static void dump_assign(T_ASSIGN *);
static void dump_expr(T_EXPR *);
static void dump_variable(T_VARIABLE *, int);
static void dump_call(T_FCALL *);

static int for_loop = 0;

/* from generate.c */
static char *map_type_name(T_VARIABLE *);

void
se_debug_statement(T_STATEMENT *sp)
{
  char buf[BUFSIZ];
  char *p;
  T_EXPR *ep;
  T_CASE *cp;
  T_FCALL *callp;

  switch(sp->s_type) {
  case S_IF:
    printf("if (");
    dump_lexpr(sp->s_un.s_if->i_if);
    puts(")");
    break;
  case S_CALL:
    callp = sp->s_un.s_call;
    if (strcmp(callp->c_name, "se_lazy_lvalue")) {
      dump_call(sp->s_un.s_call);
      putchar('\n');
      break;
    }
    /* lazy_lvalue */
    sp = (T_STATEMENT *) callp->c_args->e_variable->var_un.var_register;
    se_debug_statement(sp);
    break;
  case S_WHILE:
    printf("while(");
    dump_lexpr(sp->s_un.s_while->w_expr);
    puts(")");
    break;
  case S_ASSIGN:
    dump_assign(sp->s_un.s_assign);
    putchar('\n');
    break;
  case S_INCREMENT:
    dump_variable(sp->s_un.s_variable, 0);
    fputs("++", stdout);
    if (for_loop == 0)
      puts(";");
    break;
  case S_DECREMENT:
    dump_variable(sp->s_un.s_variable, 0);
    fputs("--", stdout);
    if (for_loop == 0)
      puts(";");
    break;
  case S_FOR:
    for_loop++;
    printf("for(");
    if (sp->s_un.s_for->f_before)
      dump_statement_list(sp->s_un.s_for->f_before);
    fputs("; ", stdout);
    if (sp->s_un.s_for->f_while)
      dump_lexpr(sp->s_un.s_for->f_while);
    fputs("; ", stdout);
    if (sp->s_un.s_for->f_after)
      dump_statement_list(sp->s_un.s_for->f_after);
    puts(")");
    for_loop--;
    break;
  case S_SWITCH:
    printf("switch(");
    dump_expr(sp->s_un.s_switch->sw_expr);
    puts(")");
    break;
  case S_RETURN:
    printf("return ");
    if (sp->s_un.s_return->ret_expr)
      dump_expr(sp->s_un.s_return->ret_expr);
    puts(";");
    break;
  case S_BREAK:
    printf("break;\n");
    break;
  }
}

static void
dump_statement_list(T_STATEMENT *slp)
{
  T_STATEMENT *sp;

  for(sp=slp; sp; sp=sp->s_next) {
    se_debug_statement(sp);
    if (sp->s_next)
      putchar(',');
  }
}

static void
dump_lexpr(T_LEXPR *lep)
{
  switch(lep->le_op) {
  case LE_AND:
    dump_lexpr((T_LEXPR *) lep->le_left);
    fputs(" && ", stdout);
    dump_lexpr((T_LEXPR *) lep->le_right);
    break;
  case LE_OR:
    dump_lexpr((T_LEXPR *) lep->le_left);
    fputs(" || ", stdout);
    dump_lexpr((T_LEXPR *) lep->le_right);
    break;
  case LE_PREC:
    putchar('(');
    dump_lexpr((T_LEXPR *) lep->le_left);
    putchar(')');
    break;
  case LE_NOT:
    fputs("!(", stdout);
    dump_lexpr((T_LEXPR *) lep->le_left);
    putchar(')');
    break;
  case LE_EQ:
    dump_expr(lep->le_left);
    fputs(" == ", stdout);
    dump_expr(lep->le_right);
    break;
  case LE_RE_EQ:
    dump_expr(lep->le_left);
    fputs(" =~ ", stdout);
    dump_expr(lep->le_right);
    break;
  case LE_RE_NEQ:
    dump_expr(lep->le_left);
    fputs(" !=~ ", stdout);
    dump_expr(lep->le_right);
    break;
  case LE_NE:
    dump_expr(lep->le_left);
    fputs(" != ", stdout);
    dump_expr(lep->le_right);
    break;
  case LE_LT:
    dump_expr(lep->le_left);
    fputs(" < ", stdout);
    dump_expr(lep->le_right);
    break;
  case LE_GT:
    dump_expr(lep->le_left);
    fputs(" > ", stdout);
    dump_expr(lep->le_right);
    break;
  case LE_GE:
    dump_expr(lep->le_left);
    fputs(" >= ", stdout);
    dump_expr(lep->le_right);
    break;
  case LE_LE:
    dump_expr(lep->le_left);
    fputs(" <= ", stdout);
    dump_expr(lep->le_right);
    break;
  }
}

static void
dump_assign(T_ASSIGN *ap)
{
  static char *op[] = {
    0,
    " = ",    /* A_ASSIGN=1       */
    " += ",   /* A_ADD=2          */
    " -= ",   /* A_SUBTRACT=3     */
    " *= ",   /* A_MULTIPLY=4     */
    " /= ",   /* A_DIVIDE=5       */
    " %= ",   /* A_MODULUS=6,     */
    " &= ",   /* A_BIT_AND=7      */
    " |= ",   /* A_BIT_OR=8       */
    " ^= ",   /* A_BIT_XOR=9      */
    " <<= ",  /* A_SHIFT_LEFT=10  */
    " >>= "   /* A_SHIFT_RIGHT=11 */
  };

  dump_variable(ap->a_variable, 0);
  fputs(op[ap->a_op], stdout);
  dump_expr(ap->a_expression);
}

static void
dump_expr(T_EXPR *ep)
{
  static char *op[] = {
    0,
    " + ",  /* EO_ADD=1          */
    " - ",  /* EO_SUBTRACT=2     */
    " * ",  /* EO_MULTIPLY=3     */
    " / ",  /* EO_DIVIDE=4       */
    " % ",  /* EO_MODULUS=5,     */
    " & ",  /* EO_BIT_AND=6      */
    " | ",  /* EO_BIT_OR=7       */
    " ^ ",  /* EO_BIT_XOR=8      */
    " << ", /* EO_SHIFT_LEFT=9   */
    " >> "  /* EO_SHIFT_RIGHT=10 */
  };
  T_VARIABLE var;

  switch(ep->e_type) {
  case E_VALUE:
    dump_variable(ep->e_variable, 1);
    return;
  case E_EXPRESSION:
    if (ep->e_op == EO_PRECEDENCE) {
      putchar('(');
      dump_expr(ep->e_left);
      putchar(')');
      return;
    }
    if (ep->e_op == EO_BIT_NOT) {
      putchar('~');
      dump_expr(ep->e_left);
      return;
    }
    break;
  case E_CALL:
    if (strcmp(ep->e_call->c_name, "se_lazy_value") == 0)
      dump_expr(ep->e_call->c_args);
    else
      dump_call(ep->e_call);
    return;
  case E_INCRA:
  case E_LAZY_INCRA:
    dump_variable(ep->e_variable, 1);
    fputs("++", stdout);
    return;
  case E_INCRB:
  case E_LAZY_INCRB:
    fputs("++", stdout);
    dump_variable(ep->e_variable, 1);
    return;
  case E_DECRA:
  case E_LAZY_DECRA:
    dump_variable(ep->e_variable, 1);
    fputs("--", stdout);
    return;
  case E_DECRB:
  case E_LAZY_DECRB:
    fputs("--", stdout);
    dump_variable(ep->e_variable, 1);
    return;
  case E_QCOP:
    putchar('(');
    dump_lexpr(ep->e_lexpr);
    fputs(" ? ", stdout);
    dump_expr(ep->e_left);
    fputs(" : ", stdout);
    dump_expr(ep->e_right);
    putchar(')');
    return;
  case E_ASSIGN:
    putchar('(');
    dump_assign(ep->e_assign);
    putchar(')');
    return;
  default:
    break;
  }

  dump_expr(ep->e_left);
  fputs(op[ep->e_op], stdout);
  dump_expr(ep->e_right);
}

static char *
s_fix(char *s)
{
  static char buf[BUFSIZ];
  char *p = buf;
  register char c;

  if (strlen(s) > sizeof buf)
    return s;
  while(c = *s++) {
    switch(c) {
    case '\b':
      *p++ = '\\';
      *p++ = 'b';
      break;
    case '\f':
      *p++ = '\\';
      *p++ = 'f';
      break;
    case '\n':
      *p++ = '\\';
      *p++ = 'n';
      break;
    case '\t':
      *p++ = '\\';
      *p++ = 't';
      break;
    case '\r':
      *p++ = '\\';
      *p++ = 'r';
      break;
    default:
      if (isprint(c))
        *p++ = c;
      else {
        sprintf(p, "\\x%x", c);
        p = &buf[strlen(p)];
      }
      break;
    }
  }
  *p = '\0';
  return buf;
}

void __dv__(T_VARIABLE *vp)
{
  dump_variable(vp, 1);
}

static T_VARIABLE *
get_lazy_member(T_VARIABLE *vp, T_VARIABLE *member_list[])
{
  int i;
  int subscript;
  int member_count = 0;
  anode *anp;
  T_EXPR *sub;
  T_STRUCT *stp;
  T_VARIABLE *vvp;
  T_VARIABLE *mvp;
  T_VARIABLE *xvp;
  T_VARIABLE *parent;

  for(parent=vp->var_parent; parent; parent=parent->var_parent) {
    if (member_count == MAX_DOTS)
      se_fatal("dot notation overflow");
    member_list[member_count++] = parent;
  }
  for(i=member_count-1, mvp=parent=member_list[i]; i>=0; i--, parent=vvp) {
    if (mvp->var_subscript) {
      subscript = se_compute_subscript(mvp, 0);
      stp = ((T_STRUCT **) parent->var_un.var_array)[subscript];
    } else
      stp = parent->var_un.var_user;
    if (i == 0)
      mvp = vp;
    else
      mvp = member_list[i - 1];
    for(vvp=stp->st_members; vvp; vvp=vvp->var_next)
      if (strcmp(mvp->var_name, vvp->var_name) == 0)
        break;
    if (vvp == 0)
      se_fatal("cannot evaluate member: %s", mvp->var_name);
  }
  return vvp;
}

static void
dump_variable(T_VARIABLE *vp, int show_value)
{
  char buf[2];
  char *p;
  char *name;
  int i;
  int j;
  int lazy = 0;
  unsigned char c;
  unsigned short s;
  unsigned int l;
  T_ULLONG ll;
  double d;
  void *array = 0;
  int subscript = -1;
  T_VARIABLE *vvp;
  T_VARIABLE *parents[MAX_DOTS];
  T_STRUCT *sp;

#if 0
  for(i=0; i<show_value; i++)
    putchar(' ');
#endif

  if (vp->var_parent) {
    for(i=0, vvp=vp->var_parent; vvp; vvp=vvp->var_parent, i++)
      parents[i] = vvp;
    for(j=i-1; j>=0; j--) {
      printf("%s", parents[j]->var_name);
      if (parents[j]->var_subscript) {
        subscript = se_compute_subscript(parents[j], 0);
        printf("[%d]", subscript);
        if (parents[j]->var_type = VAR_USER)
          lazy = 1;
      }
      putchar('.');
    }
#if 0
    if (show_value) {
      for(vvp=sp->st_members; vvp; vvp=vvp->var_next)
        if (strcmp(vvp->var_name, vp->var_name) == 0)
          break;
      if (vvp)
        vp = vvp;
    }
#endif
  }

  if (lazy)
    vp = get_lazy_member(vp, parents);

  if (vp->var_dimension)
    array = vp->var_un.var_array;
  if (vp->var_subscript)
    subscript = se_compute_subscript(vp, 0);

  switch(vp->var_type) {
  case VAR_STRING:
    if (array) {
      if (subscript != -1) {
        p = ((char **) array)[subscript];
        if (show_value)
          printf("%s[%d]<%s>",
            vp->var_name ? vp->var_name : "",
            subscript, p ? s_fix(p) : "(nil)");
        else
          printf("%s[%d]",
            vp->var_name ? vp->var_name : "", subscript);
      } else
        if (show_value)
          printf(HEX_FORMAT, vp->var_name ? vp->var_name : "", array);
        else
          fputs(vp->var_name ? vp->var_name : "", stdout);
    } else {
      p = vp->var_un.var_string;
      if (show_value)
        printf("%s<%s>",
          vp->var_name ? vp->var_name : "", p ? s_fix(p) : "(nil)");
      else
        fputs(vp->var_name ? vp->var_name : "", stdout);
    }
    break;
  case VAR_CHAR:
    buf[0] = buf[1] = 0;
    if (array) {
      if (subscript != -1) {
        buf[0] = ((char *) array)[subscript];
        if (show_value)
          printf("%s[%d]<%s>",
            vp->var_name ? vp->var_name : "", subscript, s_fix(buf));
        else
          printf("%s[%d]", vp->var_name ? vp->var_name : "", subscript);
      } else
        if (show_value)
          printf("%s<%s>", vp->var_name ? vp->var_name : "",
                  s_fix((char *) array));
        else
          fputs(vp->var_name ? vp->var_name : "", stdout);
    } else {
      buf[0] = (char) vp->var_un.var_digit;
      if (show_value)
        printf("%s<%s>", vp->var_name ? vp->var_name : "", s_fix(buf));
      else
        fputs(vp->var_name ? vp->var_name : "", stdout);
    }
    break;
  case VAR_UCHAR:
    if (array) {
      if (subscript != -1) {
        c = ((unsigned char *) array)[subscript];
        if (show_value)
          printf("%s[%d]<%u>", vp->var_name ? vp->var_name : "", subscript, c);
        else
          printf("%s[%d]", vp->var_name ? vp->var_name : "", subscript);
      } else
        if (show_value)
          printf(HEX_FORMAT, vp->var_name, array);
        else
          fputs(vp->var_name ? vp->var_name : "", stdout);
    } else {
      c = (unsigned char) vp->var_un.var_udigit;
      if (show_value)
        printf("%s<%u>", vp->var_name ? vp->var_name : "", c);
      else
        fputs(vp->var_name ? vp->var_name : "", stdout);
    }
    break;
  case VAR_SHORT:
    if (array) {
      if (subscript != -1) {
        s = ((short *) array)[subscript];
        if (show_value)
          printf("%s[%d]<%d>",
            vp->var_name ? vp->var_name : "", subscript, s);
        else
          printf("%s[%d]",
            vp->var_name ? vp->var_name : "", subscript);
      } else
        if (show_value)
          printf(HEX_FORMAT, vp->var_name, array);
        else
          fputs(vp->var_name ? vp->var_name : "", stdout);
    } else {
      s = (short) vp->var_un.var_digit;
      if (show_value)
        printf("%s<%d>", vp->var_name ? vp->var_name : "", s);
      else
        fputs(vp->var_name ? vp->var_name : "", stdout);
    }
    break;
  case VAR_USHORT:
    if (array) {
      if (subscript != -1) {
        s = ((unsigned short *) array)[subscript];
        if (show_value)
          printf("%s[%d]<%u>",
            vp->var_name ? vp->var_name : "", subscript, s);
        else
          printf("%s[%d]",
            vp->var_name ? vp->var_name : "", subscript);
      } else
        if (show_value)
          printf(HEX_FORMAT, vp->var_name, array);
        else
          fputs(vp->var_name ? vp->var_name : "", stdout);
    } else {
      s = (unsigned short) vp->var_un.var_udigit;
      if (show_value)
        printf("%s<%u>", vp->var_name ? vp->var_name : "", s);
      else
        fputs(vp->var_name ? vp->var_name : "", stdout);
    }
    break;
  case VAR_LONG:
    if (array) {
      if (subscript != -1) {
        l = ((int *) array)[subscript];
        if (show_value)
          printf("%s[%d]<%d>",
            vp->var_name ? vp->var_name : "", subscript, l);
        else
          printf("%s[%d]",
            vp->var_name ? vp->var_name : "", subscript);
      } else
        if (show_value)
          printf(HEX_FORMAT, vp->var_name, array);
        else
          fputs(vp->var_name ? vp->var_name : "", stdout);
    } else {
      l = vp->var_un.var_digit;
      if (show_value)
        printf("%s<%d>", vp->var_name ? vp->var_name : "", l);
      else
        fputs(vp->var_name ? vp->var_name : "", stdout);
    }
    break;
  case VAR_ULONG:
    if (array) {
      if (subscript != -1) {
        l = ((unsigned int *) array)[subscript];
        if (show_value)
          printf("%s[%d]<%u>",
            vp->var_name ? vp->var_name : "", subscript, l);
        else
          printf("%s[%d]",
            vp->var_name ? vp->var_name : "", subscript);
      } else
        if (show_value)
          printf(HEX_FORMAT, vp->var_name, array);
        else
          fputs(vp->var_name ? vp->var_name : "", stdout);
    } else {
      l = vp->var_un.var_udigit;
      if (show_value)
        printf("%s<%u>", vp->var_name ? vp->var_name : "", l);
      else
        fputs(vp->var_name ? vp->var_name : "", stdout);
    }
    break;
  case VAR_LONGLONG:
    if (array) {
      if (subscript != -1) {
        ll = ((T_LLONG *) array)[subscript];
        if (show_value)
          printf("%s[%d]<%lld>",
            vp->var_name ? vp->var_name : "", subscript, ll);
        else
          printf("%s[%d]", vp->var_name ? vp->var_name : "", subscript);
      } else
        if (show_value)
          printf(HEX_FORMAT, vp->var_name, array);
        else
          fputs(vp->var_name ? vp->var_name : "", stdout);
    } else {
      ll = vp->var_un.var_ldigit;
      if (show_value)
        printf("%s<%lld>", vp->var_name ? vp->var_name : "", ll);
      else
        fputs(vp->var_name ? vp->var_name : "", stdout);
    }
    break;
  case VAR_ULONGLONG:
    if (array) {
      if (subscript != -1) {
        ll = ((T_ULLONG *) array)[subscript];
        if (show_value)
          printf("%s[%d]<%llu>",
            vp->var_name ? vp->var_name : "", subscript, ll);
        else
          printf("%s[%d]", vp->var_name ? vp->var_name : "", subscript);
      } else
        if (show_value)
          printf(HEX_FORMAT, vp->var_name, array);
        else
          fputs(vp->var_name ? vp->var_name : "", stdout);
    } else {
      ll = vp->var_un.var_uldigit;
      if (show_value)
        printf("%s<%llu>", vp->var_name ? vp->var_name : "", ll);
      else
        fputs(vp->var_name ? vp->var_name : "", stdout);
    }
    break;
  case VAR_DOUBLE:
    if (array) {
      if (subscript != -1) {
        d = ((double *) array)[subscript];
        if (show_value)
          printf("%s[%d]<%g>",
            vp->var_name ? vp->var_name : "", subscript, d);
        else
          printf("%s[%d]", vp->var_name ? vp->var_name : "", subscript);
      } else
        if (show_value)
          printf(HEX_FORMAT, vp->var_name, array);
        else
          fputs(vp->var_name ? vp->var_name : "", stdout);
    } else {
      d = vp->var_un.var_rdigit;
      if (show_value)
        printf("%s<%g>", vp->var_name ? vp->var_name : "", d);
      else
        fputs(vp->var_name ? vp->var_name : "", stdout);
    }
    break;
  case VAR_USER:
    name = vp->var_name ? vp->var_name : "LAZY_VALUE";
    if (array) {
      if (subscript != -1)
        if (show_value)
          printf("%s[%d](STRUCTURE)", name, subscript);
        else
          printf("%s[%d]", name, subscript);
      else
        if (show_value)
          printf(HEX_STRUCT, name, array);
        else
          fputs(name, stdout);
    } else {
      if (show_value)
        printf("%s(STRUCTURE)", name);
      else
        fputs(name, stdout);
#if 0
      printf("%s = {\n", name);
      for(vvp=vp->var_un.var_user->st_members; vvp; vvp=vvp->var_next) {
        dump_variable(vvp, show_value+1);
        putchar('\n');
      }
      for(i=0; i<show_value; i++)
        putchar(' ');
      putchar('}');
#endif
    }
    break;
  }
}

static void
dump_call(T_FCALL *cp)
{
  T_EXPR *ep;

  if (strcmp(cp->c_name, "address_of") == 0) {
    putchar('&');
    dump_variable(cp->c_args->e_variable, 1);
    return;
  } else if (strcmp(cp->c_name, "type_cast") == 0) {
    printf("((%s) ", map_type_name(cp->c_block->b_return));
    dump_expr(cp->c_args);
    putchar(')');
    return;
  } else if (strcmp(cp->c_name, "indirection") == 0) {
    printf("*((%s *) ", map_type_name(cp->c_block->b_return));
    dump_expr(cp->c_args);
    putchar(')');
    return;
  } else if (strcmp(cp->c_name, "new") == 0) {
    printf("new %s[", map_type_name(cp->c_block->b_return));
    dump_expr(cp->c_args->e_variable->var_initial);
    putchar(']');
    return;
  } else if (strcmp(cp->c_name, "renew") == 0) {
    printf("renew %s[", cp->c_args->e_variable->var_name);
    dump_expr(cp->c_args->e_next);
    putchar(']');
    return;
  }
  printf("%s(", cp->c_name);
  if (cp->c_args) {
    for(ep=cp->c_args; ep; ep=ep->e_next) {
      dump_expr(ep);
      if (ep->e_next)
        fputs(", ", stdout);
    }
  }
  putchar(')');
}

static char *
map_type_name(T_VARIABLE *vp)
{
  switch(vp->var_type) {
  case VAR_CHAR:
    return "char";
    break;
  case VAR_UCHAR:
    return "uchar";
    break;
  case VAR_SHORT:
    return "short";
    break;
  case VAR_USHORT:
    return "ushort";
    break;
  case VAR_LONG:
    return "int";
    break;
  case VAR_ULONG:
    return "uint";
    break;
  case VAR_LONGLONG:
    return "longlong";
    break;
  case VAR_ULONGLONG:
    return "ulonglong";
    break;
  case VAR_DOUBLE:
    return "double";
    break;
  case VAR_STRING:
    return "string";
    break;
  case VAR_USER:
    return vp->var_struct->st_name;
    break;
  }
}
