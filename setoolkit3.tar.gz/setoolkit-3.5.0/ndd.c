/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stropts.h>
#include <inet/nd.h>
#include "avl.h"
#include "se.h"

/* for the m_toldem member */
#define TOLDEM_OPEN     1
#define TOLDEM_IOCTL    2

typedef struct _map T_MAP;
struct _map {
  char   *m_type_name;      /* type name from include file         */
  char   *m_dev_name;       /* name of device to get this var from */
  int     m_sd;             /* stream descriptor                   */
  int     m_toldem;         /* a warning has been issued           */
};

#define NDD_TYPES_INCREMENT   8
#define NDD_BUF_INCREMENT     65536

static T_MAP *ndd_types;
static int    ndd_typesiz;
static int    ndd_type_number;
static char  *ndd_buf;
static int    ndd_bufsiz;

void
se_init_ndd(void)
{
  if (ndd_types)
    return;
  ndd_types = (T_MAP *) se_alloc(sizeof(T_MAP) * NDD_TYPES_INCREMENT);
  ndd_typesiz = NDD_TYPES_INCREMENT;
  ndd_type_number = 0;
  ndd_buf = (char *) se_alloc(NDD_BUF_INCREMENT);
  ndd_bufsiz = NDD_BUF_INCREMENT;
}

void
se_add_ndd_type(T_STRUCT *sp)
{
  T_MAP *mp;

  if (ndd_types == 0)
    se_init_ndd();
  if (ndd_type_number == ndd_typesiz) {
    int n = ndd_typesiz + NDD_TYPES_INCREMENT;
    mp = (T_MAP *) se_alloc(sizeof(T_MAP) * n);
    memcpy(mp, ndd_types, sizeof(T_MAP) * ndd_typesiz);
    ndd_typesiz = n;
    se_free(ndd_types);
    ndd_types = mp;
  }
  mp = &ndd_types[ndd_type_number++];
  mp->m_type_name = sp->st_name;
  mp->m_dev_name = sp->st_kname;
  mp->m_sd = -1;
  mp->m_toldem = 0;
}

static void
refresh_ndd_member(T_VARIABLE *vp, int cmd)
{
  char *p;
  char *name;
  char *var_name;
  int i;
  int done = 0;
  T_MAP *mp;
  struct strioctl str_cmd;

  /* all ndd variables are structures. period. */
  if (vp->var_parent == 0)
    return;
  /* hunt this type down from the map */
  name = vp->var_parent->var_struct->st_name;
  for(mp=ndd_types; mp->m_type_name; mp++)
    if (strcmp(mp->m_type_name, name) == 0)
      break;
  if (mp->m_type_name == 0)
    return;
  if (mp->m_sd == -1) {
    mp->m_sd = open(mp->m_dev_name, O_RDWR);
    if (mp->m_sd == -1) {
      if ((mp->m_toldem & TOLDEM_OPEN) == 0) {
        se_warning("cannot open %s: %s", mp->m_dev_name, strerror(errno));
        mp->m_toldem |= TOLDEM_OPEN;
      }
      return;
    }
  }
  do {
    memset(ndd_buf, '\0', ndd_bufsiz);
    str_cmd.ic_cmd = cmd;
    str_cmd.ic_timout = 0;
    str_cmd.ic_dp = ndd_buf;
    str_cmd.ic_len = ndd_bufsiz;
    var_name = vp->var_name;
    if (*var_name == '_')       /* can't anyone make variable names uniform? */
      var_name++;
    switch(cmd) {
    case ND_GET:
      strcpy(ndd_buf, var_name);
      break;
    case ND_SET:
      switch(vp->var_type) {
      case VAR_LONG:
        snprintf(ndd_buf, ndd_bufsiz,
          "%s%c%d", var_name, '\0', vp->var_un.var_digit);
        break;
      case VAR_STRING:
        snprintf(ndd_buf, ndd_bufsiz,
          "%s%c%s", var_name, '\0', vp->var_un.var_string);
        break;
      default:
        /* ? */
        return;
      }
      break;
    default:
      /* ? */
      return;
    }
    if (ioctl(mp->m_sd, I_STR, &str_cmd) == -1) {
      /* no errors on get of write-only variables */
      if (! ((cmd == ND_GET) && (errno == EACCES)) ) {
        if ((mp->m_toldem & TOLDEM_IOCTL) == 0) {
          se_warning("%s ioctl of %s failed: %s",
              (cmd == ND_GET) ? "get" : "set", vp->var_name, strerror(errno));
          mp->m_toldem |= TOLDEM_IOCTL;
        }
      }
      return;
    }
    if (cmd == ND_GET) {
      switch(vp->var_type) {
      case VAR_LONG:
        vp->var_un.var_digit = atol(ndd_buf);
        done = 1;
        break;
      case VAR_STRING:
        if (str_cmd.ic_len == ndd_bufsiz) {
          se_free(ndd_buf);
          ndd_bufsiz += NDD_BUF_INCREMENT;
          ndd_buf = (char *) se_alloc(ndd_bufsiz);
          continue;
        }
        for(i=0, p=ndd_buf; i<str_cmd.ic_len - 1; i++, p++)
          if (*p == '\0')
            *p = '\n';
        se_new_string(&vp->var_un.var_string, ndd_buf);
        done = 1;
        break;
      default:
        /* ? */
        return;
      }
    } else
      done = 1;
  } while(!done);
}

void
se_refresh_ndd_variable(T_VARIABLE *vp)
{
  T_VARIABLE *vvp;

  if (vp->var_type == VAR_USER)
    for(vvp=vp->var_un.var_user->st_members; vvp; vvp=vvp->var_next)
      refresh_ndd_member(vvp, ND_GET);
  else
    refresh_ndd_member(vp, ND_GET);
}

void
se_update_ndd_variable(T_VARIABLE *vp)
{
  T_VARIABLE *vvp;

  if (vp->var_type == VAR_USER)
    for(vvp=vp->var_un.var_user->st_members; vvp; vvp=vvp->var_next)
      refresh_ndd_member(vvp, ND_SET);
  else
    refresh_ndd_member(vp, ND_SET);
}

void
se_end_ndd(void)
{
  T_MAP *mp;

  for(mp=ndd_types; mp->m_type_name; mp++)
    if (mp->m_sd != -1)
      close(mp->m_sd);
}
