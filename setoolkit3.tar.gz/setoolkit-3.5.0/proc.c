/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <dirent.h>
# define _STRUCTURED_PROC 1
#include <sys/procfs.h>
#include <sys/param.h>
#include <sys/user.h>
#include <sys/proc.h>
#include <sys/stat.h>
#include <sys/sysmacros.h>
#include "avl.h"
#include "se.h"

#define PROC_DIR     "/proc"
#define PROC_PID     "pr_pid"
#define MAX_TT_LEN   128
#define DIRENT       struct dirent

static void assign_values(T_STATEMENT *, psinfo_t *);

static DIR      *dirp;
static psinfo_t  zero_proc;

static void
init_dir(void)
{
  if (dirp == 0) {
    dirp = opendir(PROC_DIR);
    if (dirp == 0)
      se_fatal("cannot open procdir: %s", PROC_DIR);
  }
}

void
run_next_proc(T_STATEMENT *sp)
{
  char process[BUFSIZ];
  int input;
  DIRENT *dep;
  psinfo_t procinfo;

  init_dir();
  procinfo = zero_proc;
  procinfo.pr_pid = -1;
  while(dep = readdir(dirp)) {
    if (dep->d_name[0] == '.')
      continue;
    snprintf(process, sizeof process, "%s/%s/psinfo", PROC_DIR, dep->d_name);
    input = open(process, O_RDONLY);
    if (input != -1) {
      if (read(input, &procinfo, sizeof(psinfo_t)) != sizeof(psinfo_t)) {
        close(input);
        continue;
      }
    }
    close(input);
    break;
  }
  assign_values(sp, &procinfo);
}

void
run_first_proc(T_STATEMENT *sp)
{
  init_dir();
  rewinddir(dirp);
  run_next_proc(sp);
}

void
run_get_proc(T_STATEMENT *sp)
{
  char process[BUFSIZ];
  int pid;
  int input;
  psinfo_t procinfo;
  T_VARIABLE var;

  memset(&var, '\0', sizeof var);
  se_resolve_expression(&var, sp->s_un.s_call->c_args, 1);
  if (Se_type_sizes[var.var_type] != Se_type_sizes[VAR_LONG])
    se_fix_type(&var, VAR_LONG);
  pid = var.var_un.var_digit;

  procinfo = zero_proc;
  snprintf(process, sizeof process, "%s/%d/psinfo", PROC_DIR, pid);
  input = open(process, O_RDONLY);
  if (input != -1)
    if (read(input, &procinfo, sizeof(psinfo_t)) != sizeof(psinfo_t))
      procinfo.pr_pid = -1;
  close(input);
  assign_values(sp, &procinfo);
}

static void
assign_values(T_STATEMENT *sp, psinfo_t *procinfo)
{
  T_VARIABLE *vp = sp->s_un.s_call->c_block->b_return;

  /* copy the psinfo_t struct into the variable */
  se_area_into_struct((uchar_t *) procinfo, vp);
}

struct tty_devs {
  char   *td_device;
  char   *td_name;
  int    *td_major;
  char *(*td_compose)(char *, dev_t, struct tty_devs *);
};

static char *
pts_compose(char *name, dev_t dev, struct tty_devs *tp)
{
  snprintf(name, MAX_TT_LEN, tp->td_name, geteminor(dev));
  return name;
}

static char *
tty_compose(char *name, dev_t dev, struct tty_devs *tp)
{
  char p = 'a';

  snprintf(name, MAX_TT_LEN, tp->td_name, p + geteminor(dev));
  return name;
}

static char *
pty_compose(char *name, dev_t dev, struct tty_devs *tp)
{
  char p = 'p';

  snprintf(name, MAX_TT_LEN,
    tp->td_name, p + geteminor(dev) / 16, geteminor(dev) % 16);
  return name;
}

/* this function is attached in proc.se */

char *
dev_to_tty(dev_t dev)
{
  static int console_major;
  static int pts_major;
  static int pty_major;
  static int tty_major;
  static struct tty_devs tty_map[] = {
    { "/dev/console",  "console",  &console_major,  0           },
    { "/dev/pts/0",    "pts/%d",   &pts_major,      pts_compose },
    { "/dev/ttya",     "tty%c",    &tty_major,      tty_compose },
    { "/dev/ttyp0",    "tty%c%d",  &pty_major,      pty_compose },
    { 0,               0,          0,               0           }
  };
  static char *unknown = "?";
  static char name[MAX_TT_LEN];
  static int initialized = 0;
  struct tty_devs *tp;
  struct stat stbuf;

  if (initialized == 0) {
    for(tp=tty_map; tp->td_device; tp++) {
      if (stat(tp->td_device, &stbuf) == -1)
        continue;
      *tp->td_major = getemajor(stbuf.st_rdev);
    }
    initialized = 1;
  }
  for(tp=tty_map; tp->td_device; tp++)
    if (getemajor(dev) == *tp->td_major)
      return (tp->td_compose) ? (*tp->td_compose)(name, dev, tp) : tp->td_name;
  return unknown;
}
