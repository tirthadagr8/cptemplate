
typedef union
#ifdef __cplusplus
	YYSTYPE
#endif
 {
  int          integer;
  double       real;
  char        *string;
  T_BLOCK     *block;
  T_STATEMENT *statement;
  T_IF        *if_statement;
  T_FCALL     *call_statement;
  T_WHILE     *while_statement;
  T_ASSIGN    *assign_statement;
  T_EXPR      *expression;
  T_LEXPR     *l_expression;
  T_VARIABLE  *variable;
  T_STRUCT    *structure;
  T_VARTYPE    var_type;
  T_FOR       *for_statement;
  T_DO        *do_statement;
  T_SWITCH    *switch_statement;
  T_CASE      *case_statement;
  T_RETURN    *return_statement;
  T_BREAK     *break_statement;
  T_CONTINUE  *continue_statement;
  T_SFTYPE     struct_flags;
} YYSTYPE;
extern YYSTYPE yylval;
# define AMPERSAND 257
# define AND 258
# define AND_EQ 259
# define ASSIGN 260
# define ASTERISK 261
# define ATTACH 262
# define BREAK 263
# define CASE 264
# define CHAR_TYPE 265
# define CLASS 266
# define COLON 267
# define COMMA 268
# define CONTINUE 269
# define DECREMENT 270
# define DEFAULT 271
# define DO 272
# define DOT 273
# define DOUBLE_TYPE 274
# define ELLIPSIS 275
# define ELSE 276
# define EQ 277
# define EXCLAMATION 278
# define EXTERN 279
# define FOR 280
# define GE 281
# define GT 282
# define HAT 283
# define IF 284
# define INCREMENT 285
# define INTEGER 286
# define KSTAT 287
# define KVM 288
# define LE 289
# define LEFT_CURLY 290
# define LEFT_PAREN 291
# define LEFT_SQUARE 292
# define LNEW 293
# define LONGLONG_TYPE 294
# define LONG_TYPE 295
# define LRENEW 296
# define LT 297
# define MIB 298
# define MINUS 299
# define MINUS_EQ 300
# define MOD_EQ 301
# define NDD 302
# define NE 303
# define NIL 304
# define OR 305
# define OR_EQ 306
# define PERCENT 307
# define PIPE 308
# define PLUS 309
# define PLUS_EQ 310
# define PRAGMA 311
# define QSTRING 312
# define RE_EQ 313
# define RE_NEQ 314
# define REAL 315
# define LRETURN 316
# define QUESTION 317
# define RIGHT_CURLY 318
# define RIGHT_PAREN 319
# define RIGHT_SQUARE 320
# define SEMICOLON 321
# define SHIFT_LEFT 322
# define SHIFT_RIGHT 323
# define SHIFT_LEFT_EQ 324
# define SHIFT_RIGHT_EQ 325
# define SHORT_TYPE 326
# define SLASH 327
# define SLASH_EQ 328
# define STRING 329
# define STRING_TYPE 330
# define STRUCT 331
# define SWITCH 332
# define TILDE 333
# define TIMES_EQ 334
# define UCHAR_TYPE 335
# define ULONGLONG_TYPE 336
# define ULONG_TYPE 337
# define USER_TYPE 338
# define USHORT_TYPE 339
# define WHILE 340
# define XOR_EQ 341
# define AT_SIGN 342
# define BACKSLASH 343
# define DOT_DOT 344
# define EOLN 345
# define BI_MAX_CPU 346
# define BI_MAX_DISK 347
# define BI_MAX_IF 348
# define BI_MAX_INTS 349
