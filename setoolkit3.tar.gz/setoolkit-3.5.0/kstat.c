/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <kstat.h>
#include <string.h>
#include <errno.h>
#include <sys/sysinfo.h>
#include <sys/vnode.h>
#include <sys/vfs.h>
#include <sys/dnlc.h>
#include <sys/var.h>
#include <sys/vmmeter.h>
#include <sys/fs/cachefs_fs.h>
#include <sys/fs/cachefs_fscache.h>
#include <nfs/nfs.h>
#include <nfs/nfs_clnt.h>
#include <libgen.h>
#include <sys/types.h>
#include <regex.h>
#include "avl.h"
#include "se.h"

/* #define I_WANT_TO_SEE_STATE_CHANGES 1 */

#undef MAX
#define MAX(a, b) (((a) > (b)) ? (a) : (b))

#define MAX_K 64

/* no st or nfs in DISKS, just in lex */
#define DISKS "id", "sd", "fd", "ssd", "ptesp-scsi-bus", "*ptesp", "td", "md",\
              "cmdk", "FTscsi", "dad", "atapicd"

#define INTRS "esp", "fd", "zs", "hme", "fdc", "cgsix", "audio"

/* check with IF names in lex.c */
#define MAX_NAME_VEC 128

typedef struct _map T_MAP;
typedef struct _rec T_REC;
typedef struct ncstats ncstats_t;
typedef struct var var_t;
typedef struct flushmeter flushmeter_t;

struct _map {
  int   m_type;                /* KSTAT_TYPE type                           */
  char *m_type_name;           /* variable type name                        */
  char *m_lookup_name[MAX_K];  /* name as contained in kstat          */
  int  (*m_load_raw)(kstat_t *, T_VARIABLE *, avlhdr *, int);
};
/* m_lookup_name: 

name exact match:
  m_lookup_name[0] == name, m_lookup_name[1] == 0
name prefix match:
  m_lookup_name[0] == *name, m_lookup_name[1] == ""
module list exact match:
  m_lookup_name[0] == module0, m_lookup_name[1] == module1 ...
                      ... m_lookup_name[n] == "" 
kstat notation:
  module:    m_lookup_name[0] = match type, m_lookup_name[4] == pattern
  instance:  m_lookup_name[1] = match type, m_lookup_name[5] == pattern
  name:      m_lookup_name[2] = match type, m_lookup_name[6] == pattern
  statistic: m_lookup_name[3] = match type, m_lookup_name[7] == pattern 

match type: ":A" all, ":G" gmatch, ":R" regexpr
*/

/* offsets in m_lookup_name for kstat notation fields */
enum {
  MODULE = 0,
  INSTANCE = 1,
  NAME = 2,
  STATISTIC = 3,
  PATTERN = 4
};

typedef enum {
  R_TREE, R_ARRAY
} T_RTYPE;

struct _rec {
  T_RTYPE r_type;        /* whither R_TREE or R_ARRAY           */
  int     r_ktype;       /* KSTAT_TYPE_NAMED, etc.              */
  int     r_count;       /* how many trees in the array         */
  union {
    avlhdr *r_tree;      /* one tree                            */
    avlhdr **r_array;    /* many trees                          */
  } r_un;
};

typedef struct {
  int   ck_id;
  int   ck_ismounted;
  void *ck_vfsp;
  int   ck_mp_index;
  int   ck_bf_index;
  int   ck_cd_index;
  int   ck_ci_index;
} cachefs_key_t;

static int  load_sysinfo  (kstat_t *, T_VARIABLE *, avlhdr *, int);
static int  load_vminfo   (kstat_t *, T_VARIABLE *, avlhdr *, int);
static int  load_ncstats  (kstat_t *, T_VARIABLE *, avlhdr *, int);
static int  load_var      (kstat_t *, T_VARIABLE *, avlhdr *, int);
static int  load_cpusys   (kstat_t *, T_VARIABLE *, avlhdr *, int);
static int  load_cpuwait  (kstat_t *, T_VARIABLE *, avlhdr *, int);
static int  load_cpuvm    (kstat_t *, T_VARIABLE *, avlhdr *, int);
static int  load_flushm   (kstat_t *, T_VARIABLE *, avlhdr *, int);
static int  load_cache    (kstat_t *, T_VARIABLE *, avlhdr *, int);
static int  load_nfs_mount(kstat_t *, T_VARIABLE *, avlhdr *, int);

static T_MAP static_kstat_types[] = {
{ KSTAT_TYPE_RAW,   "ks_sysinfo",     { "sysinfo",    0 }, load_sysinfo   },
{ KSTAT_TYPE_RAW,   "ks_vminfo",      { "vminfo",     0 }, load_vminfo    },
{ KSTAT_TYPE_RAW,   "ks_cachefs",     { "cachefs","", 0 }, load_cache     },
{ KSTAT_TYPE_RAW,   "ks_ncstats",     { "ncstats",    0 }, load_ncstats   },
{ KSTAT_TYPE_RAW,   "ks_flushmeter",  { "flushmeter", 0 }, load_flushm    },
{ KSTAT_TYPE_RAW,   "ks_var",         { "var",        0 }, load_var       },
{ KSTAT_TYPE_RAW,   "ks_cpu_sysinfo", { "cpu_stat","",0 }, load_cpusys    },
{ KSTAT_TYPE_RAW,   "ks_cpu_syswait", { "cpu_stat","",0 }, load_cpuwait   },
{ KSTAT_TYPE_RAW,   "ks_cpu_vminfo",  { "cpu_stat","",0 }, load_cpuvm     },
{ KSTAT_TYPE_RAW,   "ks_nfs_mount",   { "nfs", "",    0 }, load_nfs_mount },

{ KSTAT_TYPE_INTR,  "ks_interrupts",  { INTRS,        0 }, 0              },
{ KSTAT_TYPE_IO,    "ks_disks",       { DISKS,        0 }, 0              },
{ 0,                 0,               {0,             0 }, 0              },
};
static avlhdr *kstat_types = 0;

static kstat_ctl_t *kc;
static avlhdr      *kstat_tree;
static int          refresh_count = 0;  /* optimize updates */
static T_VARIABLE   zero_variable;
static T_EXPR       zero_expr;

static void    grow_kstat_tree(void);
static void    grow_kstat_node(char *);
static void    tree_insert(avlhdr *, char *, void *);
static avlhdr *make_struct_tree(T_MAP *, kstat_t *, int);
static int     module_match(kstat_t *, char *[]);
static int     member_length(T_VARIABLE *);
static int     link_count(T_MAP *);

void
se_init_kstat(void)
{
  T_MAP *mp;
  anode *anp;

  if (kc == 0) {
    kc = kstat_open();
    if (kc == 0)
      se_fatal("unable to init kstat: %s", strerror(errno));
    kstat_types = avlinit();
    if (kstat_types == 0)
      se_fatal("unable to grow types tree");
    for(mp=static_kstat_types; mp->m_type_name; mp++)
      if (avlinsert(kstat_types, mp->m_type_name, mp, &anp) == AVL_NOMEM)
        se_fatal("out of types tree node memory");
  }

  if ((Se_kstat_var_count > 0) && (kstat_tree == 0))
    grow_kstat_tree();
}

static void
refresh_kstat_member(T_VARIABLE *vp)
{
  char *name;
  char tmp[sizeof(((kstat_named_t *) 0)->value.c) + 1];
  int number;
  int subscript;
  void *array;
  T_MAP *mp;
  static T_MAP *mp_cache;
  T_REC *rp;
  T_VARIABLE *vvp = 0;
  anode *anp;
  anode *rfp;
  anode *lnp;
  avlhdr *tree;
  kstat_named_t *kn;
  kstat_t *kp;

  /* all kstat variables are structures. period. */
  if (vp->var_parent == 0)
    return;

  name = vp->var_parent->var_struct->st_name;
  if (mp_cache && (strcmp(mp_cache->m_type_name, name) == 0))
    mp = mp_cache;
  else {
    /* hunt this type down from the map */
    anp = avlget(kstat_types, name);
    if (anp == 0) {
      /* Variable declared as kstat type but not found in table.              *
       * Keep the for loop from looping forever by finding number$ and        *
       * giving it a -1.  If there is no number$ member then, well, whatever. */
      if (strcmp(vp->var_name, NUMBER_NAME) == 0)
        vvp = vp;
      else {
        if (vp->var_parent->var_dimension) {
          subscript = se_compute_subscript(vp->var_parent, 1);
          vvp = vp->var_parent;
          vvp = ((T_STRUCT **) vvp->var_un.var_array)[subscript]->st_members;
        } else
          vvp = vp->var_parent->var_un.var_user->st_members;
        for(; vvp; vvp=vvp->var_next)
          if (strcmp(vvp->var_name, NUMBER_NAME) == 0)
            break;
      }
      if (vvp)
        vvp->var_un.var_digit = -1;
      return;
    }
    mp_cache = mp = (T_MAP *) anp->an_data;
  }

  /* if this begger is set, then the info that we want is contained in       *
   * multiple records with these names.  In this case, the names specified   *
   * in m_lookup_name are ks_module names, not the ks_name name.  We'll know *
   * which record to pick by the presense of the member "number".  If        *
   * record number "number" does not exist, "number" is set to -1 and we     *
   * return.  This will allow the program to loop through all the records.   */

  if (mp->m_lookup_name[1] || (*mp->m_lookup_name[0] == '*')) {
    if (strcmp(vp->var_name, NUMBER_NAME) == 0)
      vvp = vp;
    else {
      if (vp->var_parent->var_dimension) {
        subscript = se_compute_subscript(vp->var_parent, 1);
        vvp = vp->var_parent;
        vvp = ((T_STRUCT **) vvp->var_un.var_array)[subscript]->st_members;
      } else
        vvp = vp->var_parent->var_un.var_user->st_members;
      for(; vvp; vvp=vvp->var_next)
        if (strcmp(vvp->var_name, NUMBER_NAME) == 0)
          break;
    }
    if (vvp)
      number = vvp->var_un.var_digit;
    else {
      se_warning("struct %s does not contain a \"number\" member",
        mp->m_type_name);
      number = 0;
    }
  }

  /* get the type/var from the tree */
  anp = avlget(kstat_tree, mp->m_type_name);
  if (anp == 0) {
    grow_kstat_node(mp->m_type_name);
    anp = avlget(kstat_tree, mp->m_type_name);
    if (anp == 0) {
      if (vvp)
        vvp->var_un.var_digit = -1;
      return;
    }
  }

  /* grab the structure tree */
  rp = (T_REC *) anp->an_data;
  if (rp->r_type == R_TREE)
    tree = rp->r_un.r_tree;
  else {
    if ((number >= rp->r_count) || (number < 0)) {
      if (vvp)
        vvp->var_un.var_digit = -1;
      return;
    }
    if (rp->r_un.r_array[number] == 0) {
      /* asking for a instance that doesn't exist */
      if (vvp)
        vvp->var_un.var_digit = -1;
      return;
    }
    tree = rp->r_un.r_array[number];
  }

  /* fill in the variable's value from kstat */
  anp = avlget(tree, vp->var_name);
  if (anp == 0) {
    if (Se_flags & SE_VANISHED) {
      if (strncmp(vp->var_name, "missing", 7) == 0)
        return;
      se_fatal("member: %s vanished!", vp->var_name);
    }
    return;
  }

  /* determine the need for update by the value of refresh_count */
  rfp = avlget(tree, REFRESH_NAME);
  if (rfp == 0)
    se_fatal("refresh_count vanished!");
  if ((long) rfp->an_data != refresh_count) {
    lnp = avlget(tree, LINK_NAME);
    if (lnp == 0)
      se_fatal("link vanished!");
    if (kstat_read(kc, (kstat_t *) lnp->an_data, 0) == -1)
      se_fatal("kstat_read failed: %s", strerror(errno));
    avlinsert(tree, REFRESH_NAME, (void *) (long) refresh_count, &lnp);
    /* will return AVL_THERE, need to manually insert it into the node */
    lnp->an_data = (void *) (long) refresh_count;
  }

  switch(mp->m_type) {
  case KSTAT_TYPE_NAMED:
    /* there are no arrays as structure members in kstat */
    kn = (kstat_named_t *) anp->an_data;
    switch(kn->data_type) {
    case KSTAT_DATA_CHAR:
      if (anp->an_flags[0])
        se_new_string(&vp->var_un.var_string, (char *) kn->value.ul);
      else {
        memcpy(tmp, kn->value.c, sizeof(kn->value.c));
        tmp[sizeof(kn->value.c)] = '\0';
        se_new_string(&vp->var_un.var_string, tmp);
      }
      break;
    case KSTAT_DATA_INT32:
    case KSTAT_DATA_UINT32:
      vp->var_un.var_udigit = kn->value.ui32;
      break;
    case KSTAT_DATA_INT64:
    case KSTAT_DATA_UINT64:
      vp->var_un.var_uldigit = kn->value.ui64;
      break;
#ifdef KSTAT_DATA_STRING
    case KSTAT_DATA_STRING:
      se_new_stringn(&vp->var_un.var_string, KSTAT_NAMED_STR_PTR(kn),
		     KSTAT_NAMED_STR_BUFLEN(kn));
      break;
#endif
    }
    break;
  case KSTAT_TYPE_RAW:
    if (vp->var_subscript) {
      subscript = se_compute_subscript(vp, 1);
      array = vp->var_un.var_array;
      switch(vp->var_type) {
      case VAR_CHAR:
      case VAR_UCHAR:
        ((unsigned char *) array)[subscript] =
          ((unsigned char *) anp->an_data)[subscript];
        break;
      case VAR_SHORT:
      case VAR_USHORT:
        ((unsigned short *) array)[subscript] =
          ((unsigned short *) anp->an_data)[subscript];
        break;
      case VAR_LONG:
      case VAR_ULONG:
        ((unsigned int *) array)[subscript] =
          ((unsigned int *) anp->an_data)[subscript];
        break;
      case VAR_LONGLONG:
      case VAR_ULONGLONG:
        ((T_ULLONG *) array)[subscript] =
          ((T_ULLONG *) anp->an_data)[subscript];
        break;
      case VAR_DOUBLE:
        ((double *) array)[subscript] =
          ((double *) anp->an_data)[subscript];
        break;
      case VAR_STRING:
        se_new_string(((char **) array) + subscript,
                      ((char **) anp->an_data)[subscript]);
        break;
      }
    } else {
      switch(vp->var_type) {
      case VAR_CHAR:
      case VAR_UCHAR:
        vp->var_un.var_udigit = *((unsigned char *) anp->an_data);
        break;
      case VAR_SHORT:
      case VAR_USHORT:
        vp->var_un.var_udigit = *((unsigned short *) anp->an_data);
        break;
      case VAR_LONG:
      case VAR_ULONG:
        vp->var_un.var_udigit = *((unsigned int *) anp->an_data);
        break;
      case VAR_LONGLONG:
      case VAR_ULONGLONG:
        vp->var_un.var_uldigit = *((T_ULLONG *) anp->an_data);
        break;
      case VAR_DOUBLE:
        vp->var_un.var_rdigit = *((double *) anp->an_data);
        break;
      case VAR_STRING:
        se_new_string(&vp->var_un.var_string, (char *) anp->an_data);
        break;
      }
    }
    break;
  case KSTAT_TYPE_INTR:
    if (vp->var_type == VAR_STRING)
      se_new_string(&vp->var_un.var_string, (char *) anp->an_data);
    else
      vp->var_un.var_udigit = *((unsigned int *) anp->an_data);
    break;
  case KSTAT_TYPE_IO:
    /* there are no arrays in kstat_type_io structures */
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      vp->var_un.var_udigit = *((unsigned char *) anp->an_data);
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      vp->var_un.var_udigit = *((unsigned short *) anp->an_data);
      break;
    case VAR_LONG:
    case VAR_ULONG:
      vp->var_un.var_udigit = *((unsigned int *) anp->an_data);
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      vp->var_un.var_uldigit = *((T_ULLONG *) anp->an_data);
      break;
    case VAR_DOUBLE:
      vp->var_un.var_rdigit = *((double *) anp->an_data);
      break;
    case VAR_STRING:
      se_new_string(&vp->var_un.var_string, (char *) anp->an_data);
      break;
    }
    break;
  }
}

void
se_refresh_kstat_variable(T_VARIABLE *vp)
{
  int i;
  T_VARIABLE *vvp;
  T_VARIABLE var;
  T_EXPR expr;

  se_init_kstat();
  for(; (i = kstat_chain_update(kc)) != 0; ) {
    switch (i) {
    case -1:
      se_fatal("kstat_chain_update() failed: %s", strerror(errno));
      break;
    default:
#if I_WANT_TO_SEE_STATE_CHANGES
      puts("<<<<<< STATE CHANGE >>>>>>");
#endif
      /* state change, start over */
      avlfree(kstat_tree);
      kstat_tree = 0;
      grow_kstat_tree();
      break;
    }
  }

  /* kept in each tree.  This eliminates a call to kstat_read() for every *
   * member of the same structure since one will read in all of them.     */

  refresh_count++;

  if (vp->var_type == VAR_USER) {
    for(vvp=vp->var_un.var_user->st_members; vvp; vvp=vvp->var_next) {
      if (vvp->var_dimension) {
        expr = zero_expr;
        expr.e_type = E_VALUE;
        expr.e_variable = &var;
        var = zero_variable;
        var.var_type = VAR_LONG;
        vvp->var_subscript = &expr;
        for(i=0; i<vvp->var_dimension; i++) {
          var.var_un.var_digit = i;
          refresh_kstat_member(vvp);
        }
        vvp->var_subscript = 0;
      } else
        refresh_kstat_member(vvp);
    }
  } else
    refresh_kstat_member(vp);
}

static void
delete_kstat_node(avlhdr *ahp, anode *anp)
{
  int i;
  T_REC *rp = (T_REC *) anp->an_data;

  if (rp == 0)
    return;
  if (rp->r_type == R_TREE)
    avlfree(rp->r_un.r_tree);
  else {
    for(i=0; i<rp->r_count; i++)
      if (rp->r_un.r_array[i])
        avlfree(rp->r_un.r_array[i]);
    se_free(rp->r_un.r_array);
  }
  se_free(rp);
}

static void
delete_raw_node(avlhdr *ahp, anode *anp)
{
  /* only NUMBER_NAME, NAME_NAME and nodes with an_flags[0] turned on */
  if ((strcmp((char *) anp->an_tag, NUMBER_NAME) == 0) ||
      (strcmp((char *) anp->an_tag, NAME_NAME) == 0) || anp->an_flags[0])
    se_free(anp->an_data);
}

static void
delete_named_node(avlhdr *ahp, anode *anp)
{
  /* LINK_NAME and REFRESH_NAME have nothing to be freed.             *
   * NUMBER_NAME, NAME_NAME, and INSTANCE_NAME have constant strings  *
   *   as their an_tag and must not be freed.                         *
   * Then, everything gets its an_data freed.                         */

  /* LINK_NAME and REFRESH_NAME have nothing to be freed */
  if ((strcmp((char *) anp->an_tag, LINK_NAME) == 0) ||
      (strcmp((char *) anp->an_tag, REFRESH_NAME) == 0))
    return;

  /* if it's NAME, then delete the name and the data */
  if (strcmp((char *) anp->an_tag, NAME_NAME) == 0) {
    se_free((void *) ((kstat_named_t *) anp->an_data)->value.ul);
    se_free(anp->an_data);
    return;
  }

  /* if it's NUMBER or INSTANCE, delete the data */
  if ((strcmp((char *) anp->an_tag, NUMBER_NAME) == 0) ||
      (strcmp((char *) anp->an_tag, INSTANCE_NAME) == 0)) {
    se_free(anp->an_data);
    return;
  }

  /* everthing else gets the tag deleted but not the data */
  se_free(anp->an_tag);
}

static void
grow_kstat_tree(void)
{
  /* grow this tree if it isn't there */
  if (kstat_tree == 0) {
    kstat_tree = avlinit();
    if (kstat_tree == 0)
      se_fatal("cannot allocate kstat trees");
    kstat_tree->ah_delete = delete_kstat_node;
  }
}

void
se_add_kstat_type(T_STRUCT *sp)
{
  char *p;
  int i;
  int multiple = 0;
  T_MAP *mp;
  anode *anp;

  /* already declared in static array, kill it and start over */
  se_init_kstat();
  anp = avlget(kstat_types, sp->st_name);
  if (anp)
    avldelete(kstat_types, anp);
  mp = (T_MAP *) se_alloc(sizeof(T_MAP));
  mp->m_type = KSTAT_TYPE_NAMED;
  mp->m_type_name = sp->st_name;
  p = se_string_save(sp->st_kname);
  if (*p == ':') {
    /* kstat_notation */
    char *next_p;
    char *colon;
    ++p;
    for(i=0; i<4; ++i) {
      colon = strchr(p, ':');
      if (colon) {
	*colon = '\0';
	next_p = colon + 1;
      } else {
	next_p = p + strlen(p);
      }
      if (*p == '\0') {
	mp->m_lookup_name[i + PATTERN] = 0;
	mp->m_lookup_name[i] = ":A"; /* match all */
      } else if (*p == '/') {
	/* regular expression */
	char *slash;
	regex_t *re;
	++p;
	slash = strchr(p, '/');
	if (slash)
	  *slash = '\0';
	re = se_alloc(sizeof(regex_t));
	if (regcomp(re, p, REG_EXTENDED | REG_NOSUB) != 0)
	  se_fatal("bad regular expression");
	mp->m_lookup_name[i + PATTERN] = (char *)re;
	mp->m_lookup_name[i] = ":R";
      } else {
	/* gmatch pattern */
	mp->m_lookup_name[i + PATTERN] = p;
	mp->m_lookup_name[i] = ":G";
      }
      p = next_p;
    }
  } else {
    multiple = (strchr(sp->st_kname, ':') != 0);
    for(i=0, p=strtok(p, ":"); p; p=strtok(0, ":"), i++)
      mp->m_lookup_name[i] = p;
    if (multiple)
      mp->m_lookup_name[i] = "";
  }
  mp->m_load_raw = 0;
  if (avlinsert(kstat_types, mp->m_type_name, mp, &anp) == AVL_NOMEM)
    se_fatal("out of kstat type node memory");
}

void
se_add_disk_name(char *name)
{
  char *disks_name = "ks_disks";
  int i;
  anode *anp;
  T_MAP *mp;

  anp = avlget(kstat_types, disks_name);
  if (anp == 0)
    se_fatal("%s vanished!", disks_name);
  mp = (T_MAP *) anp->an_data;
  for(i=0; mp->m_lookup_name[i]; i++)
    ;
  mp->m_lookup_name[i++] = se_string_save(name);
  mp->m_lookup_name[i] = 0;
  grow_kstat_tree();
  anp = avlget(kstat_tree, disks_name);
  if (anp)
    avldelete(kstat_tree, anp);
}

static void
grow_kstat_node(char *type_name)
{
  int i;
  int n;
  int found;
  int module_compare;
  int multiple_count = 0;
  T_MAP *mp;
  T_REC *rp;
  T_REC *mrp = 0;
  anode *anp;
  kstat_t *kp;
  kstat_named_t *kn;

  /* hunt this type down from the map */
  anp = avlget(kstat_types, type_name);
  if (anp) {
    mp = (T_MAP *) anp->an_data;

    /* init */
    mrp = 0;
    found = 0;
    multiple_count = 0;

    module_compare = (mp->m_lookup_name[1] || (*mp->m_lookup_name[0] == '*'));

    /* hunt down the links with this type looking for the record(s) */
    for(kp=kc->kc_chain; kp; kp=kp->ks_next) {

      /* get the right type first */
      if (kp->ks_type != mp->m_type)
        continue;

      /* ok, is it the right link? */
      if (module_compare) {
        if (module_match(kp, mp->m_lookup_name))
          continue;
      } else if (strcmp(kp->ks_name, mp->m_lookup_name[0]))
          continue;

      /* it's what we want. read the actual stuff *
       * but only if isn't the cachefs.0.key link */
      if (kstat_read(kc, kp, 0) == -1)
        if ( ! ((strcmp(kp->ks_module, "cachefs") == 0) &&
                (strcmp(kp->ks_name, "key") == 0)))
          se_fatal("cannot read kstats: %s", strerror(errno));

      /* We may care about the statistics, so check again that it's what we want */
      if (module_compare) {
        if (module_match(kp, mp->m_lookup_name))
          continue;
      }

      /* got it */
      found = 1;

      /* now build the T_REC that is part of the (type_name=TREC*) node */
      if (module_compare) {
        /* see if we already have the node built */
        if (mrp == 0) {
          rp = NEW(T_REC);
          rp->r_ktype = mp->m_type;
          rp->r_type = R_ARRAY;
          n = link_count(mp);
          rp->r_un.r_array = (avlhdr **) se_alloc(n * sizeof(avlhdr *));
          mrp = rp;
        } else
          rp = mrp;
        rp->r_un.r_array[multiple_count] =
          make_struct_tree(mp, kp, multiple_count);
        if (rp->r_un.r_array[multiple_count])
          multiple_count++;
      } else {
        /* build a tree from this structure */
        rp = NEW(T_REC);
        rp->r_ktype = mp->m_type;
        rp->r_type = R_TREE;
        rp->r_un.r_tree = make_struct_tree(mp, kp, 0);
      }
      if (module_compare == 0)
        /* found the quantity-one item, break */
        break;
    }
    if (found) {
      /* how many of these do we have */
      if (module_compare)
        rp->r_count = multiple_count;

      /* insert a (type_name=TREC*) node */
      switch(avlinsert(kstat_tree, mp->m_type_name, rp, &anp)) {
      case AVL_INSERT:
        break;
      case AVL_THERE:
        se_fatal("duplicate structures");
        break;
      case AVL_NOMEM:
        se_fatal("cannot allocate node");
        break;
      }
    }
  }
}

static int *
int_save(int number)
{
  int *ip;

  ip = (int *) se_alloc(sizeof(int));
  *ip = number;
  return ip;
}

static int
load_sysinfo(kstat_t *kp, T_VARIABLE *vp, avlhdr *tree, int number)
{
  sysinfo_t *si;

  /* load the members */
  si = (sysinfo_t *) kp->ks_data;
  tree_insert(tree, vp->var_name, &si->updates);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &si->runque);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &si->runocc);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &si->swpque);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &si->swpocc);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &si->waiting);
  return 1;
}

static int
load_vminfo(kstat_t *kp, T_VARIABLE *vp, avlhdr *tree, int number)
{
  vminfo_t *vi;

  /* load the members */
  vi = (vminfo_t *) kp->ks_data;
  tree_insert(tree, vp->var_name, &vi->freemem);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vi->swap_resv);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vi->swap_alloc);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vi->swap_avail);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vi->swap_free);
  return 1;
}

static int
load_ncstats(kstat_t *kp, T_VARIABLE *vp, avlhdr *tree, int number)
{
  ncstats_t *ns;

  /* load the members */
  ns = (ncstats_t *) kp->ks_data;
  tree_insert(tree, vp->var_name, &ns->hits);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &ns->misses);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &ns->enters);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &ns->dbl_enters);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &ns->long_enter);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &ns->long_look);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &ns->move_to_front);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &ns->purges);
  return 1;
}

static int
load_var(kstat_t *kp, T_VARIABLE *vp, avlhdr *tree, int number)
{
  var_t *vs;

  /* load the members */
  vs = (var_t *) kp->ks_data;
  tree_insert(tree, vp->var_name, &vs->v_buf);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vs->v_call);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vs->v_proc);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vs->v_maxupttl);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vs->v_nglobpris);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vs->v_maxsyspri);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vs->v_clist);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vs->v_maxup);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vs->v_hbuf);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vs->v_hmask);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vs->v_pbuf);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vs->v_sptmap);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vs->v_maxpmem);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vs->v_autoup);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &vs->v_bufhwm);
  return 1;
}

static int
load_cpusys(kstat_t *kp, T_VARIABLE *vp, avlhdr *tree, int number)
{
  cpu_stat_t *cst;
  cpu_sysinfo_t *cs;

  /* skip past number, name and instance */
  vp = vp->var_next->var_next->var_next;

  /* load the members */
  cst = (cpu_stat_t *) kp->ks_data;
  cs = &cst->cpu_sysinfo;
  tree_insert(tree, vp->var_name, cs->cpu);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, cs->wait);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->bread);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->bwrite);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->lread);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->lwrite);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->phread);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->phwrite);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->pswitch);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->trap);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->intr);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->syscall);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->sysread);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->syswrite);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->sysfork);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->sysvfork);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->sysexec);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->readch);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->writech);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->rcvint);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->xmtint);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->mdmint);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->rawch);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->canch);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->outch);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->msg);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->sema);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->namei);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->ufsiget);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->ufsdirblk);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->ufsipage);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->ufsinopage);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->inodeovf);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->fileovf);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->procovf);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->intrthread);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->intrblk);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->idlethread);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->inv_swtch);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->nthreads);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->cpumigrate);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->xcalls);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->mutex_adenters);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->rw_rdfails);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->rw_wrfails);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->modload);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->modunload);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->bawrite);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->rw_enters);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->win_uo_cnt);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->win_uu_cnt);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->win_so_cnt);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->win_su_cnt);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cs->win_suo_cnt);
  return 1;
}

static int
load_cpuwait(kstat_t *kp, T_VARIABLE *vp, avlhdr *tree, int number)
{
  cpu_stat_t *cst;
  cpu_syswait_t *cw;

  /* skip past number, name and instance */
  vp = vp->var_next->var_next->var_next;

  /* load the members */
  cst = (cpu_stat_t *) kp->ks_data;
  cw = &cst->cpu_syswait;

  /* load the members */
  tree_insert(tree, vp->var_name, &cw->iowait);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cw->swap);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cw->physio);
  return 1;
}

static int
load_cpuvm(kstat_t *kp, T_VARIABLE *vp, avlhdr *tree, int number)
{
  cpu_stat_t *cst;
  cpu_vminfo_t *cv;

  /* skip past number, name and instance */
  vp = vp->var_next->var_next->var_next;

  /* load the members */
  cst = (cpu_stat_t *) kp->ks_data;
  cv = &cst->cpu_vminfo;

  /* load the members */
  tree_insert(tree, vp->var_name, &cv->pgrec);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->pgfrec);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->pgin);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->pgpgin);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->pgout);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->pgpgout);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->swapin);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->pgswapin);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->swapout);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->pgswapout);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->zfod);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->dfree);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->scan);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->rev);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->hat_fault);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->as_fault);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->maj_fault);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->cow_fault);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->prot_fault);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->softlock);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->kernel_asflt);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->pgrrun);
#ifdef HAVE_CPU_VMINFO_T_EXECPGIN
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->execpgin);
#endif
#ifdef HAVE_CPU_VMINFO_T_EXECPGOUT
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->execpgout);
#endif
#ifdef HAVE_CPU_VMINFO_T_EXECFREE
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->execfree);
#endif
#ifdef HAVE_CPU_VMINFO_T_ANONPGIN
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->anonpgin);
#endif
#ifdef HAVE_CPU_VMINFO_T_ANONPGOUT
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->anonpgout);
#endif
#ifdef HAVE_CPU_VMINFO_T_ANONFREE
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->anonfree);
#endif
#ifdef HAVE_CPU_VMINFO_T_FSPGIN
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->fspgin);
#endif
#ifdef HAVE_CPU_VMINFO_T_FSPGOUT
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->fspgout);
#endif
#ifdef HAVE_CPU_VMINFO_T_FSFREE
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &cv->fsfree);
#endif
  return 1;
}

static int
load_flushm(kstat_t *kp, T_VARIABLE *vp, avlhdr *tree, int number)
{
  flushmeter_t *fp;

  /* load the members */
  fp = (flushmeter_t *) kp->ks_data;

  tree_insert(tree, vp->var_name, &fp->f_ctx);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &fp->f_segment);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &fp->f_page);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &fp->f_partial);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &fp->f_usr);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &fp->f_region);
  return 1;
}

static int
load_cache(kstat_t *kp, T_VARIABLE *vp, avlhdr *tree, int number)
{
  char *p;
  char name[128];
  anode *anp;
  kstat_t *xp;
  cachefs_key_t *ck;
  cachefs_stats_t *cs;
  static cachefs_key_t *ck_head;

  if (strcmp(kp->ks_name, "key") == 0) {
    ck_head = (cachefs_key_t *) kp->ks_data;
    return 0;
  } else if (strcmp(kp->ks_name, "log") == 0) {
    return 0;
  } else if (strcmp(kp->ks_name, "stats") == 0) {
    if (ck_head == 0) {
      for(xp=kc->kc_chain; xp; xp=xp->ks_next) {
        if (xp->ks_type != KSTAT_TYPE_RAW)
          continue;
        if (strcmp(xp->ks_module, kp->ks_module))
          continue;
        if (strcmp(xp->ks_name, "key"))
          continue;
        break;
      }
      if (xp == 0)
        se_fatal("cachefs.0.key vanished!");
      ck_head = (cachefs_key_t *) xp->ks_data;
    }
    snprintf(name, sizeof name, "cachefs%d", kp->ks_instance);
    switch(avlinsert(tree, NAME_NAME, name, &anp)) {
    case AVL_INSERT:
      break;
    case AVL_THERE:
      se_new_string((char **) &anp->an_data, name);
      break;
    case AVL_NOMEM:
      se_fatal("cannot allocate node");
      break;
    }
    p = (char *) ck_head;
    ck = ck_head + (kp->ks_instance - 1);
    cs = (cachefs_stats_t *) kp->ks_data;

    /* skip past number, name and instance */
    vp = vp->var_next->var_next->var_next;
    tree_insert(tree, vp->var_name, se_string_save(p + ck->ck_mp_index));

    /* flag this as needing to be se_free()ed */
    anp = avlget(tree, vp->var_name);
    anp->an_flags[0] = 1;

    vp = vp->var_next;
    tree_insert(tree, vp->var_name, se_string_save(p + ck->ck_bf_index));

    /* flag this as needing to be se_free()ed */
    anp = avlget(tree, vp->var_name);
    anp->an_flags[0] = 1;

    vp = vp->var_next;
    tree_insert(tree, vp->var_name, se_string_save(p + ck->ck_cd_index));

    /* flag this as needing to be se_free()ed */
    anp = avlget(tree, vp->var_name);
    anp->an_flags[0] = 1;

    vp = vp->var_next;
    tree_insert(tree, vp->var_name, se_string_save(p + ck->ck_ci_index));

    /* flag this as needing to be se_free()ed */
    anp = avlget(tree, vp->var_name);
    anp->an_flags[0] = 1;

    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &cs->st_hits);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &cs->st_misses);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &cs->st_passes);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &cs->st_fails);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &cs->st_modifies);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &cs->st_gc_count);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &cs->st_gc_time);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &cs->st_gc_before_atime);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &cs->st_gc_after_atime);

    return 1;
  }
}

static int
load_nfs_mount(kstat_t *kp, T_VARIABLE *vp, avlhdr *tree, int number)
{
  struct mntinfo_kstat *mp;

  /* skip past number, name and instance */
  vp = vp->var_next->var_next->var_next;

  /* load the members */
  mp = (struct mntinfo_kstat *) kp->ks_data;

  tree_insert(tree, vp->var_name, mp->mik_proto);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_vers);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_flags);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_secmod);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_curread);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_curwrite);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_retrans);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_timers[0].srtt);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_timers[0].deviate);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_timers[0].rtxcur);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_timers[1].srtt);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_timers[1].deviate);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_timers[1].rtxcur);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_timers[2].srtt);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_timers[2].deviate);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_timers[2].rtxcur);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_timers[3].srtt);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_timers[3].deviate);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_timers[3].rtxcur);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_noresponse);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_failover);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, &mp->mik_remap);
  vp = vp->var_next;
  tree_insert(tree, vp->var_name, mp->mik_curserver);
  return 1;
}

static avlhdr *
make_struct_tree(T_MAP *mp, kstat_t *kp, int number)
{
  char *p;
  char tmp[BUFSIZ];
  int i;
  int j;
  avlhdr *tree;
  anode *anp;
  kstat_named_t *kn;
  kstat_intr_t *ki;
  kstat_io_t *kio;
  T_STRUCT *sp;
  T_VARIABLE *vp;

  /* verify that the structure is what we think it is */
  sp = se_get_struct(mp->m_type_name);
  if (sp == 0)
#if I_CARE_IF_I_CANT_FIND_THE_STRUCT
    se_fatal("cannot find struct %s", mp->m_type_name);
#else
    return 0;
#endif

  tree = avlinit();
  if (tree == 0)
    se_fatal("cannot allocate kstat trees");

  /* for kstat_read()ing in refresh_kstat_member() */
  tree_insert(tree, LINK_NAME, kp);
  tree_insert(tree, REFRESH_NAME, 0);

  vp = sp->st_members;

  switch(mp->m_type) {
  case KSTAT_TYPE_RAW:
    tree->ah_delete = delete_raw_node;

    /* load the name and number */
    tree_insert(tree, NUMBER_NAME, int_save(number));
    tree_insert(tree, NAME_NAME, se_string_save(kp->ks_name));
    tree_insert(tree, INSTANCE_NAME, &kp->ks_instance);

    if ((*mp->m_load_raw)(kp, vp, tree, number) == 0) {
      avlfree(tree);
      return 0;
    }
    break;
  case KSTAT_TYPE_NAMED:
    tree->ah_delete = delete_named_node;

    /* load the name and number */
    kn = NEW(kstat_named_t);
    kn->data_type = KSTAT_DATA_INT32;
    kn->value.i32 = number;
    tree_insert(tree, NUMBER_NAME, kn);

    kn = NEW(kstat_named_t);
    kn->data_type = KSTAT_DATA_CHAR;
    kn->value.ul = (ulong_t) se_string_save(kp->ks_name);
    tree_insert(tree, NAME_NAME, kn);

    /* mark this node as having a string_saved'ed string, not a kstat *
     * array of characters.                                           */
    anp = avlget(tree, NAME_NAME);
    anp->an_flags[0] = 1;

    kn = NEW(kstat_named_t);
    kn->data_type = KSTAT_DATA_INT32;
    kn->value.i32 = kp->ks_instance;
    tree_insert(tree, INSTANCE_NAME, kn);

    /* insert all the structure members into the tree */
    for(i=0, kn=(kstat_named_t *) kp->ks_data; i<kp->ks_ndata; kn++, i++) {
      if ((kn->name == 0) || (kn->name[0] == '\0'))
        continue;
      if (se_get_keyword(kn->name))
        snprintf(tmp, sizeof tmp, "SYM_%s", kn->name);
      else {
        strcpy(tmp, kn->name);
        se_cleanup_tok_syms(tmp);
      }
      p = se_string_save(tmp);
      tree_insert(tree, p, kn);
    }
    break;
  case KSTAT_TYPE_INTR:
    /* de-allocation is the same as the raw nodes */
    tree->ah_delete = delete_raw_node;

    if (kp->ks_ndata > 1)
      se_fatal("time to fix the (ks_ndata > 1) problem");
    ki = (kstat_intr_t *) kp->ks_data;

    /* add the instance number */
    tree_insert(tree, NUMBER_NAME, int_save(number));
    vp = vp->var_next;

    /* add the name */
    tree_insert(tree, NAME_NAME, se_string_save(kp->ks_name));
    vp = vp->var_next;

    /* the instance number */
    tree_insert(tree, INSTANCE_NAME, &kp->ks_instance);
    vp = vp->var_next;

    for(i=0; i<KSTAT_NUM_INTRS && vp; i++, vp=vp->var_next)
      tree_insert(tree, vp->var_name, &ki->intrs[i]);
    break;
  case KSTAT_TYPE_IO:
    /* de-allocation is the same as the raw nodes */
    tree->ah_delete = delete_raw_node;

    if (kp->ks_ndata > 1)
      se_fatal("time to fix the (ks_ndata > 1) problem");
    kio = (kstat_io_t *) kp->ks_data;

    /* add the instance number */
    tree_insert(tree, NUMBER_NAME, int_save(number));
    vp = vp->var_next;

    /* add the name */
    tree_insert(tree, NAME_NAME, se_string_save(kp->ks_name));
    vp = vp->var_next;

    /* the instance number */
    tree_insert(tree, INSTANCE_NAME, &kp->ks_instance);
    vp = vp->var_next;

    /* the type of the member is kept in the user definition */
    tree_insert(tree, vp->var_name, &kio->nread);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &kio->nwritten);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &kio->reads);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &kio->writes);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &kio->wtime);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &kio->wlentime);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &kio->wlastupdate);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &kio->rtime);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &kio->rlentime);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &kio->rlastupdate);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &kio->wcnt);
    vp = vp->var_next;
    tree_insert(tree, vp->var_name, &kio->rcnt);
    break;
  default:
    se_fatal("type not found: %d", mp->m_type);
    break;
  }
  return tree;
}

static void
tree_insert(avlhdr *tree, char *tag, void *data)
{
  anode *anp;

  switch(avlinsert(tree, tag, data, &anp)) {
  case AVL_INSERT:
    break;
  case AVL_THERE:
    se_fatal("duplicate structure member: %s", tag);
    break;
  case AVL_NOMEM:
    se_fatal("cannot allocate node");
    break;
  }
}

static int
link_count(T_MAP *mp)
{
  int count = 0;
  kstat_t *kp;

  for(kp=kc->kc_chain; kp; kp=kp->ks_next)
    if ((kp->ks_type == mp->m_type) &&
        (module_match(kp, mp->m_lookup_name) == 0))
      count++;
  return count;
}

static void
chain_debug()
{
  kstat_t *kp;

  for(kp=kc->kc_chain; kp; kp=kp->ks_next)
    printf("kp      = 0x%x\nks_next = 0x%x\n", kp, kp->ks_next);
}

static int
module_match(kstat_t *kp, char *names[])
{
  if (names[0] && *names[0] != ':') {
    char **pp;

    for(pp=names; *pp && **pp; pp++) {
      if (**pp == '*') {
	if (strncmp(kp->ks_name, *pp + 1, strlen(*pp + 1)) == 0)
	  return 0;
      } else if (strcmp(kp->ks_module, *pp) == 0)
	return 0;
    }
  } else {
    /* kstat notation */

    int i;
    kstat_named_t *kn;

    /* module */
    if (names[MODULE][1] == 'R') {
      if (regexec((regex_t *)names[MODULE + PATTERN], kp->ks_module, 0, 0, 0) != 0)
	return 1;
    } else if (names[MODULE][1] == 'G') {
      if (gmatch(kp->ks_module, names[MODULE + PATTERN]) == 0)
	return 1;
    }

    /* instance */
    if (names[INSTANCE][1] != 'A') {
      char instance[20];
      int len;
      len = snprintf(instance, sizeof(instance), "%d", kp->ks_instance);
      if (len >= sizeof(instance))
        se_fatal("Instance too big");
      if (names[INSTANCE][1] == 'R') {
	if (regexec((regex_t *)names[INSTANCE + PATTERN], instance, 0, 0, 0) != 0)
	  return 1;
      } else if (names[INSTANCE][1] == 'G') {
	if (gmatch(instance, names[INSTANCE + PATTERN]) == 0)
	  return 1;
      }
    }

    /* name */
    if (names[NAME][1] == 'R') {
      if (regexec((regex_t *)names[NAME + PATTERN], kp->ks_name, 0, 0, 0) != 0)
	return 1;
    } else if (names[NAME][1] == 'G') {
      if (gmatch(kp->ks_name, names[NAME + PATTERN]) == 0)
	return 1;
    }

    /* statistic */
    if (kp->ks_type != KSTAT_TYPE_NAMED)
      return 0;

    for(i=0, kn=KSTAT_NAMED_PTR(kp); i<kp->ks_ndata; kn++, i++) {
      /* if no data yet assume a match, will do full check when data read */
      if (kn == 0)
	return 0;

      if (names[STATISTIC][1] == 'R') {
        if (regexec((regex_t *)names[STATISTIC + PATTERN], kn->name, 0, 0, 0) == 0)
	  return 0;
      } else if (names[STATISTIC][1] == 'G') {
	if (gmatch(kn->name, names[STATISTIC + PATTERN]) != 0)
	  return 0;
      } else
	return 0;
    }
  }
  return 1;
}

static int
member_length(T_VARIABLE *vp)
{
  int count = 0;
  T_VARIABLE *vvp;

  for(vvp=vp; vvp; vvp=vvp->var_next)
    count++;
  return count;
}

void
se_end_kstat(void)
{
  if (kc)
    kstat_close(kc);
}

static void
update_kstat_member(T_VARIABLE *vp)
{
  char *name;
  int number;
  int subscript;
  void *array;
  T_MAP *mp;
  static T_MAP *mp_cache;
  T_REC *rp;
  T_VARIABLE *vvp = 0;
  anode *anp;
  avlhdr *tree;
  kstat_named_t *kn;
  kstat_t *kp;

  /* don't try to kstat_write() the magic members */
  if ((strcmp(vp->var_name, NAME_NAME) == 0) ||
      (strcmp(vp->var_name, NUMBER_NAME) == 0) ||
      (strcmp(vp->var_name, INSTANCE_NAME) == 0))
    return;

  /* all kstat variables are structures. period. */
  if (vp->var_parent == 0)
    return;

  name = vp->var_parent->var_struct->st_name;
  if (mp_cache && (strcmp(mp_cache->m_type_name, name) == 0))
    mp = mp_cache;
  else {
    /* hunt this type down from the map */
    name = vp->var_parent->var_struct->st_name;
    anp = avlget(kstat_types, name);
    if (anp == 0) {
      /* Variable declared as kstat type but not found in table.              *
       * Keep the for loop from looping forever by finding number$ and        *
       * giving it a -1.  If there is no number$ member then, well, whatever. */
      if (strcmp(vp->var_name, NUMBER_NAME) == 0)
        vvp = vp;
      else {
        if (vp->var_parent->var_dimension) {
          subscript = se_compute_subscript(vp->var_parent, 1);
          vvp = vp->var_parent;
          vvp = ((T_STRUCT **) vvp->var_un.var_array)[subscript]->st_members;
        } else
          vvp = vp->var_parent->var_un.var_user->st_members;
        for(; vvp; vvp=vvp->var_next)
          if (strcmp(vvp->var_name, NUMBER_NAME) == 0)
            break;
      }
      if (vvp)
        vvp->var_un.var_digit = -1;
      return;
    }
    mp_cache = mp = (T_MAP *) anp->an_data;
  }

  /* if this begger is set, then the info that we want is contained in       *
   * multiple records with these names.  In this case, the names specified   *
   * in m_lookup_name are ks_module names, not the ks_name name.  We'll know *
   * which record to pick by the presense of the member "number".  If        *
   * record number "number" does not exist, "number" is set to -1 and we     *
   * return.  This will allow the program to loop through all the records.   */

  if (mp->m_lookup_name[1] || (*mp->m_lookup_name[0] == '*')) {
    if (strcmp(vp->var_name, NUMBER_NAME) == 0)
      vvp = vp;
    else {
      if (vp->var_parent->var_dimension) {
        subscript = se_compute_subscript(vp->var_parent, 1);
        vvp = vp->var_parent;
        vvp = ((T_STRUCT **) vvp->var_un.var_array)[subscript]->st_members;
      } else
        vvp = vp->var_parent->var_un.var_user->st_members;
      for(; vvp; vvp=vvp->var_next)
        if (strcmp(vvp->var_name, NUMBER_NAME) == 0)
          break;
    }
    if (vvp)
      number = vvp->var_un.var_digit;
    else {
      se_warning("struct %s does not contain a \"number\" member",
        mp->m_type_name);
      number = 0;
    }
  }

  /* get the type/var from the tree */
  anp = avlget(kstat_tree, mp->m_type_name);
  if (anp == 0) {
    grow_kstat_node(mp->m_type_name);
    anp = avlget(kstat_tree, mp->m_type_name);
    if (anp == 0) {
      if (vvp)
        vvp->var_un.var_digit = -1;
      return;
    }
  }

  /* grab the structure tree */
  rp = (T_REC *) anp->an_data;
  if (rp->r_type == R_TREE)
    tree = rp->r_un.r_tree;
  else {
    if (number >= rp->r_count) {
      if (vvp)
        vvp->var_un.var_digit = -1;
      return;
    }
    if (rp->r_un.r_array[number] == 0) {
      /* asking for a instance that doesn't exist */
      if (vvp)
        vvp->var_un.var_digit = -1;
      return;
    }
    tree = rp->r_un.r_array[number];
  }

  /* fill in the variable's value from kstat */
  anp = avlget(tree, vp->var_name);
  if (anp == 0) {
#if WISHES_WERE_HORSES
    /* bugs in x86 */
    if (strncmp(vp->var_name, "missing", 7) == 0)
      return;
    se_fatal("member: %s vanished!", vp->var_name);
#else
    return;
#endif
  }

  switch(mp->m_type) {
  case KSTAT_TYPE_NAMED:
    kn = (kstat_named_t *) anp->an_data;
    switch(kn->data_type) {
    case KSTAT_DATA_CHAR:
      if (vp->var_un.var_string)
        strncpy(kn->value.c, vp->var_un.var_string, sizeof kn->value.c);
      break;
    case KSTAT_DATA_INT32:
    case KSTAT_DATA_UINT32:
      kn->value.ui32 = vp->var_un.var_udigit;
      break;
    case KSTAT_DATA_INT64:
    case KSTAT_DATA_UINT64:
      kn->value.ui64 = vp->var_un.var_uldigit;
      break;
#ifdef KSTAT_DATA_STRING
    case KSTAT_DATA_STRING:
      KSTAT_NAMED_STR_PTR(kn) = vp->var_un.var_string;
      KSTAT_NAMED_STR_BUFLEN(kn) = strlen(vp->var_un.var_string) + 1;
#endif
    }
    break;
  case KSTAT_TYPE_RAW:
    if (vp->var_subscript) {
      subscript = se_compute_subscript(vp, 1);
      array = vp->var_un.var_array;
      switch(vp->var_type) {
      case VAR_CHAR:
      case VAR_UCHAR:
        ((unsigned char *) anp->an_data)[subscript] =
          ((unsigned char *) array)[subscript];
        break;
      case VAR_SHORT:
      case VAR_USHORT:
        ((unsigned short *) anp->an_data)[subscript] =
          ((unsigned short *) array)[subscript];
        break;
      case VAR_LONG:
      case VAR_ULONG:
        ((unsigned int *) anp->an_data)[subscript] =
          ((unsigned int *) array)[subscript];
        break;
      case VAR_LONGLONG:
      case VAR_ULONGLONG:
        ((T_ULLONG *) anp->an_data)[subscript] =
          ((T_ULLONG *) array)[subscript];
        break;
      case VAR_DOUBLE:
        ((double *) anp->an_data)[subscript] =
          ((double *) array)[subscript];
        break;
      case VAR_STRING:
        ((char **) anp->an_data)[subscript] =
          ((char **) array)[subscript];
        break;
      }
    } else {
      switch(vp->var_type) {
      case VAR_CHAR:
      case VAR_UCHAR:
        *((unsigned char *) anp->an_data) = vp->var_un.var_udigit;
        break;
      case VAR_SHORT:
      case VAR_USHORT:
        *((unsigned short *) anp->an_data) = vp->var_un.var_udigit;
        break;
      case VAR_LONG:
      case VAR_ULONG:
        *((unsigned int *) anp->an_data) = vp->var_un.var_udigit;
        break;
      case VAR_LONGLONG:
      case VAR_ULONGLONG:
        *((T_ULLONG *) anp->an_data) = vp->var_un.var_uldigit;
        break;
      case VAR_DOUBLE:
        *((double *) anp->an_data) = vp->var_un.var_rdigit;
        break;
      case VAR_STRING:
        anp->an_data = vp->var_un.var_string;
        break;
      }
    }
    break;
  case KSTAT_TYPE_INTR:
    if (vp->var_type == VAR_STRING)
      /* only the name$ member */
      anp->an_data = vp->var_un.var_string;
    else
      *((unsigned int *) anp->an_data) = vp->var_un.var_udigit;
    break;
  case KSTAT_TYPE_IO:
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      *((unsigned char *) anp->an_data) = vp->var_un.var_udigit;
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      *((unsigned short *) anp->an_data) = vp->var_un.var_udigit;
      break;
    case VAR_LONG:
    case VAR_ULONG:
      *((unsigned int *) anp->an_data) = vp->var_un.var_udigit;
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      *((T_ULLONG *) anp->an_data) = vp->var_un.var_uldigit;
      break;
    case VAR_DOUBLE:
      *((double *) anp->an_data) = vp->var_un.var_rdigit;
      break;
    case VAR_STRING:
      anp->an_data = vp->var_un.var_string;
      break;
    }
    break;
  }
  anp = avlget(tree, LINK_NAME);
  if (anp == 0)
    se_fatal("link vanished!");
  if (kstat_write(kc, (kstat_t *) anp->an_data, 0) == -1)
    se_fatal("cannot modify: %s", vp->var_name);
}

void
se_update_kstat_variable(T_VARIABLE *vp)
{
  int i;
  T_VARIABLE *vvp;
  T_VARIABLE var;
  T_EXPR expr;

  se_init_kstat();
  if (vp->var_type == VAR_USER) {
    for(vvp=vp->var_un.var_user->st_members; vvp; vvp=vvp->var_next) {
      if (vvp->var_dimension) {
        expr = zero_expr;
        expr.e_type = E_VALUE;
        expr.e_variable = &var;
        var = zero_variable;
        var.var_type = VAR_LONG;
        vvp->var_subscript = &expr;
        for(i=0; i<vvp->var_dimension; i++) {
          var.var_un.var_digit = i;
          update_kstat_member(vvp);
        }
        vvp->var_subscript = 0;
      } else
        update_kstat_member(vvp);
    }
  } else
    update_kstat_member(vp);
}

static int
count_names(char *names, char *name_vec[])
{
  char *p;
  int count = 0;

  for(p=strtok(names, ":"); p; p=strtok((char *) 0, ":"))
    name_vec[count++] = p;
  name_vec[count] = 0;
  return count;
}

static int
name_matches(kstat_t *kp, char *name_vec[])
{
  char **pp;

  for(pp=name_vec; *pp; pp++) {
    if (**pp == '*') {
      if (strncmp(kp->ks_name, *pp+1, strlen(*pp+1)) == 0)
        return 1;
    } else if (strcmp(kp->ks_module, *pp) == 0)
      return 1;
  }
  return 0;
}
