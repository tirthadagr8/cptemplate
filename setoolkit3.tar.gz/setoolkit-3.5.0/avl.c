/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/*
 *      NAME:           avl.c
 *      AUTHOR:         James L. Macropol
 *      DESCRIPTION:    AVL tree manipulation routines.
 *
 *      PORTED TO ANSI C:  Richard L. Pettit, Jr.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avl.h"

#define MAXLEVEL 200  /* Maximum depth for node visitors */
#define ANALL    100  /* Number of anode's allocated at a crack */

#define BAL(x)          ((x)+2) /* Unsigned balance factor */
#define AVLNFREE(anp)   (((anp)->an_next = Avlfree), (Avlfree = (anp)))

static void   avlbalance(avlhdr *ahp, anode *anp, int add);
static anode *avlnode(void);

static anode *Avlfree = NULL;

/*+
 * avlget
 *
 *      Fetch a pointer to the given header tag value.
 *
 *      anp = avlget(ahp, tag)
 *
 *      anode   *anp;           Returned pointer to the node whose key is <tag>
 *                              NULL is returned if there is no such node.
 *      avlhdr  *ahp;           Ptr to the tree header to search.
 *      void    *tag;           Key to look for.
-*/

anode *
avlget(avlhdr *ahp, void *tag)
{
    register anode *anp;
    register int way;

    anp = ahp->ah_top;
    while (anp) {
        switch((unsigned long) ahp->ah_cmp) {
        case (unsigned long) AVC_NONE:
            way = *((char *) tag) - *((char *) anp->an_tag);
            if (way == 0)
                way = strcmp((char *) tag, (char *) anp->an_tag);
            break;
        case (unsigned long) AVC_INT:
            way = (unsigned long) tag - (unsigned long) anp->an_tag;
            break;
        default:
            way = (*ahp->ah_cmp)(tag, anp->an_tag);
            break;
        }

        if (way == 0)
            return anp;
        if (way < 0)
            anp = anp->an_left;
        else
            anp = anp->an_right;
    }
    return NULL;
}

/*+
 * avlinsert
 *
 *      This routine does a tree insertion.
 *
 *      retcode = avlinsert(ahp, tag, data, anpp)
 *
 *      AvlInsVal retcode;      Enum return code that may take one of the
 *                              following values:
 *                                      AVL_THERE       Node already existed
 *                                                      in the tree.  Ptr to
 *                                                      it was returned into
 *                                                      *anpp.
 *                                      AVL_NOMEM       Could not allocate
 *                                                      another anode.
 *                                      AVL_INSERT      Node inserted.  Ptr
 *                                                      to it returned into
 *                                                      *anpp.
 *      void    *tag;           Ptr to tag (key) of record to insert.
 *      void    *data;          Ptr to data value.  In actuality, avlinsert()
 *                              does very little with this, and only copies
 *                              it to the an_data field if a node is inserted.
 *      anode   **anpp;         Ptr to where avlinsert() will save a pointer
 *                              to the inserted (or already existing) node with
 *                              the proper key value.  If this pointer is
 *                              passed as NULL, then the the pointer will not
 *                              be saved.
-*/

AvlInsVal
avlinsert(avlhdr *ahp, void *tag, void *data, anode **anpp)
{
    register anode *anp;       /* New node or node in search */
    register anode *oldanp;    /* previous node in search */
    register int way;          /* return from compare */

    /* If we have more tree to search, then search it. We   *
     * first compare against the tag at this node.  If no   *
     * cigar, then descend down into the depths of the left *
     * or right subtree, as appropriate.  If we do find a   *
     * match, then we can put our data into it.             */

    for (anp = ahp->ah_top, oldanp = NULL; anp; ) {
        oldanp = anp;
        switch((unsigned long) ahp->ah_cmp) {
        case (unsigned long) AVC_NONE:
            way = *((char *) tag) - *((char *) anp->an_tag);
            if (way == 0)
                way = strcmp((char *) tag, (char *) anp->an_tag);
            break;
        case (unsigned long) AVC_INT:
            way = (unsigned long) tag - (unsigned long) anp->an_tag;
            break;
        default:
            way = (*ahp->ah_cmp)(tag, anp->an_tag);
            break;
        }

        if (way < 0)
            anp = anp->an_left;
        else if (way > 0)
            anp = anp->an_right;
        else {
            if (anpp)
                *anpp = anp;
            return AVL_THERE;
        }
    }

    /* Did not find the tag in the present tree.  We must build a   *
     * new node and insert it here.                                 */

    anp = avlnode();
    if (anp == NULL)
        return AVL_NOMEM;

    anp->an_tag = tag;
    anp->an_data = data;

    if (oldanp == NULL)
        ahp->ah_top = anp;
    else if (way < 0) {
        oldanp->an_left = anp;
        oldanp->an_balance--;
    } else {
        oldanp->an_right = anp;
        oldanp->an_balance++;
    }
    anp->an_up = oldanp;

    if (oldanp && (oldanp->an_balance != BAL(0)))
        avlbalance(ahp, oldanp, 1);
    switch (ahp->ah_debug) {
    case AVD_DMP:
        printf("\n\n*********\n\nAfter inserting\n");
        if (ahp->ah_print)
            (void) avldepth(ahp, ahp->ah_print, NULL);
        /* Fall through */
    case AVD_CHK:
        (void) avlcheck(ahp, ahp->ah_top, NULL);
        break;
    }
    if (anpp)
        *anpp = anp;
    return AVL_INSERT;
}

/*+
 * avldelete
 *
 *      Delete the given node.
 *
 *      avldelete (ahp, anp)
 *
 *      avlhdr  *ahp;           Ptr to tree header.
 *      anode   *anp;           Ptr to node to delete.
-*/

void
avldelete(avlhdr *ahp, anode *anp)
{
    register anode *qanp;  /* Where to start rebalancing */
    register anode *panp;  /* Parent of node to delete */
    register anode *canp;  /* Who to rotate */
    int adj;               /* Flag adjustments to panp's balance */

    if (anp == NULL)
        return;

    /* panp is the parent node.  It may not exist if this is the    *
     * top node of the tree.  qanp is where we will start to do the *
     * rebalancing act for the tree.  adj is to flag any adjustment *
     * to panp's balance.  If a rotation must occur just to get the *
     * delete done (much less keep the tree balanced), qanp and adj *
     * will be changed.                                             */

    panp = anp->an_up;
    qanp = panp;
    canp = NULL;
    adj = 1;

    /* This is a simple case if either the left or right subtree    *
     * are missing.  Just substitute the other subtree.             */

    if (anp->an_left == NULL)
        canp = anp->an_right;
    else if (anp->an_right == NULL)
        canp = anp->an_left;

        /* Hard luck... This node has two descendants.  So find the    *
         * rightmost node of our left subtree, and link him in place.  */

    else {

        /* Mark adj to zero (so we will not adjust the balance  *
         * of the parent here).  Find the rightmost decendant   *
         * of the deleted node's left subtree.  It might be the *
         * same as the left child node, so we must check later. */

        adj = 0;
        for (canp = anp->an_left; canp->an_right; canp = canp->an_right)
            ;

        /* canp will replace anp.  qanp is canp's parent. Since *
         * we are replacing anp, in effect we are really        *
         * deleting a subtree from qanp, so we must start the   *
         * rebalancing from qanp on up.                         */

        qanp = canp->an_up;
        if (qanp != anp) {
            if ((qanp->an_right = canp->an_left) != 0)
                qanp->an_right->an_up = qanp;
            qanp->an_balance--;
            canp->an_left = anp->an_left;
            canp->an_left->an_up = canp;
            canp->an_balance = anp->an_balance;
        } else {
            canp->an_balance = anp->an_balance + 1;
            qanp = canp;
        }
        canp->an_right = anp->an_right;
        canp->an_right->an_up = canp;
    }

    /* Adjust the parent pointer.  If a parent node really exists,  *
     * then adj will update its balance.                            */

    if (panp) {
        if (anp == panp->an_left) {
            panp->an_left = canp;
            panp->an_balance += adj;
        } else {
            panp->an_right = canp;
            panp->an_balance -= adj;
        }
    } else
        ahp->ah_top = canp;
    if (canp)
        canp->an_up = panp;

    /* Balance the tree if the balance factor did not just go to +1 *
     * or -1 (+1 and -1 are odd.  +2, 0, and -2 are even).  Then we *
     * can free the data and tag for this node, the node itself,    *
     * and finally exit.                                            */

    if (qanp && !(qanp->an_balance & 01))
        avlbalance(ahp, qanp, 0);
    if (ahp->ah_delete)
        (*ahp->ah_delete)(ahp, anp);
    AVLNFREE(anp);

    /* If we are to debug changes to tree, then do so.      */

    switch (ahp->ah_debug) {
    case AVD_DMP:
        printf("\n\n*********\n\nAfter deleting\n");
        if (ahp->ah_print)
            (void) avldepth(ahp, ahp->ah_print, NULL);
        /* Fall through */
    case AVD_CHK:
        (void) avlcheck(ahp, ahp->ah_top, NULL);
        break;
    }
}

/*
 *      <avlbalance>
 *
 *      Check and correct the balance factor of a modified node,
 *      and its ancestors.
 *      This is a static internal routine.
 *
 *      avlbalance(ahp, anp, add)
 *
 *      avlhdr  *ahp;           Ptr to tree header.
 *      anode   *anp;           Bottom-most node that needs balancing.
 *      int     add;            1 => node was added to tree.
 *                              0 => node was deleted from tree.
 */

static void 
avlbalance(avlhdr *ahp, anode *anp, int add)
{
    register anode *oldanp;
    register anode *panp;
    register anode *canp;

    for (; anp; anp = anp->an_up)
        switch (anp->an_balance) {
        case BAL(-2):
            oldanp = anp->an_left;

            /* If add, check for balance < 0.               *
             * If delete, check for <= 0.                   *
             * If add is 1, then condidtion will be true if *
             * the balance is -1 ( < 0).  If add is zero,   *
             * the condition will be true if balance is 0   *
             * or 1 ( <= 0).                                */

            /* Single LL rotation */
            if ((oldanp->an_balance + add) <= BAL(0)) {
                if ((panp = anp->an_up) != 0) {
                    if (panp->an_left == anp)
                        panp->an_left = oldanp;
                    else
                        panp->an_right = oldanp;
                } else
                    ahp->ah_top = oldanp;
                oldanp->an_up = panp;

                if ((anp->an_left = oldanp->an_right) != 0)
                    anp->an_left->an_up = anp;
                oldanp->an_right = anp;
                anp->an_up = oldanp;
                if (oldanp->an_balance < BAL(0)) {
                    anp->an_balance = BAL(0);
                    oldanp->an_balance = BAL(0);
                    anp = oldanp;
                } else {
                    anp->an_balance = BAL(-1);
                    oldanp->an_balance = BAL(1);
                    return;
                }
            } else  {    /* Double LR rotation */
                canp = oldanp->an_right;
                if ((panp = anp->an_up) != 0) {
                    if (panp->an_left == anp)
                        panp->an_left = canp;
                    else
                        panp->an_right = canp;
                } else
                    ahp->ah_top = canp;
                canp->an_up = panp;

                if ((oldanp->an_right = canp->an_left) != 0)
                    oldanp->an_right->an_up = oldanp;
                canp->an_left = oldanp;
                oldanp->an_up = canp;
                if ((anp->an_left = canp->an_right) != 0)
                    anp->an_left->an_up = anp;
                canp->an_right = anp;
                anp->an_up = canp;
                if (canp->an_balance  == BAL(-1))
                    anp->an_balance = BAL(1);
                else
                    anp->an_balance = BAL(0);
                if (canp->an_balance == BAL(1))
                    oldanp->an_balance = BAL(-1);
                else
                    oldanp->an_balance = BAL(0);
                canp->an_balance = BAL(0);
                anp = canp;
            }
            goto delbal;
        case BAL(-1):
        case BAL(1):
            if (add && ((panp = anp->an_up) != 0)) {
                panp->an_balance += (anp == panp->an_left) ? -1 : 1;
                continue;
            }
            return;
delbal:
        case BAL(0):
            if (!add && ((panp = anp->an_up) != 0)) {
                panp->an_balance -= (anp == panp->an_left) ? -1 : 1;
                continue;
            }
            return;
        case BAL(2):
            oldanp = anp->an_right;

            /* If add, check for balance > 0.               *
             * If delete, check for >= 0.                   *
             * If add is 1, then condidtion will be true if *
             * the balance is 1 ( > 0).  If add is zero, the*
             * condition will be true if balance is 0 or 1  *
             * ( >= 0).                                     */

            /* Single RR rotation */
            if ((oldanp->an_balance - add) >= BAL(0)) {
                if ((panp = anp->an_up) != 0) {
                    if (panp->an_left == anp)
                        panp->an_left = oldanp;
                    else
                        panp->an_right = oldanp;
                } else
                    ahp->ah_top = oldanp;
                oldanp->an_up = panp;

                if ((anp->an_right = oldanp->an_left) != 0)
                    anp->an_right->an_up = anp;
                oldanp->an_left = anp;
                anp->an_up = oldanp;
                if (oldanp->an_balance > BAL(0)) {
                    anp->an_balance = BAL(0);
                    oldanp->an_balance = BAL(0);
                    anp = oldanp;
                } else {
                    anp->an_balance = BAL(1);
                    oldanp->an_balance = BAL(-1);
                    return;
                }
            } else {          /* Double RL rotation */
                canp = oldanp->an_left;
                if ((panp = anp->an_up) != 0) {
                    if (panp->an_left == anp)
                        panp->an_left = canp;
                    else
                        panp->an_right = canp;
                } else
                    ahp->ah_top = canp;
                canp->an_up = panp;
                if ((oldanp->an_left = canp->an_right) != 0)
                    oldanp->an_left->an_up = oldanp;
                canp->an_right = oldanp;
                oldanp->an_up = canp;
                if ((anp->an_right = canp->an_left) != 0)
                    anp->an_right->an_up = anp;
                canp->an_left = anp;
                anp->an_up = canp;
                if (canp->an_balance == BAL(1))
                    anp->an_balance = BAL(-1);
                else
                    anp->an_balance = BAL(0);
                if (canp->an_balance == BAL(-1))
                    oldanp->an_balance = BAL(1);
                else
                    oldanp->an_balance = BAL(0);
                canp->an_balance = BAL(0);
                anp = canp;
            }
            goto delbal;
        }
}

/*+
 * avlfree
 *
 *      Free a whole avl tree.
 *
 *      avlfree(ahp)
 *
 *      avlhdr  *ahp;           Ptr to tree to free.
-*/

void
avlfree(avlhdr *ahp)
{
    register anode *anp;
    register anode *newanp;

    /* sick of this core dump */
    if (ahp == 0)
        return;
    for (anp = ahp->ah_top; anp; anp = newanp) {
        if (anp->an_left) {
            newanp = anp->an_left;
            anp->an_left = NULL;
        } else if (anp->an_right) {
            newanp = anp->an_right;
            anp->an_right = NULL;
        } else {
            newanp = anp->an_up;
            if (ahp->ah_delete)
                (*ahp->ah_delete)(ahp, anp);
            AVLNFREE(anp);
        }
    }
    AVLNFREE((anode * ) ahp);
}

/*
 *      <avlnode>
 *
 *      Allocate an avl node from the node pool.
 *      This is a static internal routine.
 *
 *      anp = avlnode();
 *
 *      anode   *anp;           Returned ptr to new node.
 */

static anode *
avlnode(void)
{
    register anode *anp;
    register anode *endp;

    while ((anp = Avlfree) == NULL) {
        anp = (anode * ) malloc(sizeof (anode) * ANALL);
        if (anp == NULL)
            return NULL;
        memset(anp, '\0', sizeof(anode) * ANALL);
        for (endp = &anp[ANALL]; anp < endp; anp++)
            AVLNFREE(anp);
    }
    Avlfree = anp->an_next;
    anp->an_left     = NULL;
    anp->an_up       = NULL;
    anp->an_right    = NULL;
    anp->an_balance  = BAL(0);
    anp->an_flags[0] = anp->an_flags[1] = anp->an_flags[2] = 0;
    return anp;
}

#define LEFT    0
#define RIGHT   1
#define HERE    2

/*+
 * avldepth
 *
 *      Do a depth-first search of an avl tree, calling the given function
 *      with every node.
 *
 *      ret = avldepth(ahp, func, param)
 *
 *      int     ret;            Return value. Zero => the whole tree was
 *                              searched without abort.
 *      avlhp   *ahp;           Ptr to tree header.
 *      int     (*func)();      Ptr to function to call.
 *      void    *param;         Extra parameter passed to func.
 *
 *      The given function will be called with an (anode *) parameter,
 *      which is the node currently being visited, along with an integer
 *      tree depth, and the optional parameter.  The function should return
 *      zero, unless it wishes the search to be aborted.  A non-zero return
 *      will abort the search, and become avldepth()'s return value.
-*/

int
avldepth(avlhdr *ahp, int (*func)(anode *, int, void *), void *param)
{
    register anode *anp;
    register int depth;
    register anode *nanp;
    char way[MAXLEVEL];
    int return_value;

    way[0] = LEFT;
    depth = 0;
    for (anp = ahp->ah_top; anp; anp = nanp)
        switch (way[depth]) {
        case LEFT:
            if ((nanp = anp->an_left) != 0) {
                way[depth++] = HERE;
                way[depth] = LEFT;
                break;
            }
            /* FALL THROUGH */
        case HERE:
            if ((return_value = (*func)(anp, depth, param)) != 0)
                return return_value;
            if ((nanp = anp->an_right) != 0) {
                way[depth++] = RIGHT;
                way[depth] = LEFT;
                break;
            }
            /* FALL THROUGH */
        case RIGHT:
            nanp = anp->an_up;
            depth--;
            break;
        }
    return 0;
}

/*+
 * avlbrdth
 *
 *      Do a breadth-first search of an avl tree, calling the given function
 *      with every node.
 *
 *      ret = avlbrdth(ahp, func, param)
 *
 *      int     ret;            Return value. Zero => the whole tree was
 *                              searched without abort.
 *      avlhp   *ahp;           Ptr to tree header.
 *      int     (*func)();      Ptr to function to call.
 *      void    *param;         Extra parameter passed to func.
 *
 *      The given function will be called with an (anode *) parameter,
 *      which is the node currently being visited, along with an integer
 *      tree depth, and the extra parameter.  The function should return
 *      zero, unless it wishes the search to be aborted.  A non-zero return
 *      will abort the search, and become avlbrdth()'s return value.
-*/

int
avlbrdth(avlhdr *ahp, int (*func)(anode *, int, void *), void *param)
{
    register anode *anp;
    register anode *nanp;
    register int depth;
    int more = 1;
    char way[MAXLEVEL];
    int current_depth;
    int return_value;

    for (current_depth = 0; more; current_depth++) {
        depth = more = 0;
        way[depth] = HERE;
        for (anp = ahp->ah_top; anp; anp = nanp)
            switch (way[depth]) {
            case HERE:
                if (depth == current_depth) {
                    if ((return_value = (*func)(anp, depth, param)) != 0)
                        return return_value;
                    if (anp->an_left || anp->an_right)
                        more = 1;
                }
                if ((nanp = anp->an_left) != 0) {
                    way[depth++] = LEFT;
                    way[depth] = HERE;
                    break;
                }
                /* FALL THROUGH */
            case LEFT:
                if ((nanp = anp->an_right) != 0) {
                    way[depth++] = RIGHT;
                    way[depth] = HERE;
                    break;
                }
                /* FALL THROUGH */
            case RIGHT:
                nanp = anp->an_up;
                depth--;
                break;
            }
    }
    return 0;
}

/*+
 * avlcheck
 *
 *      Check the structure of the given avl tree.
 *
 *      balance = avlcheck(ahp, anp, parent)
 *
 *      int     balance;        balance of the tree {-1, 0, 1}
 *      avlhdr  *ahp;           ptr to header of tree.
 *      anode   *anp;           ptr to node of subtree to check.
 *      anode   *parent;        ptr to parent of subtree to check.
 *
 *      Errors are indicated by a printout to stdout, followed by a call to
 *      abort().
 *
 *      The entire tree may be checked by -
 *
 *              (void) avlcheck(ahp, ahp->ah_top, NULL);
-*/

int
avlcheck(avlhdr *ahp, anode *anp, anode *parent)
{
    register int rght = 0;
    register int left = 0;

    if (anp->an_up != parent) {
        printf("Bad parent ptr at %X\n", anp);
        fflush(stdout);
        abort();
    }
    if (anp->an_left)
        left = avlcheck(ahp, anp->an_left, anp);
    if (anp->an_right)
        rght = avlcheck(ahp, anp->an_right, anp);
    if (BAL(rght - left) != anp->an_balance) {
        printf("Bad avl balance at %X\n", anp);
        fflush(stdout);
        abort();
    }
    return ((left > rght) ? left : rght) + 1;
}

/*+
 * avlinit
 *
 *      Initialize an empty header set.
 *
 *      ahp = avlinit()
 *
 *      struct avlhdr   *ahp            returned pointer to header node.
 *                                      NULL if avlinit() failed.
-*/

avlhdr *
avlinit(void)
{
    register avlhdr *ahp;

    if ((ahp = (avlhdr * ) avlnode()) != 0) {
        ahp->ah_top        = NULL;
        ahp->ah_debug      = (AvlDFlags) 0;
        ahp->ah_cmp        = AVC_NONE;
        ahp->ah_delete     = NULL;
        ahp->ah_print      = NULL;
        ahp->ah_user       = NULL;
    }
    return ahp;
}

/*+
 * avlfirst
 *
 *      Fetch a pointer to the first node in the tree.
 *
 *      anp = avlfirst(ahp)
 *
 *      avlhdr  *ahp            Pointer to tree.
 *      anode   *anp            Returned ptr to node.  NULL is returned
 *                              if there are no nodes in the tree.
-*/

anode *
avlfirst(avlhdr *ahp)
{
    register anode *anp;
    register anode *oanp;

    oanp = NULL;
    for (anp = ahp->ah_top; anp; anp = anp->an_left)
        oanp = anp;
    return oanp;
}

/*+
 * avlnext
 *
 *      Fetch a pointer to the next node in the tree.
 *
 *      nanp = avlnext(ahp, anp, delete)
 *
 *      avlhdr  *ahp            Pointer to tree.
 *      anode   *anp            Pointer to present node in the tree.
 *      int     delete          If non-zero, the node pointed to by <anp>
 *                              will be deleted.
 *      anode   *nanp           Returned ptr to next node.  NULL is returned
 *                              if there are no more nodes in the tree.
-*/

anode *
avlnext(avlhdr *ahp, anode *anp, int delete_it)
{
    register anode *nanp;
    register anode *oanp;

    if (anp->an_right) {
        nanp = NULL;
        for (oanp = anp->an_right; oanp; oanp = oanp->an_left)
            nanp = oanp;
    } else {
        oanp = anp;
        for (nanp = anp->an_up; nanp; nanp = nanp->an_up) {
            if (oanp == nanp->an_left)
                break;
            oanp = nanp;
        }
    }
    if (delete_it)
        avldelete(ahp, anp);
    return nanp;
}

/*+
 * avllast
 *
 *      Fetch a pointer to the last node in the tree.
 *
 *      anp = avllast(ahp)
 *
 *      avlhdr  *ahp            Pointer to tree.
 *      anode   *anp            Returned ptr to node.  NULL is returned
 *                              if there are no nodes in the tree.
-*/

anode *
avllast(avlhdr *ahp)
{
    register anode  *anp;
    register anode  *oanp;

    oanp = NULL;
    for (anp = ahp->ah_top; anp; anp = anp->an_right)
        oanp = anp;
    return oanp;
}

/*+
 * avlprev
 *
 *      Fetch a pointer to the previous node in the tree.
 *
 *      nanp = avlprev(ahp, anp, delete_it)
 *
 *      avlhdr  *ahp            Pointer to tree.
 *      anode   *anp            Pointer to present node in the tree.
 *      int     delete_it       If non-zero, the node pointed to by <anp>
 *                              will be deleted.
 *      anode   *nanp           Returned ptr to previous node.  NULL is
 *                              returned if there are no more nodes in the tree
-*/

anode *
avlprev(avlhdr *ahp, anode *anp, int delete_it)
{
    register anode *nanp;
    register anode *oanp;

    if (anp->an_left) {
        nanp = NULL;
        for (oanp = anp->an_left; oanp; oanp = oanp->an_right)
            nanp = oanp;
    } else {
        oanp = anp;
        for (nanp = anp->an_up; nanp; nanp = nanp->an_up) {
            if (oanp == nanp->an_right)
                break;
            oanp = nanp;
        }
    }
    if (delete_it)
        avldelete(ahp, anp);
    return nanp;
}
